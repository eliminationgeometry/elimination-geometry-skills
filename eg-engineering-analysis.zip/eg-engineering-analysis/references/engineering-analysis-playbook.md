# EG Engineering-Analysis Playbook

Read this file after the engineering-analysis canon when the task needs physical modeling, simulation, controls, materials, structures, fluids, waves, energy, process systems, Earth systems, or scientific machine learning. The domain examples are candidate interfaces, not claims that the bundled EG corpus already proves each result.

## 1. Establish the engineering contract

Before choosing a reduced state or architecture, declare:

- engineering decision, predicted quantity, controlled output, or design objective;
- spatial, temporal, energetic, and statistical scales;
- units and nondimensional groups;
- governing equations, empirical laws, or data-driven model class;
- initial, boundary, interface, loading, and forcing conditions;
- material, geometric, manufacturing, and operating-envelope assumptions;
- conservation, symmetry, positivity, passivity, causality, stability, or admissibility constraints;
- available sensors, actuators, computation, memory, bandwidth, and experimental interventions;
- tolerance, risk aggregation, safety factor, and validation endpoint.

Do not substitute a convenient field norm for a mission or design criterion without establishing the connection.

## 2. Local high fidelity versus shared engineering model

Typical local objects include a fine-scale solution, locally calibrated constitutive law, operating-point controller, detailed mesh, full spectral basis, microstructure, path history, kinetic state, or experiment-specific inverse solution.

Typical shared grammars include:

- one reduced-order basis across parameters or regimes;
- one closure or constitutive model across scales and load paths;
- one controller, estimator, or gain schedule across operating points;
- one mesh family, timestep rule, or solver stack across geometries;
- one sensor layout or acquisition policy;
- one homogenized descriptor across microstructures;
- one surrogate or digital twin across environmental and lifecycle conditions;
- one design satisfying several loads, missions, manufacturing constraints, and uncertainties.

The engineering obstruction is not “the model is imperfect.” It is the residual loss forced specifically by the declared shared contract after local model adequacy, evidence, numerical resolution, and implementation are separated.

## 3. Error and evidence accounts

Keep these mechanisms distinct:

| Account | Questions |
|---|---|
| Scientific/model form | Are the governing laws, constitutive assumptions, closures, and neglected physics adequate? |
| Shared representation/architecture | Can the chosen state, basis, controller, sensor, or design grammar represent every task-relevant local solution? |
| Parameters and evidence | Are parameters identifiable and calibration/operating data informative over the required envelope? |
| Discretization and numerics | Are mesh, timestep, basis, quadrature, precision, conditioning, and solver tolerances resolved? |
| Coupling and transmission | Does the local discrepancy propagate through multiphysics interfaces, feedback, or downstream observables? |
| Implementation | Are equations, units, boundary conditions, material tables, parallel reductions, and code paths implemented correctly? |
| Experiment and validation | Does the model predict an independently measured endpoint at the claimed scale and uncertainty? |
| Resources and operation | Do sensing, control, compute, latency, energy, fabrication, and maintenance constraints bind? |

The classification may depend on the declared design class. A fixed coarse mesh can be an architecture restriction in one study and an incomplete numerical implementation in another. State the contract.

## 4. Minimal physical witnesses

Prefer a load case, mode, scale, path, or regime that exposes the missing distinction:

- two microstructures with the same retained descriptor but different target properties;
- two load histories with equal current stress/strain and different future response;
- two flow states with equal coarse variables but different forces, mixing, or stability;
- two wave fields with equal intensity and different phase, polarization, or coherence;
- two operating points requiring incompatible controller actions;
- two parameter fields producing indistinguishable sensors and different mission outcomes;
- one discarded mode that dominates a boundary load or instability;
- one singular, bifurcating, contact, fracture, or transition regime where a smooth shared model fails.

Verify that the pair satisfies the same boundary, resource, and admissibility contract. A witness produced by changing the problem does not diagnose the original model.

## 5. Domain routes

### Composite materials and microstructure

Candidate eliminands:

- constituent fields, geometry, interfaces, orientation distributions, defects, residual stress, and loading history.

Shared grammars:

- representative volume elements, homogenized tensors, reduced descriptors, constitutive families, surrogate microstructure–property maps, and common manufacturing rules.

Native task quantities:

- compliance, stiffness, strength, fatigue life, damage, fracture, thermal/electrical transport, permeability, or another declared property.

Useful witnesses and repairs:

- same volume fractions but different connectivity or orientation and different property;
- same current macroscopic state but different irreversible history;
- refine the descriptor, retain a path/state variable, split regimes, use a task-conditioned RVE, or change the manufacturing/design grammar.

Require scale separation or quantify its failure; check boundary-condition and RVE-size sensitivity, conservation, symmetry, positive definiteness, mesh convergence, material uncertainty, and experimental validation.

### Solid, structural, and geotechnical mechanics

Candidate eliminands include fine stress fields, internal variables, contact state, crack topology, soil heterogeneity, and dynamic modes. Shared grammars include reduced finite-element bases, constitutive models, damage states, sensor layouts, and common structural designs.

Potential witnesses include load-path dependence, mode localization, buckling branch changes, contact activation, crack initiation, and soils with equal coarse descriptors but different failure. Repairs may add internal state, enrich the basis/mesh locally, retain branch information, change sensor placement, or alter the structural design.

Check equilibrium, compatibility, objectivity, conservation, constitutive admissibility, patch and manufactured-solution tests, mesh/objectivity studies, uncertainty, and independent measurements.

### Fluid mechanics and transport

Candidate eliminands include unresolved scales, subgrid stresses, memory kernels, boundary layers, multiphase interfaces, reaction states, and coherent structures. Shared grammars include one turbulence/closure model, reduced basis, grid family, learned operator, or controller across regimes.

Native quantities may be force, heat/mass transfer, mixing, pressure loss, stability, acoustics, combustion efficiency, path action, or mission cost—not residual alone.

Witnesses include equal coarse moments with different fluxes, discarded modes that change forces, history-dependent separation, regime transitions, or closure failure at a boundary. Repairs may enrich state/memory, split regimes, add local modes, adapt sensing/mesh, change closure, or narrow the operating envelope.

Check mass, momentum, energy, species, entropy, positivity, realizability, grid/timestep/domain convergence, inlet/outlet sensitivity, turbulence statistics, rare events, calibration separation, and experimental validation.

### Wave physics, optics, acoustics, and electromagnetics

Candidate eliminands include phase, polarization, coherence, evanescent modes, boundary traces, scattering paths, frequency content, and fine geometry. Shared grammars include intensity-only measurements, modal truncations, paraxial or effective-medium models, fixed arrays, reduced bases, and common inverse/design architectures.

Task-visible witnesses include equal intensities with different phases, equal far fields with different near-field behavior, truncated modes that alter focusing or boundary loads, and structures with equal effective parameters but different band or transient response.

Repairs may retain phase/coherence, add modes or sensors, refine boundary representation, use frequency- or task-conditioned bases, change illumination, or narrow the task. Check energy flux, reciprocity, passivity, causality, gauge/polarization conventions, dispersion, mesh and domain truncation, inverse nonuniqueness, and measurement calibration.

### Control, estimation, and autonomous systems

Candidate eliminands include hidden state, disturbance, model uncertainty, belief state, trajectory history, and fast dynamics. Shared grammars include one controller, estimator, state abstraction, action menu, gain schedule, or onboard compute/sensor contract.

Witnesses include two hidden states with the same retained estimate and different safe actions, operating points requiring incompatible gains, current output equality with different future transitions, and unmodeled dynamics transmitted through feedback.

Repairs may enrich state/belief, schedule or switch controllers with a certified gate, add sensing or actions, change update memory, robustify the controller, or reduce the certified envelope.

Check observability, controllability, stability margins, robustness, constraints, latency, saturation, estimator/controller interaction, failure modes, simulation-to-hardware gap, and independent scenario or hardware validation.

### Thermal, chemical, process, and energy systems

Candidate eliminands include reaction intermediates, fine temperature/composition fields, degradation state, electrochemical microstate, network contingencies, and fast process variables. Shared grammars include reduced kinetics, lumped models, process controllers, battery states, dispatch policies, and surrogate plants.

Witnesses include equal aggregate state with different degradation or runaway risk, reduced kinetics that preserve steady output and fail transients, and operating regimes requiring incompatible control or dispatch. Repairs may add state, reactions, modes, sensors, regime logic, or resource flexibility.

Check elemental and energy balance, thermodynamic admissibility, positivity, stiffness, conservation, transport coupling, parameter identifiability, fault scenarios, uncertainty, and plant/experimental validation.

### Earth, climate, environmental, and subsurface systems

Candidate eliminands include subgrid processes, unresolved topography, clouds, turbulence, ecological state, porous heterogeneity, and historical forcing. Shared grammars include parameterizations, coarse grids, assimilation states, reduced models, and common sensor networks.

Witnesses include equal resolved states with different fluxes or extremes, parameterizations that preserve climatology and fail interventions, and sensor-equivalent fields with different hazards. Repairs may retain memory/state, refine parameterization or grid, target observations, use regime-aware models, or narrow the inference contract.

Separate weather, climate, causal intervention, and hazard tasks. Check conservation, balance, scale coupling, boundary forcing, ensemble uncertainty, extremes, hindcast leakage, and out-of-period or out-of-region validation.

### Scientific machine learning and digital twins

Candidate eliminands include fine simulation state, latent parameters, geometry, history, and uncertainty. Shared grammars include one neural operator, surrogate, latent state, encoder, or twin across systems and regimes.

Witnesses include two physical states sharing an embedding but requiring different outputs or updates, strong interpolation and failed extrapolation at a task-visible transition, and a surrogate residual that is small while mission error is large.

Repairs may refine the representation, add invariants/state/modes, acquire targeted data, split regimes, constrain the architecture, or preserve a physical update variable. Distinguish training loss, equation residual, physical validity, task performance, and operational latency.

## 6. Verification ladder

Use the layers required by the claim:

1. **Dimensional and type consistency:** units, coordinates, sign/orientation, tensor/object types.
2. **Local law:** governing equation, constitutive relation, conservation, positivity, symmetry, or passivity.
3. **Limiting and exact cases:** analytical solution, manufactured solution, asymptotic limit, zero-coupling, or zero-obstruction regime.
4. **Numerical resolution:** mesh, timestep, basis, precision, quadrature, tolerance, domain, and iteration convergence.
5. **Witness exposure:** the reduced/shared model fails on the predicted pair, path, mode, or operating point.
6. **Matched repair:** the change restores the witness under the same task and resource ledger.
7. **Negative control:** a generic equal-resource change or task-invisible distinction does not produce the same causal story.
8. **Envelope and uncertainty:** sensitivity, parameter uncertainty, aleatory variability, robustness, rare/singular regimes.
9. **Independent validation:** frozen measurements, experiment, field data, hardware, or a genuinely held-out scenario.

Do not skip directly from a training or calibration fit to a design recommendation.

## 7. Calibration, validation, and authorization

Keep separate:

- data used to choose model form, features, closure, or architecture;
- data used to estimate parameters;
- data used to select hyperparameters, discretization, or operating envelope;
- data or experiments reserved to validate the final claim.

If the same evidence serves several roles, state the resulting limitation. A posterior or calibrated parameter distribution may guide experiments; it does not automatically authorize a safety, reliability, or compliance conclusion.

## 8. Resource and design tradeoffs

Modes, sensors, states, mesh cells, parameters, precision, experiments, compute, energy, mass, and manufacturing complexity are different resources. Do not add them into one budget without an explicit cost model.

When comparing designs, match the resources relevant to the claim and report the full ledger. A lower-order model with hidden offline computation or a controller with uncounted refresh/sensing cost is not an equal-resource comparison.

## 9. Safety and professional boundary

For decisions affecting life safety, medical treatment, critical infrastructure, environmental compliance, flight, structural certification, or regulated products:

- identify the governing jurisdiction and current authoritative standards;
- preserve required safety factors, verification independence, traceability, and configuration control;
- obtain qualified domain review and required experimental certification;
- state that EG analysis is diagnostic support, not approval authority.

Do not use broad cross-disciplinary claims as a substitute for domain evidence.

## 10. Compact physical-engineering checkpoint

```text
Engineering task and units:
Operating envelope and quantifiers:
Local high-fidelity object:
Shared/reduced grammar:
Task-visible witness:
Leading error account and alternatives:
Transmission to the endpoint:
Resolution/saturation evidence:
Matched repair:
Verification and independent validation:
Remaining nonclaims:
```
