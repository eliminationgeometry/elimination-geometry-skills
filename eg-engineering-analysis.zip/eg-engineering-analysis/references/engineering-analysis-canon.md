# EG Engineering-Analysis Canon

This is the mandatory lightweight operating memory for `eg-engineering-analysis`. It translates the Elimination Geometry monograph and task-visible research logic into decisions about physical models, simulations, controls, experiments, and engineered designs. It does not replace exact EG sources, current domain literature or standards, physical validation, or licensed engineering judgment.

## 1. Mission

Ask:

> When locally adequate physical solutions, models, controllers, measurements, or designs must be replaced by one shared and deployable object, which distinctions visible to the declared engineering task are lost, where does the loss first occur, and what smallest change restores the required behavior?

Use this discovery order:

```text
engineering task and units
  -> typed physical system
  -> task quotient
  -> local high-fidelity object
  -> shared model/design grammar
  -> lost physical distinction
  -> native cost or diagnostic proxy
  -> minimal admissible witness
  -> coupling/transmission and task exposure
  -> discriminating analysis, simulation, or experiment
  -> matched intervention
  -> verification and independent validation
```

Every arrow is a question, not an automatic implication.

## 2. Scope boundary

Use this canon when the primary artifact is a governing model, retained state, closure, geometry, material law, boundary/load condition, reduced basis, controller, sensing plan, experiment, or physical design.

Do not use it merely because software runs the analysis. When acceptance depends on source-code behavior, APIs, concurrency, builds, deployment, or runtime correctness, the task is software engineering. In a mixed task, state which interface is currently being judged.

## 3. Three levels of analysis

Keep separate:

1. **Local physical adequacy:** each operating point, load case, scale, material realization, or regime can be modeled or designed adequately on its own.
2. **Shared realizability:** one legal closure, controller, surrogate, reduced state, sensor layout, manufacturing grammar, or design can serve the full declared envelope.
3. **Evidence and authorization:** analysis, simulations, measurements, and standards are sufficient to identify the mechanism and support the proposed decision.

Local adequacy does not prove shared realizability. A structural obstruction does not prove finite evidence can detect it. A calibrated model is not automatically validated or authorized.

## 4. Engineering translation of EG objects

| EG object | Physical/scientific engineering interpretation |
|---|---|
| Context or world \(x\) | load case, operating point, geometry, material realization, environment, time, path, or scale |
| Local oracle \(a_x^\star\) | fine solution, locally calibrated law, local controller, mesh, basis, sensor choice, or design |
| Shared grammar \(\mathfrak A\) | one closure, constitutive family, controller, reduced basis, surrogate, sensor layout, manufacturing rule, or resource contract |
| Local objective \(H_x(a)\) | compliance, energy, force error, instability, control cost, damage, risk, or mission loss |
| Eliminated target \(J(x)\) | best attainable local value after optimizing the auxiliary object |
| Native defect | exact excess in the original engineering objective after inserting a non-oracle object |
| Carrier | retained state, coarse field, descriptor, basis coefficients, measurements, or controller memory |
| Quotient | physical distinctions intentionally ignored by the declared task |
| Witness | smallest pair, path, scale, mode, branch, or regime exposing the loss |
| Transmission | dynamics, feedback, multiphysics coupling, propagation, or observation chain |
| Exposure | force, stability, damage, performance, safety, control, or scientific endpoint distinguishes the mismatch |
| Saturation | the fixed model/design class has been adequately calibrated and numerically resolved |
| Matched repair | a change acting on the interface identified by the witness |

Do not manufacture a formal objective. Measured discrepancies and a valid collision can support an EG-structured diagnosis without certifying an EG defect.

## 5. Task-relative physical sufficiency

No coarse state, descriptor, closure, basis, sensor set, or surrogate is simply sufficient. It is sufficient for a declared endpoint, operating envelope, continuation, risk aggregation, and tolerance.

Examples:

- the same volume fractions can be adequate for stiffness and insufficient for failure or transport;
- a reduced flow state can preserve bulk energy while missing a load-driving coherent structure;
- an intensity-only optical representation can preserve power and lose task-visible phase;
- a current controller state can select the right action now and fail after the next observation;
- a steady-state reduced kinetic model can fail a transient or runaway task.

Define task equivalence before counting variables, modes, cells, sensors, parameters, or experiments.

## 6. Local freedom versus shared grammar

The grammar must say what may adapt and what must remain common. Useful contracts include:

- one closure or constitutive law across regimes and loading paths;
- one controller, estimator, or gain schedule across operating points;
- one reduced basis, mesh family, or surrogate across parameters and geometries;
- one sensor or actuation layout under a fixed budget;
- one homogenized descriptor across microstructures;
- one manufactured design across missions, loads, tolerances, and uncertainties.

The key quantifier is:

```text
each context has an adequate physical object
does not imply
one admissible shared object is adequate for every context.
```

## 7. Native task cost before proxy cost

Prefer the actual engineering quantity: force, energy, compliance, fatigue life, heat transfer, mixing, pressure loss, control cost, stability margin, probability of failure, or another declared endpoint.

Residual norms, parameter distance, rank, mode count, mesh size, bit count, runtime, and spectral angles are separate accounts. Relating them to task loss requires a theorem, stability estimate, experiment, or explicit cost model.

When an exact elimination exists,

\[
J(x)=\inf_a H_x(a),
\qquad
D_x(a)=H_x(a)-J(x)\ge 0,
\]

certify exactness, orientation, nonnegativity, and touching before calling \(D_x\) a native defect.

## 8. Typed error accounts

| Account | Typical question | Matched response |
|---|---|---|
| Scientific/model form | Are governing laws, closures, and neglected physics adequate? | revise the model or certified envelope |
| Shared representation/design | Does one retained state, basis, controller, sensor, or design merge task-distinct cases? | enrich, split, schedule, or change the shared grammar |
| Parameters/evidence | Are parameters identifiable and data informative over the envelope? | acquire or diversify evidence; retain unresolvedness |
| Numerics/optimization | Are mesh, timestep, precision, conditioning, tolerance, and search adequate? | resolve or improve the numerical method inside the class |
| Coupling/transmission | Does the discrepancy survive dynamics, feedback, or multiphysics interfaces? | repair coupling or narrow the task claim |
| Implementation/units | Are equations, signs, units, tables, and boundary conditions implemented correctly? | correct the implementation |
| Experiment/validation | Does the selected model predict an independent endpoint? | perform frozen or external validation |
| Resources/operation | Do sensing, control, compute, fabrication, energy, or maintenance constraints bind? | change the resource or operating contract |

Do not exchange accounts without evidence.

## 9. Witness-first diagnosis

A useful witness demonstrates the failure and indicates the repair. Seek:

- two microstructures with equal retained descriptors and different target properties;
- two histories with equal current macrostate and different future response;
- two flow fields with equal coarse variables and different forces, mixing, or stability;
- two wave fields with equal intensity and different phase, coherence, or polarization;
- two operating points requiring incompatible controller actions;
- one discarded mode controlling a boundary load or instability;
- one bifurcation, contact, fracture, transition, or singular regime where a smooth shared model fails.

Keep geometry, loads, boundary conditions, resources, and admissibility fixed. A witness created by changing the contract does not diagnose the original system.

## 10. Transmission and exposure

Trace:

```text
lost physical distinction
  -> retained carrier or closure
  -> dynamics/coupling/controller
  -> declared engineering observer
```

If the path annihilates the mismatch, it is not loss for that task. Narrow the claim or choose a legitimate observer; do not manufacture exposure.

## 11. Saturation and matched intervention

Before blaming the shared class, check local high-fidelity adequacy, calibration, identifiability, mesh/timestep/basis/tolerance convergence, solver robustness, implementation, and a zero-obstruction regime.

Let the witness route the intervention:

| Witness | Matched intervention |
|---|---|
| descriptor or coarse-state collision | retain a task-visible variable, moment, mode, or topology |
| equal current state, different continuation | add history or recursive state |
| incompatible operating regimes | split, schedule, switch with a valid gate, or narrow the envelope |
| unobservable task distinction | repair sensing or experimental design |
| discarded slow/unstable mode | enrich, precondition, deflate, or restructure that channel |
| numerical class adequate, solver misses it | improve numerics inside the class |
| no declared endpoint sees the difference | narrow the claim; do not redesign |

Compare a matched repair with a generic equal-resource change when making a mechanism claim.

## 12. Verification ladder

Use only the layers needed, but name those skipped:

1. units, coordinates, signs, and object types;
2. governing laws, conservation, symmetry, positivity, passivity, and admissibility;
3. exact, manufactured, limiting, zero-coupling, and zero-obstruction cases;
4. mesh, timestep, basis, quadrature, precision, tolerance, domain, and iteration convergence;
5. witness exposure under the unchanged task contract;
6. mechanism-matched repair and equal-resource control;
7. sensitivity, identifiability, uncertainty, rare regimes, and robustness;
8. independently frozen experiment, field data, hardware, or scenario.

Keep model selection, parameter calibration, numerical tuning, and final validation evidence distinct.

## 13. Evidence grades and verdicts

- **Observed:** present in supplied measurements, simulations, or artifacts.
- **Reproduced:** regenerated under a recorded configuration.
- **Inferred:** best current explanation, with alternatives stated.
- **Certified:** supported by a proof, exact identity, or explicit validity contract at the claimed scope.
- **Validated:** confirmed on an independently frozen physical endpoint.
- **Unresolved:** current evidence does not select a conclusion.

The verdict is `ordinary`, `EG-structured`, `certified EG`, or `unresolved`. Evidence grade and verdict are independent.

## 14. Anti-patterns

- Calling a failed simulation an architecture obstruction before resolving mesh, solver, and implementation errors.
- Replacing a mission endpoint with a residual norm without stability or exposure.
- Adding modes, sensors, mesh cells, or experiments without locating the binding distinction.
- Calibrating and validating on the same evidence without stating the limitation.
- Treating a numerical counterexample as a physical impossibility result.
- Treating a simulation as experimental validation.
- Using oracle regimes, parameters, or spectra in a branch advertised as deployable.
- Forcing an EG interpretation onto a unit error, wrong boundary condition, or missing physical mechanism.

## 15. Source and professional boundary

This canon is an operating guide, not a theorem source. For exact EG claims, use `engineering-analysis-source-router.md` and reread the routed chapter, proof appendix, or paper. For current algorithms, material properties, safety factors, regulatory requirements, and historical priority, use authoritative primary or official domain sources.

For safety- or regulation-critical decisions, obtain qualified review and required validation or certification. Structural resemblance to an EG example is not domain proof or professional approval.
