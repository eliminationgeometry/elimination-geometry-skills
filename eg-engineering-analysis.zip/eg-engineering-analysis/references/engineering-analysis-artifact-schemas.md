# EG Engineering-Analysis Artifact Schemas

Use these records only when they improve multi-turn work, handoff, reproducibility, or a high-consequence decision. Populate only relevant fields, preserve unknowns, and update an existing record instead of creating parallel versions.

## 1. Engineering-analysis state

```markdown
# EG Engineering-Analysis State: <system/project>

- Mode: model | diagnose | design | optimize | verify
- Verdict: ordinary | EG-structured | certified EG | unresolved
- Task, native metric, and units:
- Operating envelope and quantifiers:
- Local high-fidelity object:
- Shared model/design grammar:
- Earliest failing physical interface:
- Minimal admissible witness:
- Leading error account:
- Serious alternatives:
- Evidence grade: observed | reproduced | inferred | certified | validated | unresolved
- Intervention status: proposed | analyzed | simulated | experimentally tested | independently validated
- Next highest-information action:
- Models/configurations/data changed:
- Last updated:
```

## 2. Model and design card

```markdown
# Model and Design Card

## Engineering contract
- Prediction, control, or design decision:
- Native endpoint and units:
- Spatial, temporal, energetic, and statistical scales:
- Operating envelope, risk aggregation, and tolerances:
- Safety, admissibility, fabrication, and resource constraints:
- Available interventions:
- Falsifying outcome:

## Physical model
- Fine/source state:
- Retained state, descriptor, or representation:
- Governing equations or empirical law:
- Constitutive/closure assumptions:
- Initial, boundary, interface, loading, and forcing conditions:
- Geometry, materials, and lifecycle assumptions:
- Conservation, symmetry, positivity, passivity, or stability constraints:
- Discretization, solver, precision, and stopping rules:

## Local versus shared
- Context/load/regime variable:
- Locally adequate high-fidelity object:
- Shared/restricted model or design grammar:
- What may adapt:
- What must remain common:
- Task quotient / ignored distinctions:
- Suspected eliminated distinction:
- Native defect or diagnostic proxy:

## Evidence and observation
- Sensors/measurements/simulation outputs:
- Calibration evidence:
- Selection/tuning evidence:
- Reserved validation endpoint:
- Identifiability and uncertainty status:
- Transmission path to the task:
```

If no shared grammar exists, treat the issue as ordinary engineering. If no exact insertion or nonfactorization object exists, do not label a discrepancy a certified EG defect.

## 3. Physical witness record

```markdown
# Physical Witness Record: <ID>

- Target claim or failure:
- Context/load/path/regime A:
- Context/load/path/regime B:
- Why the shared model treats them equally:
- Why the engineering task requires different behavior:
- Units, geometry, loads, boundaries, resources, and admissibility held fixed:
- Eliminated distinction:
- Coupling/transmission path:
- Exposing observer and native metric:
- High-fidelity or experimental result:
- Shared-model result:
- Zero-obstruction or task-invisible control:
- Analytic/numerical/experimental status:
- Repair implied by the witness:
- Scope and nonclaims:
```

## 4. Simulation or experiment contract

```markdown
# Simulation or Experiment Contract

## Decision
- Competing mechanisms:
- Result favoring each mechanism:
- Result leaving the diagnosis unresolved:

## Physical contract
- Governing model and version:
- Geometry, materials, boundaries, loads, forcing, and initial state:
- Operating regime and nondimensional groups:
- Sensors/observables and calibration:
- Resource and safety constraints:

## Numerical/experimental conditions
- Mesh/basis/domain and timestep/quadrature:
- Solver, precision, initialization, tolerances, and stopping:
- Equipment, specimens, protocol, randomization, and blinding where applicable:
- Replicates, seeds, uncertainty model, and exclusions:

## Controls
- Local high-fidelity or oracle baseline:
- Exact/manufactured/limiting case:
- Mesh/timestep/tolerance convergence:
- Zero-obstruction control:
- Task-invisible/no-transmission control:
- Generic equal-resource intervention:

## Metrics and reproducibility
- Native task endpoint:
- Representation/closure discrepancy:
- Coupling/transmission metric:
- Conservation/admissibility checks:
- Uncertainty and robustness metrics:
- Commands/configuration/protocol:
- Raw outputs and metadata:
- Acceptance and failure thresholds:
- Frozen validation unit:
```

Prespecify the decision before an expensive, safety-relevant, or public mechanism claim.

## 5. Model or design change contract

```markdown
# Model or Design Change Contract

- Diagnosed witness and interface:
- Intended mechanism:
- Smallest proposed intervention:
- Equations, variables, closure, geometry, controller, sensors, or design affected:
- Units, conservation, admissibility, manufacturability, and safety invariants:
- Resources added or removed:
- Calibration consequences:
- Compatibility with existing models, data, tooling, or hardware:
- Out-of-scope behavior preserved:
- Test that must fail before and pass after:
- Generic alternative or negative control:
- Validation, fallback, and stop condition:
- Authorization boundary:
```

## 6. Verification matrix

```markdown
# Engineering Verification Matrix

| Layer | Claim | Test/evidence | Configuration | Result | Status |
|---|---|---|---|---|---|
| Units/types | | | | | pass/fail/not run |
| Governing law/conservation | | | | | |
| Exact/limiting/manufactured case | | | | | |
| Numerical convergence | | | | | |
| Witness exposure | | | | | |
| Matched intervention | | | | | |
| Equal-resource/negative control | | | | | |
| Sensitivity/uncertainty/envelope | | | | | |
| Independent experiment/field/hardware | | | | | |

Strongest conclusion authorized:
Calibration/selection reuse:
Skipped layers and rationale:
Remaining alternatives and nonclaims:
```

## 7. Engineering decision record

```markdown
# Engineering Decision Record: <short title>

- Decision:
- Date/model/version:
- Task, units, envelope, and constraints:
- Evidence considered:
- Minimal witness:
- Alternative accounts and interventions:
- Why the selected intervention is mechanism-matched:
- Resource, manufacturability, compatibility, and safety consequences:
- Verification completed:
- Deferred validation:
- Fallback or stop condition:
- Owner/qualified reviewer/approver when applicable:
```

This record documents analysis. It does not replace regulatory sign-off, organizational approval, or professional certification.
