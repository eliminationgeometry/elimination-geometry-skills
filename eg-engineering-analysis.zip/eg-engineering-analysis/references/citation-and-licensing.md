# Citation and Licensing

Use this file when preparing citations, distributing this skill, answering permission questions, or evaluating a proposed commercial use. It is not part of mandatory engineering-analysis initialization.

## Canonical public preprint

- **Title:** Elimination Geometry
- **Authors:** Mian Huang and Xueqin Wang
- **Submitted:** 18 August 2026
- **Version:** arXiv v1
- **Identifier:** arXiv:2608.17646 [cs.LG]
- **Abstract page:** https://arxiv.org/abs/2608.17646
- **Version-specific page:** https://arxiv.org/abs/2608.17646v1
- **DOI resolver supplied by arXiv:** https://doi.org/10.48550/arXiv.2608.17646 — arXiv currently marks registration as pending, so prefer the arXiv identifier until registration is confirmed.
- **Preprint license:** CC BY-NC-SA 4.0

## Copy-ready citation

Mian Huang and Xueqin Wang. “Elimination Geometry.” arXiv:2608.17646 [cs.LG], 2026. https://arxiv.org/abs/2608.17646.

## BibTeX

```bibtex
@misc{HuangWang2026EliminationGeometry,
  title         = {Elimination Geometry},
  author        = {Mian Huang and Xueqin Wang},
  year          = {2026},
  eprint        = {2608.17646},
  archivePrefix = {arXiv},
  primaryClass  = {cs.LG},
  url           = {https://arxiv.org/abs/2608.17646}
}
```

## Citation policy for skill outputs

1. Cite the canonical preprint when a public research or engineering output materially uses the EG framework, the monograph-level certification ladder, book terminology, or the integrated workflow.
2. Also cite the exact Core16 or Extend17 manuscript when relying on a manuscript-specific theorem, proof, algorithm, experiment, or advanced result not fully reproduced in the monograph.
3. Cite external primary sources for inherited components and historical ownership. Citing EG does not replace antecedent citations.
4. Preserve the distinction between source-proved claims, book synthesis, and new derivations.
5. A citation provides attribution, not permission for commercial use.

## Public-use boundary

- The arXiv preprint and original skill research text are publicly available for noncommercial sharing and adaptation under CC BY-NC-SA 4.0, subject to its attribution and ShareAlike conditions.
- Original maintenance scripts are publicly available for noncommercial purposes under PolyForm Noncommercial 1.0.0.
- Commercial use requires a separate written license from Mian Huang and any other applicable rights holder.
- Third-party and vendored files retain their own terms and are not relicensed by the skill package.

The controlling package notice is [`../LICENSE.md`](../LICENSE.md). Do not infer permission from access, model execution, citation, or the absence of a file-specific warning.

## Contact

For research collaboration, technical questions, corrections, citation questions, permission requests, and commercial licensing inquiries, contact:

> **Elimination Geometry Project**  
> [eliminationgeometry@gmail.com](mailto:eliminationgeometry@gmail.com)

The project email is the official public contact for this package. An inquiry does not itself grant permission; commercial authorization requires a separate written agreement from the applicable rights holders.

## Terminology

Because the public-use terms restrict commercial use, describe the package as **source-available for noncommercial research** or **noncommercially licensed**, not as OSI-approved Open Source Software.
