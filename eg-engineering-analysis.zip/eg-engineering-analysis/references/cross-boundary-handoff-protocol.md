# EG Cross-Boundary Handoff Protocol

This lightweight protocol is for scientific-computing, robotics, digital-twin, cyber-physical, and other tasks whose end-to-end claim crosses a physical/scientific model and a software implementation. The same file is bundled independently with both engineering skills. It does not require or authorize one skill to invoke the other.

## 1. When to use it

Load this protocol only when at least one material claim crosses the model–software boundary, for example:

- a physical variable is encoded, serialized, sampled, estimated, transformed, or controlled by software;
- numerical or runtime behavior may be confused with model-form or physical error;
- timing, state synchronization, units, coordinates, precision, version, or provenance can change the physical conclusion;
- validation must connect simulation, software-in-the-loop, hardware-in-the-loop, and a physical endpoint.

Do not load it for an ordinary one-sided task whose acceptance can be decided entirely from the physical model or entirely from the executable software contract.

## 2. Preserve one end-to-end task

Name one observer and one acceptance statement spanning both sides. Do not allow the model and software teams to optimize different proxies without an explicit exchange argument.

Keep these layers distinct:

```text
physical/source state
  -> mathematical or empirical model
  -> discretized/computational state
  -> software representation and protocol
  -> estimator/controller/decision
  -> actuator, user, or scientific observer
  -> end-to-end task loss
```

At each arrow, record what is eliminated, approximated, quantized, delayed, reordered, defaulted, or treated as equivalent.

## 3. Minimal interface contract

Record only fields relevant to the current boundary:

| Contract field | Required content |
|---|---|
| End-to-end task | observer, native metric, units, tolerance, operating envelope, and risk quantifier |
| Physical semantics | variable meaning, domain, admissible range, conservation/symmetry constraints, and failure meaning |
| Mathematical object | scalar/vector/tensor/field/distribution/state; continuous/discrete; deterministic/stochastic |
| Software representation | type, shape, schema, precision, missing/default semantics, encoding, and API/topic/file |
| Coordinates and units | unit system, sign/orientation, coordinate frame, basis, origin, handedness, and conversion owner |
| Time and order | clock, timestamp meaning, sampling rate, latency budget, synchronization, interpolation, event order, reset, and replay |
| State lifecycle | initialization, update, persistence, ownership, migration, stale-state rule, and fallback |
| Error contract | model-form, discretization, solver, estimation, quantization, transport, implementation, and measurement budgets |
| Uncertainty | aleatory/epistemic meaning, covariance or confidence semantics, correlations, calibration status, and propagation rule |
| Version and provenance | model, parameters, data, code, schema, hardware, calibration, configuration, and build identifiers |
| Runtime privilege | information available online versus labels, oracle states, true regimes, future data, or offline-only quantities |
| Validation endpoint | exact/limiting case, simulation, SIL, HIL, experiment, field test, or another independently frozen endpoint |

Unknown entries remain named obligations. Never silently choose units, frames, clocks, uncertainty meaning, or stale-state behavior.

## 4. Cross-boundary witnesses

Prefer the smallest pair or trace that the interface collapses but the end-to-end task distinguishes:

- two physical states map to the same serialized or retained state but require different predictions or actions;
- the same numeric array has different units, frames, bases, sign conventions, or timestamp meanings;
- two event histories produce the same current value but require different next updates;
- a delayed or stale estimate is accepted as current in one operating regime and unsafe in another;
- a model version and parameter set are individually valid but incompatible when deployed together;
- equal residuals or solver tolerances produce different physical task errors;
- simulation and hardware share an API while differing in saturation, latency, noise, reset, or failure semantics.

Trace the witness through the complete path. If it is annihilated before the declared observer, narrow the claim; if it survives, locate the earliest interface where the distinction became unavailable.

## 5. Cross-boundary error ledger

Do not hide these accounts inside one “model error” or “system error”:

| Account | Typical failure | Typical intervention |
|---|---|---|
| Physical/model form | missing dynamics, closure, constitutive law, boundary condition, or regime | revise the model or validity envelope |
| Discretization/numerics | unresolved mesh, timestep, basis, conditioning, tolerance, precision | resolve or change the numerical method |
| Representation/encoding | lost units, frame, order, precision, topology, uncertainty, or state | refine the type, schema, state, or encoding |
| Time/protocol | delay, jitter, clock drift, reordering, replay, stale data, non-idempotent update | repair synchronization, lifecycle, or protocol |
| Implementation/integration | code, conversion, API, concurrency, build, or hardware defect | fix and regression-test the implementation |
| Evidence/calibration | parameters, sensors, workloads, or experiments do not identify the cause | acquire evidence or retain unresolvedness |
| Deployment/operation | environment, hardware, resource, actuator, sensor, or configuration differs from validation | repair deployment or narrow the supported envelope |

Moving loss between accounts is not removing it. Every claimed exchange needs a bound, specification, measurement, or controlled experiment.

## 6. Handoff procedure

1. **Choose the lead boundary.** State whether the earliest unresolved question is model/physical or software/executable. Mixed subject matter alone does not determine the lead.
2. **Freeze the interface contract.** Record the fields above that affect the decision, including unknowns and owners.
3. **Export a boundary witness.** Make it reproducible as equations and data, a minimal input pair, a trace, a simulation configuration, or a test fixture.
4. **Audit without reinterpretation.** A receiving collaborator must not change units, frames, clocks, task metrics, uncertainty semantics, or operating envelope silently.
5. **Repair the earliest binding interface.** Prefer the smallest physical, numerical, representation, protocol, or code change selected by the witness.
6. **Return evidence in the same contract.** Include exact versions, conditions, results, failures, oracle privileges, and remaining alternatives.
7. **Verify end to end.** Recheck that the improvement reaches the original observer rather than only an internal proxy.

The contract may pass between people, turns, or tools. Passing it does not grant permission to edit code, run hardware, deploy, purchase, or perform experiments.

## 7. Verification ladder

Use the layers needed by the claim and state omissions:

1. dimensional, coordinate, type, range, and schema checks;
2. model law, invariant, exact case, or limiting-case check;
3. encode/decode and unit/frame round-trip tests;
4. discretization, tolerance, precision, determinism, and platform checks;
5. interface, timing, replay, stale-state, migration, and fault tests;
6. software-in-the-loop under the declared information contract;
7. hardware-in-the-loop with sensor, actuator, latency, saturation, and failure semantics;
8. independently frozen experiment, field data, hardware trial, or operational endpoint.

A simulation-only success cannot establish hardware or physical validity. HIL cannot establish model truth outside its calibrated envelope. A field test without version and configuration provenance is not reproducible validation.

## 8. Stop rules

- Units, frames, timestamp meaning, state ownership, or version pairing are unknown and material: stop the cross-boundary conclusion.
- Model and software optimize different endpoints: state the mismatch before comparing performance.
- Error budgets overlap, omit a material account, or exceed the end-to-end tolerance: do not declare acceptance.
- A runtime branch uses oracle or offline-only information: label it an audit, not a deployable mechanism.
- Only an internal proxy improves: do not claim end-to-end repair without transmission to the observer.
- Selection, calibration, and validation reuse the same evidence: state the limitation.
- Safety- or regulation-critical use lacks current standards, qualified review, or required validation: do not issue approval.

## 9. Compact handoff record

```text
End-to-end task, observer, metric, units, and envelope:
Lead boundary: model/physical | software/executable | unresolved
Physical state and governing assumptions:
Computational state and discretization:
Software representation, API, and lifecycle:
Units, frames, clocks, order, and synchronization:
Error and uncertainty budget by account:
Model/data/code/schema/hardware versions and provenance:
Minimal cross-boundary witness and transmission path:
Runtime information versus oracle privilege:
Smallest matched intervention:
Verification completed: analytic | numerical | interface | SIL | HIL | physical
Strongest supported conclusion and remaining nonclaims:
Next highest-information action:
```
