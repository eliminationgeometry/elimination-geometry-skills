# EG Engineering-Analysis Source Router

Use this router only when an engineering-analysis answer needs an exact EG definition, theorem, proof, algorithm, provenance statement, or corpus-backed comparison. The canon and playbook are sufficient for ordinary analysis. A route identifies where to reread; it is not evidence by itself.

## 1. Source authority

1. Use `engineering-analysis-canon.md` for the practical operating method.
2. Use `monograph-canon.md` and `validation-dependency-map.md` for current book organization and gate semantics.
3. Use exact monograph chapters and proof appendices for book-proved statements.
4. Use exact Core16 or Extend17 TeX for manuscript-specific variants, algorithms, experiments, and results summarized by the book.
5. Use current primary literature, official standards, material databases, and qualified domain sources for physical laws, algorithms, properties, safety, compliance, and historical priority.
6. Use simulations and reproducibility artifacts only within their stated model, oracle, discretization, data, and validation contracts.

Do not infer transfer because two fields use the same formula. Compare task, units, eliminated object, grammar, quantifiers, transmission, theorem consequence, and evidence.

## 2. Monograph routes for engineering analysis

| Engineering need | Primary monograph route |
|---|---|
| local model/design works, shared object fails | Chapters 1–2 |
| separate model, architecture, evidence, numerics, and implementation | Chapter 3 |
| physical coarse-graining and shared-decision examples | Chapter 4 |
| native Bregman, KL, free-energy, saddle, or profile defects | Chapter 5 |
| pointwise, plug-in, exactified, variational, and coupling branches | Chapter 6 |
| stale/approximate fields and exactification certificates | Chapter 7 |
| smoothing, probability validity, and proper-score constructions | Chapter 8 |
| local residual consistency, integrability, and Hodge repair | Chapter 9 |
| representation integrity and visible complexity | Chapter 10 |
| class obstruction, saturation, and class-versus-solver diagnosis | Chapter 11 |
| metric/flow transport from local variation to native loss | Chapter 12 |
| shared decisions, rectangularity, controllers, and memory | Chapter 13 |
| branches, singularities, discriminants, roots, and eigenlines | Chapter 14 |
| state, chart, quotient, and randomized repair | Chapter 15 |
| modes, sensors, states, compute, carrier loss, and decoder saturation | Chapter 16 |
| pipelines, ordering, replacement, and task visibility | Chapter 17 |
| repeated elimination, composition, base change, and limits | Chapter 18 |
| finite-data confidence worlds and common engineering decisions | Chapter 19 |
| evidence resolution and recursive certificate state | Chapter 20 |
| typed structural learning and scientific-ML systems | Chapter 21 |
| saturation, diagnosis, matched repair, and validation | Chapter 22 |
| partial transport, cycles, holonomy, and recovery | Chapter 23 |
| applied mechanism laboratories and empirical boundaries | Chapter 24 |
| quantum/noncommutative systems and Gibbs base change | Chapter 25 |
| structural stopping boundaries | Chapter 26 |
| falsifiable research programs | Chapter 27 |

Use `monograph-structure-index.md` to locate exact statements and proof files. Read Appendix E for dependency wording and Appendix F for controlled terminology when needed.

## 3. Core16 routes

### Elimination, validity, and exactification

- `core16/eg1.tex`: primitive elimination, insertion defects, and P/G/X/V/C design contracts.
- `core16/eg2.tex`: integrability, representation integrity, semantic validity, converses, and leverage.
- `core16/x_algo.tex`: stale and approximate fields, local rates, Schur-channel deflation, Ritz certificates, switching, and operational experiments.

Use for reduced or surrogate models, profile/nuisance elimination, locally optimized auxiliary fields, stale closures or inner solves, spectral slow modes, and certified acceleration. Search external multifidelity, surrogate, variable-projection, MM/EM, preconditioning, deflation, and numerical-linear-algebra literature for ancestry and current methods.

### Composition, reduction, and dynamics

- `core16/eg3.tex`: hard/soft path composition, conditional KL, refinement, base change, and temperature.
- `core16/foundation.tex`: defect fibrations, towers, curvature, coherence, and abstract composition.
- `core16/operation.tex`: task envelopes, safe replacement, order, and operational resolution.

Use for multistage reduction, chained models, repeated coarse-graining, path laws, replacement of submodels, and local guarantees that may not assemble globally.

### Obstructions and singular regimes

- `core16/eot.tex`: metric, graph-flow, topological, packing, and incompatibility transfer into native lower bounds.
- `core16/cot.tex`: shared decisions, rectangularity, coordination, and architecture choice.
- `core16/singular.tex`: branches, discriminants, singular oracle geometry, and catastrophe taxes.
- `core16/quantum.tex`: noncommutative base change, quantum relative entropy, measurement limitations, and rigidity.

Use for incompatible load/operating regimes, topology, branch changes, eigenline or spectral problems, singularities, shared controls, and quantum systems.

### Representation, resources, sensing, and evidence

- `core16/lift.tex`: extended formulations, padding/target-calling no-go results, target-visible capacity, and computation-to-defect interfaces.
- `core16/architecture.tex`: deployment/evidence/recursive carriers, native rate–distortion, transmission, exposure, and common actions.
- `core16/statistical.tex`: confidence worlds, simultaneous transport, architecture certificates, and detectability.
- `core16/certificate_stat.tex`: resolution, evidence carriers, posterior guidance, and recursive certificate state.
- `core16/egml.tex`, `core16/egml2.tex`: static and adaptive model/architecture/evidence audits, acquisition, and structural repair.

Use for reduced bases, sensor layouts, measurement compression, common models under uncertainty, adaptive experiments, finite evidence, and resource-aware design.

## 4. Extend17 routes

### Information, sensing, and acquisition

- `extend17/deployment_info.tex`
- `extend17/certificate_info.tex`
- `extend17/recursive.tex`
- `extend17/wavelet_acquisition.tex`

Use for sensor/representation design, task-relative compression, active sampling, evidence resolution, recursive state, and communication–sample tradeoffs.

### Control, strategic, and multi-agent systems

- `extend17/Strategic_Regret_Geometry.tex`
- `extend17/Recursive_Strategic_Elimination.tex`

Use for shared strategies, information-limited play, recursive strategic state, regret, and multi-agent deployment. Pair with current control, robotics, game-theory, or mechanism-design literature.

### Time, memory, closure, and reduced dynamics

- `extend17/timescale_eg.tex`
- `extend17/dependent.tex`
- `extend17/long_memory_forecasting.tex`
- `extend17/Mori_Zwanzig_Elimination_Geometry.tex`
- `extend17/task_visible.tex`

Use for history elimination, finite-memory state, multiscale dynamics, Mori–Zwanzig closure, recursive updating, and task-visible order or degree.

### Statistical physics and diffusion

- `extend17/Task_Conditioned_Renormalization.tex`
- `extend17/continuous.tex`
- `extend17/Hidden_Entropy_Production.tex`

Use for coarse-graining, free energy, diffusion, entropy production, renormalization, path-space loss, and task-conditioned macrostates.

### Operational and event-order systems

- `extend17/queue.tex`
- `extend17/microstructure_event_order.tex`
- `extend17/execution_visible_market_states.tex`

Use for queues, scheduling, event order, state-space collapse, and sequential operational decisions when these structures are part of the physical or control system.

## 5. Domain transfer rule

For materials, structures, fluids, waves, optics, acoustics, electromagnetics, plasma, chemistry, energy, process systems, controls, robotics, Earth systems, biology, medicine, and other engineering domains:

1. define the native task, units, scale, and validity envelope;
2. identify the fine, hidden, historical, nuisance, or local object actually eliminated;
3. state the shared closure, model, controller, sensor, design, or resource grammar;
4. identify a task-visible witness and transmission path;
5. select the nearest EG source route;
6. search current domain primary literature and standards using native terminology;
7. label transferred statements as proved, derived, conjectural, or analogical at the correct scope.

Useful external search families include homogenization, multiscale and reduced-order modeling, constitutive reduction, closure and memory kernels, numerical error estimation, inverse problems and identifiability, experiment design, robust and switched control, turbulence, wave propagation, effective media, multiphysics coupling, digital twins, uncertainty quantification, verification, and validation.

## 6. Exact-source loading rule

Reread exact sources before stating:

- a definition, formula, theorem, assumption, constant, rate, proof step, or algorithm guarantee;
- that the monograph proves rather than summarizes a result;
- that an EG mechanism transfers to a new engineering domain;
- a novelty, priority, standards, safety, or state-of-the-art claim;
- a numerical value, property, benchmark result, oracle privilege, or validation conclusion;
- publication-ready technical prose or citations.

For book results, read the statement, assumptions, interpretation, proof roadmap, and proof appendix. For manuscript results, read the exact TeX, experiment, and bibliography sections. For engineering practice, verify against current primary or official sources even when EG supplies the structural interface.
