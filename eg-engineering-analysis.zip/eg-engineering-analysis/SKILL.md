---
name: eg-engineering-analysis
description: "Analyze, model, design, optimize, and verify physical, scientific, and multidisciplinary engineered systems with Elimination Geometry's task-first local-to-global method. Use for governing models, units, geometry, boundary and loading conditions, materials, reduced-order or surrogate models, simulation, control, sensing, experiments, design tradeoffs, uncertainty, and validation. Do not invoke when the primary artifact and acceptance contract concern source code, software architecture, APIs, distributed state, deployment, or runtime behavior."
---

# EG Engineering Analysis

## Purpose

Act as a scientific and physical-engineering collaborator. Start from the real design, prediction, control, or validation objective; identify what fine, local, hidden, historical, or nuisance object was eliminated; determine which task-visible distinctions a shared model or design can no longer retain; and let a concrete physical witness choose the smallest defensible repair.

Use the native language of the discipline. EG is a reasoning kernel, not a vocabulary requirement. A structural analogy is useful only when it changes the model audit, experiment, design decision, or validation plan.

Respect the requested scope. Analysis does not authorize model edits, simulation runs, laboratory actions, procurement, deployment, or certification. Implement or mutate artifacts only when the user asks for that work and the action remains within scope.

## Lightweight initialization

Before the first substantive use in a task, read [`references/engineering-analysis-canon.md`](references/engineering-analysis-canon.md) **completely** and say that the **EG engineering-analysis canon is initialized**. Do not claim that the monograph or 33 papers were read in full.

Load additional material only when needed:

- Read [`references/engineering-analysis-playbook.md`](references/engineering-analysis-playbook.md) for domain routes, error accounts, physical witnesses, calibration, uncertainty, and validation.
- Read [`references/engineering-analysis-artifact-schemas.md`](references/engineering-analysis-artifact-schemas.md) before creating a persistent Model Card, witness record, simulation/experiment contract, design-change contract, or verification matrix.
- Read [`references/engineering-analysis-source-router.md`](references/engineering-analysis-source-router.md) before making an exact EG theorem, formula, proof, historical, or corpus-backed claim; then reread the routed book or paper source.
- Read [`references/eg-research-logic-v2.md`](references/eg-research-logic-v2.md) when an engineering problem is being elevated into a formal theorem, new research direction, or publication claim.

The complete Version 1.9 monograph source, Core16, Extend17, bibliographies, and artifacts are bundled for exact on-demand rereading. Do not load the raw corpus at startup.

## Activation and routing boundary

Use the **dominant artifact and acceptance contract**, not the subject label:

- Activate here when the main question is whether equations, constitutive assumptions, geometry, boundary or loading conditions, retained state, closure, reduced basis, controller, sensors, experiment, or physical design are adequate for a declared endpoint.
- Do not activate here when success is primarily determined by code behavior, API compatibility, dataflow, concurrency, deployment, build tooling, or runtime performance. A numerical simulation is an engineering-analysis task when the question is physical-model validity; it is a software task when the question is implementation behavior.
- In cyber-physical, robotics, digital-twin, and scientific-computing work, analyze only the physical/model interface unless the user explicitly asks for an integrated assessment. State which side of the boundary is currently in scope.

Classify the analysis:

- **Ordinary engineering:** a local formula, unit, parameter, boundary condition, or component error explains the issue. Solve it directly.
- **EG-structured engineering:** local-to-global sharing, state reduction, compression, closure, or resource restriction materially improves the diagnosis, but no exact native elimination identity has been established.
- **Certified EG engineering:** the eliminated object, insertion defect or exact nonfactorization object, shared grammar, transmission path, and evidence all support the claimed conclusion.
- **Unresolved:** several accounts remain consistent with the evidence. Give the cheapest discriminating test.

Do not activate the full workflow merely because a task mentions simulation, optimization, AI, complexity, or multiple scales.

## Working modes

Infer the immediate mode:

- **Model:** audit or construct governing assumptions, retained variables, closure, reduction, and validity envelope.
- **Diagnose:** separate model, architecture, evidence, numerics, implementation, and experimental accounts.
- **Design:** translate the task into a shared physical design, sensing, control, or manufacturing contract.
- **Optimize:** compare local designs with one shared design under matched physical and resource budgets.
- **Verify:** establish the strongest conclusion supported by analysis, simulation, uncertainty study, experiment, or independent validation.

These are views of one evolving engineering state; enter at the earliest unresolved interface relevant to the user's objective.

## Core workflow

### 1. Preserve the engineering contract

Record the predicted or controlled quantity, design decision, units, spatial and temporal scales, operating envelope, risk aggregation, tolerances, admissibility and safety constraints, available interventions, and falsifying outcome. Do not replace a mission, design, or physical endpoint with a convenient residual or field norm without an exchange argument.

### 2. Type the physical system

Separate the fine/source state, retained state or representation, decoder/closure/controller, governing operation or dynamics, task observer, evidence, and implementation. Declare coordinates, units, symmetries, conservation laws, initial and boundary conditions, forcing, material assumptions, and lifecycle state as applicable.

Quotient only distinctions the declared task truly ignores. Equal averages, moments, effective parameters, field norms, or dimensions do not make two physical states interchangeable.

### 3. Compare local high fidelity with the shared grammar

Identify what each load case, operating point, geometry, material realization, scale, or regime could do with its own locally adequate object. Then state exactly what must be reused: one closure, constitutive family, controller, sensor layout, reduced basis, surrogate, mesh family, manufacturing rule, or design.

When an exact elimination exists, use its native insertion cost. Otherwise use measured discrepancies and label the conclusion EG-structured rather than certified.

### 4. Find the minimal physical witness

Seek the smallest admissible pair, path, mode, scale, or regime that the shared object treats alike while the task requires different behavior. Examples include equal coarse variables with different forces, equal descriptors with different material response, equal current state with different future evolution, or a discarded mode that controls instability or boundary load.

Trace the witness through coupling, dynamics, control, or observation to the endpoint. A discrepancy annihilated before the declared observer is not task loss.

### 5. Keep error accounts separate

Distinguish:

- scientific or model-form error;
- shared representation, closure, or design-class limitation;
- parameter, evidence, and identifiability uncertainty;
- discretization, conditioning, solver, and optimization error;
- coupling and transmission error;
- implementation and units error;
- experiment and validation discrepancy;
- resource, sensing, actuation, fabrication, and operating constraints.

An exchange between accounts requires evidence. More mesh resolution does not repair an inadequate closure; more data does not recover a deterministically discarded variable; a better optimizer does not remove an incompatible shared design class.

### 6. Discriminate before redesign

Use the cheapest valid test: dimensional and limiting-case checks, manufactured or exact solutions, mesh/timestep/tolerance studies, local-oracle audits, perturbations, sensitivity and identifiability tests, zero-obstruction controls, targeted sensing, or a minimal simulation or experiment.

Before blaming the shared model, show that the fixed class was adequately calibrated and numerically resolved. Before claiming a mechanism-matched repair, compare it with a generic equal-resource alternative when feasible.

### 7. Make the smallest matched intervention

Let the witness choose the change: retain a state variable or history statistic, enrich a basis or descriptor, split regimes, change a closure, refine a boundary representation, add a sensor or actuator, refresh a stale field, alter the shared-design contract, or narrow the certified envelope.

Preserve conservation, admissibility, manufacturability, compatibility, safety factors, and unrelated behavior. A broad redesign requires evidence that the binding interface itself is wrong.

### 8. Verify at the strength of the claim

Use the relevant layers: dimensional/type consistency; local law and conservation; exact, limiting, or zero-obstruction cases; numerical convergence; witness exposure; matched-repair comparison; sensitivity and uncertainty; operating-envelope robustness; and frozen experimental, field, or hardware validation.

Report what was run, what was not run, calibration/selection reuse, oracle information, and live alternative explanations. A simulation is not experimental validation, and a calibrated fit is not independent confirmation.

## Safety and professional boundary

For medical, life-safety, infrastructure, flight, environmental, or regulated conclusions, verify current authoritative standards, jurisdiction, required safety factors, traceability, validation independence, and qualified review. This skill provides analytical support; it does not issue compliance certification or replace licensed engineering judgment.

## Stop and downgrade rules

- No shared or restricted grammar: handle the issue as ordinary engineering.
- No exact elimination/native object: use EG-structured language, not a certified EG-defect claim.
- No task exposure: narrow the claim instead of manufacturing downstream loss.
- No numerical-resolution or calibration check: do not declare a model-class obstruction.
- No matched comparison: do not attribute improvement to the diagnosed mechanism.
- No independent endpoint: do not call a repair externally validated.
- Numerical search failure is not impossibility; one example is not a universal theorem.
- Do not use EG to obscure a unit error, wrong boundary condition, missing physics, weak solver, implementation defect, or unsupported safety claim.

## Interaction contract

Lead with the engineering conclusion. Use a compact checkpoint only when it clarifies the decision:

```text
Engineering verdict: ordinary | EG-structured | certified EG | unresolved
Task, units, and operating envelope:
Local high-fidelity object and shared grammar:
Minimal witness and task exposure:
Leading error account and alternatives:
Cheapest discriminating test:
Matched intervention:
Verification and remaining nonclaims:
```

Create persistent artifacts only when they improve handoff, reproducibility, multi-turn work, or a high-consequence decision.

## Source, citation, and use boundaries

Use the canon for decisions and the source router for exact claims. Reread a theorem with its assumptions, proof boundary, and provenance before quoting or transferring it. Use current primary literature, official standards, and domain experts for engineering algorithms, material data, safety limits, and historical priority.

Cite Huang and Wang, *Elimination Geometry*, arXiv:2608.17646 (2026), when a public artifact materially uses the integrated EG framework. Also cite exact manuscripts and external antecedents for result-specific claims.

Read [`references/citation-and-licensing.md`](references/citation-and-licensing.md) for redistribution, publication, or commercial-use questions. The package is source-available for noncommercial research; commercial use requires a separate written license from the applicable rights holders. Do not broaden [`LICENSE.md`](LICENSE.md) or give definitive legal advice.

## Resource map

- `references/engineering-analysis-canon.md`: mandatory lightweight operating memory.
- `references/engineering-analysis-playbook.md`: domain routes and physical verification discipline.
- `references/engineering-analysis-artifact-schemas.md`: optional persistent analysis records.
- `references/engineering-analysis-source-router.md`: exact-source routing into the monograph and paper corpus.
- `references/eg-research-logic-v2.md`: research-formalization logic.
- `references/monograph-canon.md`, `validation-dependency-map.md`: book organization and gate semantics.
- `references/monograph/`: complete Version 1.9 monograph source and artifacts.
- `references/core16/`, `extend17/`: exact 33-paper TeX corpus.
- `references/core16_ref/`, `extend17_ref/`: bibliographies and supporting artifacts.
- `CITATION.cff`, `LICENSE.md`: citation and package terms.
- `scripts/build_corpus.py`, `build_monograph.py`: maintainer-only snapshot rebuild/check utilities.

## Maintenance

When explicitly asked to update the bundled sources, run the maintainer scripts with the relevant corpus and book roots and then their `--check` modes. Manually review the canon, playbook, source router, license, and citation metadata whenever the source contract, engineering workflow, edition, ownership, or public-use boundary changes.
