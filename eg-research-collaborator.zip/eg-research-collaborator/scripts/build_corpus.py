#!/usr/bin/env python3
"""Build and verify the self-contained EG corpus bundled with eg-research-collaborator.

This is a maintainer utility, not part of the normal question-answering path.
It copies the canonical TeX/Bib sources, builds a source manifest, extracts all
extension abstracts, and builds a line-addressable structure/statement index
for the core papers.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Paper:
    filename: str
    short_name: str
    field: str = "Core"


CORE_PAPERS = (
    Paper("eg1.tex", "Elimination Geometry I"),
    Paper("eg2.tex", "Elimination Geometry II"),
    Paper("x_algo.tex", "Exactification and Optimization Certificates"),
    Paper("eg3.tex", "Elimination Geometry III"),
    Paper("eot.tex", "Elimination Obstruction Transfer"),
    Paper("cot.tex", "Compositional Obstruction Transfer"),
    Paper("foundation.tex", "Foundations of Elimination Geometry"),
    Paper("quantum.tex", "Quantum Elimination Geometry"),
    Paper("singular.tex", "Singular Elimination Geometry"),
    Paper("lift.tex", "Lift Complexity"),
    Paper("operation.tex", "Operational Semantics"),
    Paper("statistical.tex", "Statistical Elimination Geometry"),
    Paper("certificate_stat.tex", "Certificate Statistics"),
    Paper("architecture.tex", "Resource-Constrained Architectures"),
    Paper("egml.tex", "EG for Machine Learning and AI"),
    Paper("egml2.tex", "EG for Adaptive Learning Systems"),
)

EXTENSION_PAPERS = (
    Paper("deployment_info.tex", "Deployment Information Radius", "Information theory and certificate design"),
    Paper("certificate_info.tex", "Certificate Information Bottleneck", "Information theory and certificate design"),
    Paper("recursive.tex", "Recursive Rate--Distortion", "Information theory and certificate design"),
    Paper("wavelet_acquisition.tex", "Certificate-Directed Wavelet Acquisition", "Information theory and certificate design"),
    Paper("Strategic_Regret_Geometry.tex", "Information-Limited Strategic Regret", "Game theory and strategic learning"),
    Paper("Recursive_Strategic_Elimination.tex", "Recursive Strategic State Compression", "Game theory and strategic learning"),
    Paper("timescale_eg.tex", "Time--Scale Elimination Geometry", "Time series, dependence, and dynamical closure"),
    Paper("dependent.tex", "Dependent Elimination Geometry", "Time series, dependence, and dynamical closure"),
    Paper("long_memory_forecasting.tex", "Fractional-Memory Forecasting", "Time series, dependence, and dynamical closure"),
    Paper("Mori_Zwanzig_Elimination_Geometry.tex", "Mori--Zwanzig Closure", "Time series, dependence, and dynamical closure"),
    Paper("task_visible.tex", "Projected Return-Kernel McMillan Degree", "Time series, dependence, and dynamical closure"),
    Paper("Task_Conditioned_Renormalization.tex", "Task-Conditioned Renormalization", "Statistical physics, diffusion, and renormalization"),
    Paper("continuous.tex", "Path-Space Distillation Taxes", "Statistical physics, diffusion, and renormalization"),
    Paper("Hidden_Entropy_Production.tex", "Hidden Entropy Production", "Statistical physics, diffusion, and renormalization"),
    Paper("queue.tex", "Task-Visible State-Space Collapse", "Queueing and market microstructure"),
    Paper("microstructure_event_order.tex", "Event-Order Geometry of Limit Order Books", "Queueing and market microstructure"),
    Paper("execution_visible_market_states.tex", "Execution-Visible Market States", "Queueing and market microstructure"),
)

STATEMENT_ENVS = (
    "definition",
    "assumption",
    "theorem",
    "proposition",
    "lemma",
    "corollary",
    "remark",
    "example",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def extract_balanced(text: str, start: int, opening: str, closing: str) -> tuple[str, int]:
    if start >= len(text) or text[start] != opening:
        return "", start
    depth = 0
    for index in range(start, len(text)):
        char = text[index]
        if char == opening and (index == 0 or text[index - 1] != "\\"):
            depth += 1
        elif char == closing and (index == 0 or text[index - 1] != "\\"):
            depth -= 1
            if depth == 0:
                return text[start + 1 : index], index + 1
    return text[start + 1 :], len(text)


def line_number(text: str, position: int) -> int:
    return text.count("\n", 0, position) + 1


def normalize_inline(value: str) -> str:
    value = re.sub(r"%[^\n]*", " ", value)
    value = re.sub(r"\\\\(?:\[[^]]*\])?", " ", value)
    value = re.sub(r"\\(?:Large|large|bfseries|textbf|emph|textit)\b", " ", value)
    value = value.replace("~", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def extract_title(text: str) -> str:
    marker = "\\title"
    start = text.find(marker)
    if start < 0:
        return "Untitled"
    brace = text.find("{", start + len(marker))
    title, _ = extract_balanced(text, brace, "{", "}")
    return normalize_inline(title)


def extract_abstract(text: str) -> str:
    match = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", text, re.DOTALL)
    if not match:
        return "[No abstract found.]"
    return match.group(1).strip()


def extract_commands(text: str, commands: tuple[str, ...]) -> list[tuple[int, str, str]]:
    command_pattern = "|".join(re.escape(command) for command in commands)
    pattern = re.compile(r"\\(" + command_pattern + r")(\*?)\s*\{")
    output: list[tuple[int, str, str]] = []
    for match in pattern.finditer(text):
        brace = text.find("{", match.start())
        value, _ = extract_balanced(text, brace, "{", "}")
        output.append((line_number(text, match.start()), match.group(1), normalize_inline(value)))
    return output


def extract_statements(text: str) -> list[tuple[int, str, str]]:
    env_pattern = "|".join(STATEMENT_ENVS)
    pattern = re.compile(r"\\begin\{(" + env_pattern + r")\}")
    output: list[tuple[int, str, str]] = []
    for match in pattern.finditer(text):
        cursor = match.end()
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        title = ""
        if cursor < len(text) and text[cursor] == "[":
            title, _ = extract_balanced(text, cursor, "[", "]")
        output.append(
            (line_number(text, match.start()), match.group(1).capitalize(), normalize_inline(title))
        )
    return output


def selected_files(source: Path, suffixes: tuple[str, ...] | None) -> list[Path]:
    return [
        path
        for path in sorted(source.iterdir())
        if path.is_file()
        and not path.name.startswith(".")
        and (suffixes is None or path.suffix in suffixes)
    ]


def copy_tree_files(
    source: Path, destination: Path, suffixes: tuple[str, ...] | None
) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for existing in destination.iterdir():
        if existing.is_file():
            existing.unlink()
    for path in selected_files(source, suffixes):
        shutil.copy2(path, destination / path.name)


def write_manifest(reference_dir: Path) -> None:
    source_dirs = ("core16", "extend17", "core16_ref", "extend17_ref")
    lines = [
        "# EG Corpus Source Manifest",
        "",
        "> Generated by `scripts/build_corpus.py`. Do not edit by hand.",
        "",
        "The SHA-256 hashes identify the exact source snapshot bundled with this skill.",
        "",
        "| Bundled path | Bytes | Words | SHA-256 |",
        "|---|---:|---:|---|",
    ]
    for dirname in source_dirs:
        directory = reference_dir / dirname
        if not directory.exists():
            continue
        for path in sorted(directory.iterdir()):
            if not path.is_file():
                continue
            text = path.read_text(errors="replace")
            words = len(text.split())
            relative = path.relative_to(reference_dir)
            lines.append(f"| `{relative}` | {path.stat().st_size} | {words} | `{sha256(path)}` |")
    lines.append("")
    (reference_dir / "source-manifest.md").write_text("\n".join(lines))


def write_core_structure_index(reference_dir: Path) -> None:
    lines = [
        "# Core16 Structure and Statement Index",
        "",
        "> Generated from the complete bundled TeX sources. Use this index to locate the exact source before making theorem-level claims. The titles below are locators, not substitutes for hypotheses or proofs.",
        "",
        "## Contents",
        "",
    ]
    for number, paper in enumerate(CORE_PAPERS, 1):
        lines.append(f"{number}. [{paper.short_name}](#core-{number:02d})")
    lines.append("")

    for number, paper in enumerate(CORE_PAPERS, 1):
        path = reference_dir / "core16" / paper.filename
        text = path.read_text()
        title = extract_title(text)
        lines.extend(
            [
                f"## Core {number:02d}",
                "",
                f"**Paper:** {title}  ",
                f"**Exact source:** [`core16/{paper.filename}`](core16/{paper.filename})",
                "",
                "### Section map",
                "",
            ]
        )
        for lineno, command, heading in extract_commands(
            text, ("section", "subsection", "subsubsection")
        ):
            indent = {"section": "-", "subsection": "  -", "subsubsection": "    -"}[command]
            lines.append(f"{indent} L{lineno}: {heading}")
        lines.extend(["", "### Named statements", ""])
        for lineno, kind, heading in extract_statements(text):
            display = f" — {heading}" if heading else ""
            lines.append(f"- L{lineno}: **{kind}**{display}")
        lines.append("")

    (reference_dir / "core-structure-index.md").write_text("\n".join(lines))


def write_core_abstracts(reference_dir: Path) -> None:
    lines = [
        "# Core16 Full Abstracts",
        "",
        "> Generated from all 16 bundled TeX sources in canonical reading order. Load this file completely during corpus initialization, after `core-canon.md`.",
        "",
        "## Contents",
        "",
    ]
    for number, paper in enumerate(CORE_PAPERS, 1):
        lines.append(f"{number}. {paper.short_name} — `core16/{paper.filename}`")
    lines.extend(["", "---", ""])
    for number, paper in enumerate(CORE_PAPERS, 1):
        path = reference_dir / "core16" / paper.filename
        text = path.read_text()
        title = extract_title(text)
        abstract = extract_abstract(text)
        lines.extend(
            [
                f"## Core {number:02d}: {paper.short_name}",
                "",
                f"**Full title:** {title}  ",
                f"**Exact source:** [`core16/{paper.filename}`](core16/{paper.filename})",
                "",
                "### Abstract",
                "",
                abstract,
                "",
            ]
        )
    (reference_dir / "core16-abstracts.md").write_text("\n".join(lines))


def write_extension_abstracts(reference_dir: Path) -> None:
    lines = [
        "# Extend17 Abstracts and Domain Router",
        "",
        "> Generated from all 17 bundled TeX sources. Load this file completely during corpus initialization.",
        "",
        "## Contents",
        "",
    ]
    current_toc_field = None
    toc_field_index = 0
    toc_paper_index = 0
    for paper in EXTENSION_PAPERS:
        if paper.field != current_toc_field:
            current_toc_field = paper.field
            toc_field_index += 1
            toc_paper_index = 0
            lines.append(f"{toc_field_index}. **{paper.field}**")
        toc_paper_index += 1
        lines.append(f"   - {toc_field_index}.{toc_paper_index} {paper.short_name} — `extend17/{paper.filename}`")
    lines.extend(["", "---", ""])
    current_field = None
    field_index = 0
    paper_index = 0
    for paper in EXTENSION_PAPERS:
        if paper.field != current_field:
            current_field = paper.field
            field_index += 1
            paper_index = 0
            lines.extend([f"## {field_index}. {current_field}", ""])
        paper_index += 1
        path = reference_dir / "extend17" / paper.filename
        text = path.read_text()
        title = extract_title(text)
        abstract = extract_abstract(text)
        lines.extend(
            [
                f"### {field_index}.{paper_index} {paper.short_name}",
                "",
                f"**Full title:** {title}  ",
                f"**Exact source:** [`extend17/{paper.filename}`](extend17/{paper.filename})",
                "",
                "#### Abstract",
                "",
                abstract,
                "",
                "#### Full-text loading rule",
                "",
                "Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.",
                "",
            ]
        )
    (reference_dir / "extend17-abstracts.md").write_text("\n".join(lines))


def build(corpus_root: Path, skill_root: Path) -> None:
    reference_dir = skill_root / "references"
    reference_dir.mkdir(parents=True, exist_ok=True)
    copy_tree_files(corpus_root / "core16", reference_dir / "core16", (".tex",))
    copy_tree_files(corpus_root / "extend17", reference_dir / "extend17", (".tex",))
    copy_tree_files(corpus_root / "core16_ref", reference_dir / "core16_ref", None)
    copy_tree_files(corpus_root / "extend17_ref", reference_dir / "extend17_ref", None)
    write_core_abstracts(reference_dir)
    write_core_structure_index(reference_dir)
    write_extension_abstracts(reference_dir)
    write_manifest(reference_dir)


def check(corpus_root: Path, skill_root: Path) -> bool:
    pairs: list[tuple[Path, Path]] = []
    errors: list[str] = []
    for dirname, papers in (("core16", CORE_PAPERS), ("extend17", EXTENSION_PAPERS)):
        for paper in papers:
            canonical = corpus_root / dirname / paper.filename
            bundled = skill_root / "references" / dirname / paper.filename
            if not canonical.exists():
                errors.append(f"missing canonical paper: {canonical}")
            if not bundled.exists():
                errors.append(f"missing bundled paper: {bundled}")

    for dirname, suffixes in (
        ("core16", (".tex",)),
        ("extend17", (".tex",)),
        ("core16_ref", None),
        ("extend17_ref", None),
    ):
        source_dir = corpus_root / dirname
        bundled_dir = skill_root / "references" / dirname
        for source in selected_files(source_dir, suffixes):
            pairs.append((source, bundled_dir / source.name))

    for source, bundled in pairs:
        if not bundled.exists():
            errors.append(f"missing bundled file: {bundled}")
        elif sha256(source) != sha256(bundled):
            errors.append(f"stale bundled file: {bundled}")
    generated = (
        "core-canon.md",
        "core16-abstracts.md",
        "extend17-abstracts.md",
        "core-structure-index.md",
        "source-manifest.md",
    )
    for filename in generated:
        if not (skill_root / "references" / filename).exists():
            errors.append(f"missing generated/canonical reference: {filename}")

    core_abstracts = skill_root / "references" / "core16-abstracts.md"
    if core_abstracts.exists():
        count = len(re.findall(r"^## Core \d{2}:", core_abstracts.read_text(), re.MULTILINE))
        if count != len(CORE_PAPERS):
            errors.append(f"core abstract count mismatch: expected {len(CORE_PAPERS)}, found {count}")

    extension_abstracts = skill_root / "references" / "extend17-abstracts.md"
    if extension_abstracts.exists():
        count = len(re.findall(r"^### \d+\.\d+ ", extension_abstracts.read_text(), re.MULTILINE))
        if count != len(EXTENSION_PAPERS):
            errors.append(
                f"extension abstract count mismatch: expected {len(EXTENSION_PAPERS)}, found {count}"
            )
    if errors:
        for error in errors:
            print(f"[ERROR] {error}")
        return False
    print(f"[OK] Verified {len(pairs)} bundled source/reference files against {corpus_root}")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--corpus-root",
        type=Path,
        help="Path containing core16/, core16_ref/, extend17/, and extend17_ref/",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Verify the bundled snapshot instead of rebuilding it",
    )
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    corpus_root = (args.corpus_root or skill_root.parent).resolve()
    required = ("core16", "core16_ref", "extend17", "extend17_ref")
    missing = [name for name in required if not (corpus_root / name).is_dir()]
    if missing:
        print(f"[ERROR] Corpus root is missing: {', '.join(missing)}")
        return 2

    if args.check:
        return 0 if check(corpus_root, skill_root) else 1
    build(corpus_root, skill_root)
    print(f"[OK] Built EG corpus resources in {skill_root / 'references'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
