# EG Research Artifact Schemas

Use these schemas as a project memory, not as bureaucratic output. Populate only fields needed for the current decision, preserve unknowns as explicit obligations, and update existing artifacts instead of recreating them on every turn.

## 1. EG Research State

```markdown
# EG Research State: <short project name>

- Current mode: explore | audit | develop | literature | experiment | write | referee
- EG verdict: exact | repairable | analogy | not presently EG
- Scientific target: <one sentence>
- Three-level status: local solvability | global realizability | finite-sample certifiability
- Four-risk diagnosis: local model | shared architecture | generalization | implementation
- Strongest defensible claim: <one sentence plus status>
- Earliest open validation gate: <single most consequential gap>
- Exact EG sources reread: <filenames or none>
- External primary sources checked: <citations or none>
- Epistemic status: source-proved | derived with proof | conjecture | open obligation | refuted | analogy
- Historical provenance: C | S | P | O | B | not applicable
- Intervention status: obstruction | authorized | saturation tested | repair tested | independently validated
- Active artifacts: <problem card, audit, theorem ledger, ...>
- Next highest-information action: <one action>
- Last updated: <task-local turn/date if useful>
```

Keep the state compact enough to show in a response when it materially helps. A full state may remain internal unless the user requests a record.

## 2. EG Problem Card

```markdown
# EG Problem Card

## Scientific contract
- Domain question:
- External variable / instance \(\theta\):
- Scientific target \(J(\theta)\):
- Units of success or loss:
- Admissible interventions:
- Desired output:

## Three-level and four-risk triage
- Local solvability question/status:
- Global realizability question/status:
- Finite-sample certifiability question/status:
- Local-model component:
- Shared-architecture component:
- Generalization component:
- Implementation component:

## Elimination contract
- Auxiliary object \(a\):
- Admissible class \(\mathcal A\):
- Lifted objective \(H(\theta,a)\):
- Elimination identity:
- Oracle fiber \(\mathcal O_\theta\):
- Native insertion defect \(D_\theta(a)\):
- Exactness/nonnegativity/touching evidence:
- Branch: P | G | X | V | C | other

## Validity contract
- Integrability status / global potential:
- Curvature, Hodge, or period residual if nonflat:
- Native versus nonnative carrier:
- Intrinsic factorization / quotient-faithful extraction gate:
- Padding, duplication, rescaling, and target-calling controls:

## Architecture contract
- Shared/restricted object:
- Architecture/resource class \(\mathfrak A\):
- Carrier:
- Decoder:
- Representation equivalences allowed:
- Risk aggregation:

## Operational and statistical contract
- Transmission/path/kernel:
- Observer/task:
- Exposure condition:
- Data/observation model:
- Confidence world or evidence model:
- Recursive update/acquisition requirement:

## Quantifiers
- Pointwise/common:
- Average/worst-case/Bayesian:
- Fixed/adaptive:
- Population/finite-sample:
- Deterministic/randomized/set-valued:

## Immediate stress test
- Zero-tax regime:
- Smallest positive witness:
- Result that would falsify the direction:
- Earliest Appendix E gate currently open:
```

If the elimination identity is blank, the current verdict cannot exceed analogy.

## 3. Formulation Audit

Use one row per gate.

```markdown
# Formulation Audit

| Gate | Status | Evidence | Consequence / repair |
|---|---|---|---|
| Scientific fidelity | passed/open/failed | | |
| Certified elimination | | | |
| Native insertion identity | | | |
| Integrability | | | |
| Carrier admissibility | | | |
| Architecture grammar | | | |
| Representation integrity | | | |
| Risk and quantifiers | | | |
| Transmission | | | |
| Task exposure | | | |
| Evidence validity | | | |
| Recursive closure | | | |
| Fixed-contract saturation | | | |
| Matched intervention | | | |
| Independent validation | | | |

Verdict: exact EG | repairable EG candidate | EG-guided analogy | not presently EG
Verdict rationale:
Fatal gap, if any:
Earliest repairable gate:
```

Allowed statuses are `passed`, `repairable`, `open`, `failed`, and `not applicable`. Follow the row order as an audit dependency, not a theorem implication. Do not mark a gate passed merely because an analogous EG paper has such a theorem.

## 4. Typed Ledger Map

```markdown
# Typed Ledger Map

| Ledger | Quantity | Units | Aggregation | Quantifiers | Exchanges out |
|---|---|---|---|---|---|
| Native | | | | | theorem/none |
| Architecture | | | | | theorem/none |
| Operational | | | | | theorem/none |
| Evidence | | | | | theorem/none |
| Recursive | | | | | theorem/none |
```

For every exchange, name the theorem or open obligation. Never put several ledgers into one scalar “total error” without a proved conversion.

## 5. Theorem Ledger

```markdown
# Theorem Ledger

| ID | Candidate statement | Epistemic status | Assumptions and quantifiers | Role provenance | Book code | Dependencies | Proof route / witness | Falsifier |
|---|---|---|---|---|---|---|---|---|
| T0 | | source-proved / derived with proof / conjecture / open obligation / refuted / analogy | | imported / calibration / interface / independent increment / analogy | C / S / P / O / B / n.a. | | | |
```

Recommended IDs:

- `I*` for primitive identities;
- `Z*` for zero-tax/realizability results;
- `O*` for obstructions and no-go results;
- `S*` for stability or transport;
- `T*` for transmission/task exposure;
- `C*` for statistical certificates;
- `A*` for algorithms, interventions, and rates.

Do not use `derived with proof` unless the argument is complete enough to audit. A proof sketch remains a conjecture plus a proposed route.

The book code records historical provenance, not correctness. In particular, `O` means unresolved priority, not original, and a proof-covered result may carry any code.

## 6. Counterexample and Witness Ledger

```markdown
# Counterexample and Witness Ledger

| ID | Target claim | Minimal construction | Contract respected? | Outcome | Status |
|---|---|---|---|---|---|
| W1 | | | yes/no and why | supports/refutes/inconclusive | analytic/computational/open |
```

Record whether the witness preserves the same representation, risk, task, and quantifiers. A counterexample to a changed contract does not refute the original theorem.

## 7. Prior-Art Matrix

```markdown
# Prior-Art Matrix

| Source | Formula | Primitive object | Quantifiers/correctness | Architecture/task | Theorem chain | Integrated method | Relation to proposed claim |
|---|---|---|---|---|---|---|---|
| <primary citation + location> | same/overlap/different/unchecked | | | | | | inherited/calibration/neighbor/non-overlap |

Search scope:
Unchecked terms or fields:
Negative-search wording:
```

The last column must state what remains after crediting the source. Avoid one-bit “new/not new” judgments before the six middle columns are resolved.

## 8. Contribution Ledger

```markdown
# Contribution Ledger

| Manuscript item | Role class | Book code | Nearest source | Exact residual contribution | Claim wording |
|---|---|---|---|---|---|
| Definition/result/algorithm/experiment | imported/calibration/interface/independent increment/analogy | C/S/P/O/B/n.a. | | | |
```

Use this ledger to separate foundations from the independent core. Role class and book code are orthogonal. If either changes after literature review, update manuscript wording immediately.

## 9. Experiment Contract

```markdown
# Experiment Contract

## Claim linkage
- Hypothesis:
- Theorem/claim IDs:
- What result would falsify the claim:

## Regimes
- Positive-obstruction regime:
- Zero-tax control:
- No-transmission/task-invisible control:
- Misspecification or approximation stress:
- Fixed-contract saturation diagnostic:

## Methods and privileges
| Method | Target contract | Information available | Oracle quantities | Compute budget | Refresh/stopping rule |
|---|---|---|---|---|---|
| | | | | | |

## Intervention contrasts
- Baseline inside the fixed architecture:
- Mechanism-matched repair:
- Generic-repair negative control:
- Equal-information/equal-compute control:
- Selection and tuning separation:

## Metrics
- Native:
- Architecture:
- Operational/task:
- Evidence/coverage:
- Recursive:
- Optimization:
- Computation/wall-clock:

## Reproducibility
- Data generation/version:
- Seeds/repetitions:
- Hardware/software:
- Saved configs/logs/artifacts:
- Prespecified plots/tables:
- Acceptance and failure thresholds:
- Independent or prospectively frozen validation unit:
- Post-confirmation analyses kept separate:
```

If oracle quantities appear in gating or tuning, label the run `oracle audit`. Include an actually deployable branch if the manuscript claims deployability. An architecture-choice conclusion requires separate evidence for saturation, matched repair, and independent validation.

## 10. Research and Manuscript Plan

```markdown
# Research / Manuscript Plan

## One-sentence thesis

## Scientific gap

## Exact contract

## Inherited foundations
- <item + source>

## Independent contribution candidates
- <item + current evidence status>

## Dependency graph
- <statement -> prerequisites -> experiment>

## Proposed sections
1. ...

## Required proofs
- ...

## Required experiments
- ...

## Related-work obligations
- ...

## Limitations and nonclaims
- ...

## Kill criteria
- <evidence that would terminate or redirect the project>
```

Do not present a candidate as an independent contribution if the Prior-Art Matrix remains unchecked on the layer actually being claimed.

## 11. Referee Checklist

```markdown
# Referee Checklist

## Contract
- [ ] The domain target is unchanged by the EG translation.
- [ ] The elimination and native defect are exact.
- [ ] Integrability and carrier admissibility precede obstruction.
- [ ] Architecture, representation, risk, and quantifiers are explicit.
- [ ] Transmission and task exposure support downstream claims.
- [ ] Population, evidence, computation, and recursion are separated.

## Theorems
- [ ] Every main statement has a correct evidence label.
- [ ] Zero-tax and boundary cases are covered.
- [ ] Universal claims survived minimal counterexamples.
- [ ] Proof dependencies do not form a circle.

## Novelty
- [ ] Matching formulas and classical objects are credited.
- [ ] Formula ancestry is not conflated with full-framework identity.
- [ ] A different domain is not the sole novelty argument.
- [ ] Independent increments are stated at the level actually checked.
- [ ] Epistemic status and C/S/P/O/B provenance are recorded separately.

## Experiments
- [ ] Baselines solve declared, comparable contracts.
- [ ] Oracle privileges are disclosed.
- [ ] The operational branch does not use oracle gating.
- [ ] Metrics include native behavior and computational cost.
- [ ] At least one design can refute the flagship claim.
- [ ] Saturation, matched repair, and independent validation are not conflated.

## Writing
- [ ] Inherited foundations precede and are separated from the independent core.
- [ ] Limitations and unresolved obligations remain visible.
- [ ] Abstract and introduction do not outrun theorem and experiment evidence.
```

## 12. Compact checkpoint

Use this in ordinary interaction when the full artifacts would be excessive:

```text
EG verdict: <exact / repairable / analogy / not presently EG>
Strongest defensible claim: <statement + status>
Critical open gate: <one gap>
Best next falsification or proof step: <one action>
Evidence status: <canonical memory; exact sources; external primary sources>
```

## 13. Certified Learning System Contract

Use this when a claim joins population geometry, finite data, deployment, and action.

```markdown
# Certified Learning System Contract

## Scientific and local layer
- Scientific target and loss units:
- Local oracle / oracle fiber:
- Local-model approximation status:
- Native insertion defect:

## Validity and shared deployment layer
- Integrability certificate or repair:
- Intrinsic carrier / extraction gate:
- Shared architecture and common-witness quantifier:
- Architecture obstruction and units:

## Typed carriers
- Deployment carrier and decoder:
- Evidence carrier and worldwise resolution contract:
- Recursive carrier and future-update closure:
- Context/task quotient and exposure:

## Statistical and implementation layer
- Simultaneous confidence world:
- Generalization event:
- Implementation/optimization certificate:
- Common action authorized across all compatible worlds:

## Intervention layer
- Fixed-contract saturation evidence:
- Failed interface localized:
- Mechanism-matched repair:
- Equal-resource negative controls:
- Independent validation endpoint:

## Nonclaims and stopping rule
- Unsupported arrows:
- Evidence that would stop or redirect the program:
```

The contract types several interfaces; it does not convert their units into one scalar unless a theorem does so.

## 14. OALI Validation Record

```markdown
# OALI Validation Record

| Stage | Claim | Evidence | Status | Failure consequence |
|---|---|---|---|---|
| Native diagnosis | Exact target-generated defect | | passed/open/failed | No structural diagnosis |
| Valid obstruction | Integrable defect, admissible carrier, declared architecture witness | | | No architecture claim |
| Authorization | Transmission, task exposure, confidence-world decision | | | No deployable intervention claim |
| Saturation | Baseline reaches fixed-contract floor under fair optimization | | | Failure may be implementation error |
| Matched repair | Intervention changes the diagnosed interface | | | Gain may be generic |
| Independent validation | Held-out/frozen endpoint and matched controls confirm predicted gain | | | No confirmed architecture choice |

Oracle-audit boundary:
Post-confirmation analyses:
Strongest conclusion currently authorized:
Next stopping rule:
```

Preserve failed and unresolved stages. Do not rewrite them as successful intermediate evidence merely because a later exploratory run looks promising.

## 15. Release and Rights Ledger

Use this only when preparing external distribution, publication, licensing, or a commercial collaboration.

```markdown
# Release and Rights Ledger

- Release artifact and version:
- Canonical EG citation included: yes/no
- Exact result-specific citations included:
- Intended use: scholarly noncommercial | educational | public noncommercial | proposed commercial
- Package label: source-available for noncommercial research
- Author-owned files:
- Coauthored files and consent status:
- Third-party/vendored files and governing terms:
- Dataset/model licenses checked:
- CC BY-NC-SA attribution and ShareAlike obligations:
- PolyForm notice preserved for scripts:
- Commercial license required: yes/no
- Applicable rights holders:
- Written authorization or agreement reference:
- Legal review status:
- Unresolved rights-clearance blockers:
```

Do not mark a commercial release cleared merely because the material is online, accessible to a model, or properly cited.
