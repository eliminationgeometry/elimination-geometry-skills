# Structure-First Domain Router

Use this router when a collaborator brings a problem from an unfamiliar field. Route by mathematical contract, not by shared vocabulary. A domain may activate several routes, and an extension paper is evidence only after its exact source is reread for technical claims.

## 1. Universal intake questions

Before selecting papers, answer as many of these as possible:

1. What is the scientific target and its native unit?
2. What hidden, nuisance, local, fine-scale, or auxiliary object is eliminated?
3. Is the elimination exact, variational, dynamic, probabilistic, or only heuristic?
4. What must be shared, compressed, coupled, deployed, remembered, or certified?
5. What is the architecture/resource grammar?
6. What carrier and decoder are actually implementable?
7. Through what dynamics, kernel, or pipeline could a mismatch propagate?
8. Which observer or task can see the propagated mismatch?
9. Are the quantifiers pointwise, common-deployment, worst-case, average, Bayesian, or worldwise?
10. Is the claim population, finite-sample, computational, operational, or recursive?
11. What intervention is legally available?
12. What smallest example could show that the EG translation is wrong?

If questions 1–3 have no credible answer, keep the project at analogy status.

## 2. Route through the monograph first

Use the monograph to locate the current organizing contract and earliest audit gate before selecting paper variants:

| Structural need | Primary book source |
|---|---|
| local solvability, global realizability, finite-sample certifiability | Chapters 1–2 |
| local-model / architecture / generalization / implementation diagnosis | Chapter 3 |
| recurring domain mechanisms and negative boundaries | Chapter 4 |
| native defects, P/G/X/V/C, exactification, graph CRPS | Chapters 5–8 |
| integrability, Hodge repair, and intrinsic carrier admissibility | Chapters 9–10 |
| regular, coordination, and singular obstructions; architecture repair | Chapters 11–15 |
| resource exchange, operational visibility, and composition | Chapters 16–18 |
| confidence worlds, three-way decisions, resolution, and evidence | Chapters 19–20 |
| certified common actions, OALI, transport, and empirical validation | Chapters 21–24 |
| noncommutative stress tests, boundaries, stopping rules, and agenda | Chapters 25–27 |

Read `validation-dependency-map.md` before jumping from one row to a later conclusion. Use `monograph-structure-index.md` to locate the exact statement and proof file. Route to Core16 when the book marks an advanced result as source-based but not fully reproduced, or when a manuscript-specific theorem, algorithm, or experiment is needed.

## 3. Core16 routing by structural need

### Certified elimination and intervention branch

Use:

- `eg1.tex` for the primitive elimination, insertion defect, and P/G/X/V/C contracts.
- `eg2.tex` for integrability, representation integrity, semantic validity, converses, and leverage.
- `x_algo.tex` for stale/approximate exactification, local rates, deflation, Ritz certification, and switching.

Typical triggers: nuisance minimization, frozen or stale auxiliaries, plug-in bias, surrogate correction, profile objectives, shared latent fields, or optimization acceleration.

### Composition, paths, and coherence branch

Use:

- `eg3.tex` for hard/soft path composition, conditional KL, refinement, base change, and temperature.
- `foundation.tex` for abstract defect fibrations, towers, curvature, coherence, and categorical structure.

Typical triggers: repeated elimination, dynamic programming, path-space laws, multiscale composition, inconsistent local reports, refinement diagrams, or changes of representation/base.

### Obstruction and obstruction-as-elimination branch

Use:

- `eot.tex` for transferring topology, cuts, packing, or incompatibility into native lower bounds.
- `cot.tex` for treating architecture choice and obstruction itself as another elimination.
- `singular.tex` for discriminants, branching or nonsmooth oracle geometry.
- `quantum.tex` for noncommutative base-change and measurement limitations.

Typical triggers: unavoidable cost under sharing, topological obstruction, singular oracle fibers, discrete collisions, minimax architecture choice, or quantum/measurement-limited access.

### Representation and computation branch

Use:

- `lift.tex` for conic/extended formulations, visible capacity, padding no-go results, and computation-to-defect interfaces.
- `architecture.tex` for typed carriers, native rate-distortion, common deployment, visibility, and recursive closure.

Typical triggers: parameter count, width, rank, cone size, charts, memory, coding, representation compression, decoder saturation, or claims that a formulation size implies runtime.

### Operational and task branch

Use:

- `operation.tex` for context closure, task envelopes, safe replacement, ordering, and resolution profiles.
- `architecture.tex` for transmission/exposure and finite-information deployment.

Typical triggers: pipelines, module replacement, ordering effects, downstream tasks, context-dependent equivalence, or a gap between native mismatch and observable behavior.

### Statistics, evidence, and adaptive validity branch

Use:

- `statistical.tex` for confidence worlds, simultaneous transport, finite-sample architecture certificates, and detectability.
- `certificate_stat.tex` for fixed-confidence resolution, evidence carriers, Bayesian guidance, and recursive certificate state.
- `architecture.tex` for common-deployment conflict and typed expansion.

Typical triggers: feasible/unresolved/impossible decisions, adaptive budget selection, confidence sets, partial identification, evidence compression, sample lower bounds, or posterior-versus-worldwise validity.

### Machine-learning systems branch

Use:

- `egml.tex` for the static model/architecture/statistics/optimization audit and OALI.
- `egml2.tex` for adaptive acquisition, evidence repair, recursive state, deployment expansion, and AR-OALI.

Typical triggers: shared encoders/policies/world models, architecture bottlenecks, active acquisition, memory refinement, adaptive repair, or claims that data/optimization can remove structural obstruction.

## 4. Extend17 routing by domain

### Information theory and certificate design

Primary extension sources:

- `deployment_info.tex`
- `certificate_info.tex`
- `recursive.tex`
- `wavelet_acquisition.tex`

Ask:

- Is the carrier for deployment, evidence, or recursion?
- What distortion or decision is native to the target?
- Which likelihood directions are binding for resolution?
- Is information averaged under a prior or required worldwise?
- Does the code preserve current output only or future acquisition state?
- Is the rate, characteristic time, or state count the relevant currency?

Nearest core interfaces: EG III, Certificate Statistics, Architecture, EGML II.

### Game theory and strategic learning

Primary extension sources:

- `Strategic_Regret_Geometry.tex`
- `Recursive_Strategic_Elimination.tex`

Ask:

- What player, strategy, best response, equilibrium, or value object is eliminated?
- Is the target regret, exploitability, welfare, equilibrium gap, or another native currency?
- Which information/strategy must be shared across types, histories, or players?
- Are opponents fixed, adaptive, adversarial, or strategically responding to the architecture?
- Is consistency pointwise, common across games, or recursive over play?
- Does an intervention change the game or only its representation?

Nearest core interfaces: EG I, COT, Operational Semantics, Architecture, EGML II.

### Time series, dependence, and dynamical closure

Primary extension sources:

- `timescale_eg.tex`
- `dependent.tex`
- `long_memory_forecasting.tex`
- `Mori_Zwanzig_Elimination_Geometry.tex`
- `task_visible.tex`

Ask:

- What fine-scale or latent history is eliminated?
- Is the reduced target predictive risk, likelihood, path action, memory-kernel error, or task loss?
- Does the auxiliary state summarize current prediction or support recursive updating?
- Is the architecture finite memory, Markov order, state-space rank, timescale partition, or filter class?
- What dependence assumptions replace iid concentration?
- Does closure hold pathwise, in distribution, in risk, or only for one horizon?
- Can the downstream task see the omitted memory?

Nearest core interfaces: EG III, Operational Semantics, Statistical EG, Certificate Statistics, Architecture.

### Statistical physics, diffusion, and renormalization

Primary extension sources:

- `Task_Conditioned_Renormalization.tex`
- `continuous.tex`
- `Hidden_Entropy_Production.tex`

Ask:

- What microstate, fast variable, field, or path is eliminated?
- Is the native currency energy, free energy, entropy production, action, KL, or task-conditioned loss?
- Is the limit hard, finite-temperature, diffusive, or renormalization based?
- Which coarse variables or closure architecture are admissible?
- Is hidden entropy/task loss transmitted to an observable?
- Are reference measures, fiber volumes, and base-change anomalies controlled?
- Does a proposed coarse-graining preserve equilibrium only, dynamics, or a declared task?

Nearest core interfaces: EG III, Foundations, EOT, Operational Semantics, Statistical EG.

### Queueing and market microstructure

Primary extension sources:

- `queue.tex`
- `microstructure_event_order.tex`
- `execution_visible_market_states.tex`

Ask:

- What queue, latent order flow, event sequence, or market state is eliminated?
- Is the native target waiting cost, execution value, regret, likelihood, or pathwise risk?
- Is the architecture a state aggregation, event-order quotient, policy class, or observation filter?
- Which ordering and latency effects survive the task quotient?
- What is observed in real time versus only retrospectively?
- Does a positive state-space obstruction change execution behavior under legal contexts?
- Are strategic response and nonstationarity part of the contract?

Nearest core interfaces: EG III, Operational Semantics, Statistical EG, Architecture, EGML II.

Treat each list as a primary home, not an exclusivity rule. Cross-domain questions often require several groups.

## 5. Routing domains not represented in Extend17

For a new field:

1. Build the universal intake map.
2. Select the monograph chapters and earliest Appendix E gate by structure.
3. Route to Core16 for exact or advanced manuscript interfaces.
4. Search the domain's primary literature for the exact primitive object and standard vocabulary.
5. Identify whether the novelty candidate is a formula, object, contract, theorem chain, or integrated method.
6. Load an Extend17 source only if its mechanism genuinely transfers; do not cite it as domain authority outside its scope.

Useful structural search families include:

- value functions, envelopes, profiles, nuisance elimination, and surrogate correction;
- coarse-graining, model reduction, sufficient state, closure, and memory kernels;
- rate-distortion, representation bottlenecks, task-aware coding, and evidence compression;
- robust/common decisions, partial identification, confidence projection, and adaptive testing;
- topology, extension complexity, graph cuts, packing, and quantization;
- contextual equivalence, bisimulation, semantics, order effects, and pipeline replacement;
- bilevel optimization, EM/MM, variable projection, Schur complements, and deflation.

## 6. Candidate selection rule

When several EG translations are plausible, rank them by:

1. fidelity to the scientific target;
2. exactness of the elimination identity;
3. naturalness of the native currency;
4. nonvacuity and practical relevance of the architecture restriction;
5. availability of a minimal zero-tax case and positive witness;
6. visibility to a real task;
7. falsifiability with accessible data or computation;
8. distance from already established full-contract results.

Present the top candidate and at most two serious alternatives. Explain what evidence would switch the choice.

## 7. Domain translation warnings

- Shared words such as “information,” “energy,” “complexity,” “state,” “geometry,” or “certificate” do not establish a common ledger.
- KL can be native defect, path decomposition, evidence information, or Bayesian-average information; keep the role typed.
- Parameter count is not automatically visible capacity.
- Coarse-graining is not automatically an EG obstruction; an exact target and task are still required.
- A latent variable is not automatically an eliminand; the objective identity must be declared.
- A collection of local residuals is not automatically one global defect; audit integrability.
- A lifted representation is not automatically intrinsic; exclude padding and target-calling carriers before complexity claims.
- A posterior is not automatically a confidence certificate.
- Better empirical prediction is not proof of recursive closure.
- Failure to optimize a baseline is not evidence of fixed-architecture saturation.
- Repair success on the development data is not independent validation.
- A different discipline may contain an identical component formula under a different name. Search by the formula and object, then compare the full contract.
