# EG Research Protocol

This protocol turns a new-domain question into an auditable EG research project. It instantiates the Version 1.9 monograph's validation order and is a sequence of gates, not a requirement to manufacture a paper. Enter at the earliest unresolved gate needed by the user's request and keep later stages explicitly provisional.

## 0. Source and evidence discipline

Initialize the monograph-and-corpus canonical memory before substantive work. Use the monograph for current organization, terminology, dependency order, proof routing, and conservative provenance. Use exact book chapters and chapter-local proof appendices for book-proved results, and exact paper TeX for advanced or manuscript-specific results that the book only summarizes. Use external primary literature for priority.

Use these epistemic labels consistently:

- **Source-proved:** stated and checked in an exact source under named assumptions.
- **Derived with proof:** established in the current work by a complete argument from declared premises.
- **Conjecture:** precise and plausible, but not proved.
- **Open obligation:** a required definition, lemma, exchange, domain fact, or implementation check.
- **Refuted:** contradicted by a theorem, counterexample, or valid experiment.
- **Analogy:** a useful structural correspondence without an exact certified identity.

Record historical provenance on a second, independent axis:

- **C:** classical or imported mathematical core.
- **S:** direct specialization, corollary, or workflow lemma.
- **P:** possible narrow program-specific increment with close antecedents.
- **O:** unresolved priority candidate, not established originality.
- **B:** book-level synthesis or interface.

Proof status, provenance, and empirical confirmation are not interchangeable. A complete proof may be C, S, P, O, or B; an O code remains unresolved even when the theorem is proved.

For external priority or state-of-the-art claims, search primary literature. Reviews and manuals are maps, not final evidence of priority. Record negative search conclusions cautiously: “not found in the searched sources” is not “does not exist.”

## 1. Scientific intake

Start from the collaborator's actual scientific problem, not from EG vocabulary. Extract:

1. The decision, prediction, inference, control, or design goal.
2. What is expensive, hidden, local, nuisance, high-dimensional, path dependent, or repeatedly eliminated.
3. What must be shared, compressed, deployed, remembered, certified, or made operational.
4. The scientific loss or objective and its units.
5. The data-generating and intervention model.
6. The desired conclusion: identity, obstruction, rate, certificate, algorithm, experiment, or manuscript.
7. What outcome would convince the collaborator that the EG direction is wrong.

Classify the question at three nonexchangeable levels before formalization:

1. local solvability of the pointwise problem;
2. global realizability by one declared deployment contract;
3. finite-sample certifiability over a simultaneous confidence world.

Also identify which of the local-model, shared-architecture, generalization, and implementation components is implicated. Do not prescribe more data, better optimization, or architecture change before this diagnosis.

If the user supplies only a domain label, consult `domain-router.md`, identify two or three structurally distinct candidate contracts, and explain the choice. Apply its five-part domain-fit gate before calling any candidate an EG application, and report its source-status label or keep it analogy-only. Do not lock onto the first lexical resemblance.

## 2. Construct the EG Problem Card

### 2.1 Target and elimination

Name the external problem variable \(\theta\) and target \(J(\theta)\). Propose an auxiliary object \(a\in\mathcal A\) and a certified elimination such as

\[
J(\theta)=\inf_{a\in\mathcal A} H(\theta,a).
\]

If the domain uses maximization, saddle elimination, log-partition elimination, dynamic programming, partial minimization, or another exact envelope, state that contract rather than forcing the minimization notation.

Define the insertion defect in native units:

\[
D_\theta(a)=H(\theta,a)-J(\theta)\ge 0.
\]

Check exactness, nonnegativity, and touching on the oracle fiber. A discrepancy that merely vanishes at one optimizer is insufficient. If no identity is available, label the proposal analogy-only until one is proved.

### 2.2 Oracle and sharing structure

Identify the oracle fiber Ωθ and what varies horizontally as θ changes. Specify the restriction that prevents choosing a fresh oracle independently everywhere:

- common parameter or policy;
- finite carrier, bits, charts, states, or memory;
- continuity, smoothness, topology, cone, tree, graph, or rank constraint;
- evidence compression or observation channel;
- recursive update or acquisition restriction;
- stale or approximate auxiliary field;
- fixed marginal or dependence constraint.

State whether the proposal is P, G, X, V, C, or a different certified contract. Do not compare branches before stating whether they optimize the same target.

### 2.3 Validity before obstruction

Before assigning structural meaning to a restricted architecture, audit:

- whether locally assembled defect reports integrate to one global objective;
- whether any nonnative lift is intrinsic rather than padded, duplicated, or target calling;
- whether a factorization, quotient-faithful extraction, or model-specific carrier theorem is required;
- which representation equivalences leave the proposed complexity or obstruction invariant.

Keep integrability and carrier admissibility as explicit obligations. A nonnegative local residual alone does not pass either gate.

### 2.4 Carrier, decoder, operation, and task

Separate four objects:

1. **Carrier:** stores distinctions.
2. **Decoder:** maps stored information to an admissible auxiliary action.
3. **Operational transmission:** propagates consequences through a path, kernel, dynamics, or pipeline.
4. **Task/observer:** declares which propagated differences matter.

A native obstruction need not be task visible. Mark transmission and exposure as open obligations until the relevant theorem is proved.

### 2.5 Ledgers

Type every quantity before combining it:

- **Native:** objective defect, risk, regret, energy, free-energy gap, path KL, value loss.
- **Architecture:** states, bits, charts, cone size, memory, width, stability, computation.
- **Operational:** path kernels, ordering, contexts, task quotient, observable behavior.
- **Evidence:** coverage, worldwise KL, characteristic time, unresolvedness.
- **Recursive:** future-update state, recursive charts, refresh or acquisition cost.

An exchange between ledgers is a theorem, not arithmetic. Record its assumptions, direction, and constant.

### 2.6 Quantifier grid

Write the quantifiers explicitly. At minimum inspect:

- pointwise versus one common architecture;
- worst-case versus population-average versus Bayesian-average risk;
- deterministic versus randomized or set-valued representations;
- population versus finite sample;
- fixed-time versus anytime/adaptive validity;
- current task versus all legal contexts versus recursive future tasks;
- exact versus approximate, stale, or computationally reachable auxiliaries.

The reversal

\[
\forall \theta\in C\;\exists A_\theta
\quad\Longrightarrow\quad
\exists A\;\forall\theta\in C
\]

is invalid without an additional theorem.

## 3. Formulation audit

Audit the following gates. Use `passed`, `repairable`, `open`, `failed`, or `not applicable`.

| Gate | Question | Failure consequence |
|---|---|---|
| Scientific fidelity | Does the formal target preserve the domain question? | Do not proceed with a mathematically clean but scientifically different problem. |
| Certified elimination | Is the target an exact declared elimination? | Analogy only. |
| Native insertion | Is defect nonnegative, touching, and in target units? | No EG tax or obstruction yet. |
| Integrability | Do assembled local defects arise from one global objective, or is the failure quantified and repaired? | No global obstruction interpretation yet. |
| Carrier admissibility | Is every lift intrinsic, factorized, or quotient-faithfully extracted? | Complexity may be vacuous under padding or target calling. |
| Architecture grammar | Is the restriction explicit and nonvacuous? | No architecture theorem. |
| Representation integrity | Are padding, duplication, target-calling, and coordinate changes controlled? | Complexity/obstruction may be artificial. |
| Risk and quantifiers | Are aggregation and witness order declared? | Bounds cannot be compared or transported. |
| Transmission | Does native mismatch reach an operational object? | No downstream consequence. |
| Task exposure | Does the observer distinguish the transmitted mismatch? | Native cost may be invisible. |
| Evidence | Is there an honest confidence world or resolution model? | No finite-sample certificate. |
| Recursive closure | Is future updating/acquisition part of the claim? | Present sufficiency does not imply recursive sufficiency. |
| Fixed-contract saturation | Is failure inside the old class distinguished from incomplete optimization? | Do not attribute empirical failure to architecture. |
| Matched intervention | Does the proposed repair answer the diagnosed witness? | The algorithm is generic, not obstruction aware. |
| Independent validation | Does improvement survive a held-out/frozen endpoint and matched controls? | No confirmed architecture-choice conclusion. |

Issue one verdict:

- **Exact EG** when all gates needed by the current claim pass.
- **Repairable EG candidate** when the structure is faithful and missing gates are concrete obligations.
- **EG-guided analogy** when the pattern is useful but the elimination identity is absent.
- **Not presently EG** when the translation changes the scientific problem or adds vacuous structure.

A project can move between verdicts as obligations are resolved or refuted.

The ordering above follows Appendix E. Passing an earlier row never marks a later row passed by implication.

## 4. Theorem and counterexample engineering

### 4.1 Build a theorem ladder

Prefer the following order:

1. **Primitive identity:** exact elimination and insertion ledger.
2. **Zero-tax theorem:** conditions under which the restricted architecture realizes the oracle field or obstruction vanishes.
3. **Validity theorem:** establish integrability and intrinsic carrier admissibility, or quantify/repair their failure.
4. **Positive witness:** an explicit collision, period, winding, cut, packing, information-blind pair, ordering conflict, or recursive split.
5. **Lower or upper transfer:** translate the witness into native units with declared regularity.
6. **Operational theorem:** show transmission and task exposure.
7. **Statistical theorem:** construct a simultaneous confidence event, stability transport, resolution information, or minimax limit.
8. **Saturation result:** separate the fixed architecture floor from incomplete optimization or finite-data noise.
9. **Matched method:** give a repair/algorithm tied to the witness and prove validity, stationarity, rate, or finite termination.
10. **Validation result:** test the predicted improvement on an independent endpoint under matched information, compute, parameter, and selection contracts.

The strongest publishable increment may occur at any rung. Do not invent later rungs to make the project look complete.

### 4.2 State theorem contracts before proving them

For each proposed result record:

- exact objects and spaces;
- representation and architecture class;
- risk aggregation and quantifiers;
- assumptions, including compactness, positivity, convexity, eigengap, separation, or measurability;
- conclusion and its units;
- role provenance: imported, calibration, interface, independent increment, or analogy;
- book provenance when applicable: C, S, P, O, or B;
- epistemic status: source-proved, derived with proof, conjecture, open obligation, refuted, or analogy;
- dependencies on other proposed results;
- a falsifier or boundary case.

If a proof silently changes any field, rewrite the statement rather than hiding the change.

### 4.3 Counterexample-first tests

Use the smallest witness capable of breaking the claim:

- two worlds with zero task-opposite KL;
- two oracle types forced into one carrier state;
- a three-node weighted graph for a semantic-preservation claim;
- a loop with nonzero period for local-to-global integrability;
- dummy coordinates, duplication, rescaling, or target-calling auxiliaries for lift invariance;
- an affine natural-parameter map for a claimed X curvature channel;
- a task that cannot see a positive native defect;
- pointwise feasible worlds with no common deployable witness;
- equal current output colors with different future transitions;
- two differently rotated approximate subspaces for a Ritz/deflation certificate;
- an oracle-gated implementation advertised as operational.

Search failure is not a proof. A numerical witness can refute a universal theorem; it cannot establish one.

### 4.4 Exactification-specific audit

When the project uses X or local additive correction:

1. Identify which jet-matching statements are inherited from EG I/II and historical surrogate, multifidelity, MM, profile, or orthogonality literature.
2. Check whether a fresh exact inner solution makes the first-order correction trivial by an envelope theorem.
3. Distinguish target preservation from acceleration.
4. Isolate the transmitted Schur/leverage channel and test affine no-go cases.
5. If claiming an operational method, audit stale fields, approximate inner solves, approximate eigenspaces, common-subspace rotation, branch switching, and fallback logic together.
6. Compare P, G, raw X, scalar-relaxed X, and deflated X with oracle privileges disclosed.

An identical additive-correction formula establishes component ancestry. Novelty can still lie in a different full contract, certification chain, stale/inexact integration, matrix-free access, switching theorem, or matched experiment. Conversely, merely renaming the formula or changing application domain is not an independent contribution.

### 4.5 Statistical-certificate-specific audit

When the project uses a three-way output:

1. Define the population truth query.
2. Define a confidence world of complete population worlds with worldwise coverage.
3. Define the set-unanimity projection that yields terminal labels or unresolvedness.
4. Keep posterior color or Bayesian guidance separate from worldwise validity.
5. Distinguish statistical unresolvedness, architecture conflict, computational failure, and recursive insufficiency.
6. Show which EG population objects are transported simultaneously and why the transport is stable.
7. State any resolution lower bound and the intervention it authorizes.

Confidence-set projection and three labels are inherited. Potential increments lie in the elimination-specific world, simultaneous typed transport, common-deployment conflict, architecture consequences, sharp stability/detectability, resolution information, or the integrated intervention.

## 5. Prior-art and novelty audit

### 5.1 Search by object and contract, not EG names alone

Generate queries from:

- the exact formula and its standard mathematical names;
- the primitive envelope, value function, profile, or dynamic object;
- the domain's native terminology;
- the architecture restriction and quantifiers;
- the theorem consequence and algorithmic interface;
- neighboring fields that solve structurally similar problems.

Use reviews to discover vocabulary, then verify claims in original papers, books, standards, or official technical documentation. For mathematical and technical questions, prefer primary sources.

### 5.2 Compare six layers

For every close predecessor, fill a Prior-Art Matrix across:

1. formula identity;
2. primitive-object identity;
3. quantifier/correctness identity;
4. architecture/task identity;
5. theorem-chain identity;
6. integrated-method identity.

Classify the relation as **same**, **overlapping**, **different**, or **unchecked**, with exact source locations.

### 5.3 Write a contribution ledger

Partition manuscript content into:

- **Imported:** classical theorem used essentially.
- **Calibration:** inherited result recast to validate the EG ledger.
- **Interface:** a new connection between inherited objects under the EG contract.
- **Independent increment:** a genuinely new theorem, witness, exact ledger, algorithm, or integration.
- **Analogy:** a design correspondence without an exact theorem.

Alongside this role classification, record the monograph's C/S/P/O/B historical code whenever a book result is involved. The axes answer different questions: a result can be source-proved and O, derived with proof and B, or imported and C. Do not translate O into “original” or P into a broad framework claim.

The novelty paragraph should name the nearest ancestors first and then state the residual increment. Avoid both extremes:

- “The formula existed, so the framework is not new.”
- “The application is new, so the mathematics is new.”

The defensible unit of comparison is the claimed contribution's full contract.

## 6. Experiment contract

Design experiments to discriminate claims, not decorate them.

### 6.1 Required fields

1. Hypothesis and theorem/claim ID.
2. Data-generating mechanism or benchmark and why it instantiates the contract.
3. Positive-obstruction, zero-tax, no-transmission, and misspecification regimes as relevant.
4. Methods and baselines with matched information and optimization budgets.
5. Oracle privileges, exact quantities, approximations, and refresh policies.
6. Native, architecture, operational, evidence, recursive, and computational metrics kept separate.
7. Prespecified failure criteria and alternative explanations.
8. Seeds, configurations, hardware, wall-clock, product counts, stopping rules, and saved artifacts.
9. Evidence that the baseline has saturated its fixed contract, or an explicit statement that saturation remains untested.
10. A mechanism-matched repair contrast, generic-repair negative control, and independent validation split when making an architecture-choice claim.

### 6.2 Baseline and oracle fairness

Do not compare algorithms that solve different target contracts without saying so. If P, G, X, V, or C branches appear together, state the target of each. If an exact spectrum, true world, oracle inner solve, or ground-truth obstruction is used, label the run as an oracle audit. The deployable branch must use only its declared certificates.

### 6.3 Falsification

Every flagship empirical claim needs at least one result that would count against it. Examples:

- the tax fails to disappear in a zero-obstruction regime;
- native obstruction is positive but task distance stays zero, refuting an exposure claim;
- a purported finite-sample certificate miscovers;
- a common architecture is claimed despite only world-specific witnesses;
- deflation gains vanish after counting Schur products and refreshes;
- a repair succeeds equally well without the diagnosed witness, suggesting it is generic rather than matched.

For an OALI conclusion, treat the following as separate evidential arrows:

```text
obstruction -> operational/statistical authorization -> saturation
  -> matched repair -> independent validation
```

Failure of one arrow does not invalidate earlier mathematics, but it does cap the empirical conclusion at that gate.

## 7. Research plan and manuscript organization

Only organize a full paper after the formulation and contribution ledgers are coherent. A useful default order is:

1. Domain problem and failure of the current language.
2. Exact target, elimination, defect, architecture, and task contract.
3. Inherited EG interfaces and nearest historical work.
4. Zero-tax boundary and minimal obstruction witness.
5. Independent theorem chain.
6. Certificate or algorithm, if justified.
7. Falsifying experimental design and results.
8. Limitations, failed exchanges, and open obligations.

Do not bury inherited material behind a claim that “the independent contribution begins here” if the first displayed result there is classical. Attach provenance to each main result and make the actual increment visible.

## 8. Referee pass

Run two distinct reviews.

### Author audit

- Are all symbols and targets stable across sections?
- Are P/G/X/V/C contracts separated?
- Were integrability and carrier admissibility checked before obstruction?
- Are ledgers and quantifiers typed?
- Are source-proved, derived, conjectural, and empirical claims labeled?
- Is historical provenance C/S/P/O/B recorded separately from proof status?
- Does each strong statement have a proof, exact source, or explicit obligation?
- Are algorithms operationally implementable under their declared information?
- Do experiments expose oracle use and compute costs?
- Does an architecture claim distinguish saturation, matched repair, and independent validation?

### Skeptical referee audit

- Can the elimination be removed without changing the claim, showing EG is decorative?
- Can dummy coordinates, padding, rescaling, or representation changes destroy the result?
- Is the “obstruction” only failed optimization?
- Is the task unable to see the native mismatch?
- Is a population theorem being sold as a finite-sample method?
- Is unresolvedness confused with conflict, ignorance, or computation?
- Is a classical formula listed as novelty?
- Is a genuinely new integrated contract dismissed merely because its parts have ancestors?
- Is the experiment gated by an oracle quantity the method claims not to need?
- Is optimization failure being renamed architecture saturation?
- Is internal or post-confirmation evidence being described as independent validation?
- What is the smallest counterexample to the flagship theorem?

Resolve fatal objections before polishing exposition. Preserve nonfatal limitations explicitly.

## 9. Interaction policy

Maintain one evolving Research State. At each turn:

1. infer the requested mode;
2. locate the earliest necessary unresolved gate;
3. perform the highest-information safe action;
4. update affected artifacts and evidence labels;
5. report the conclusion, critical gap, and next best step.

Do not force the collaborator through every artifact when a short answer suffices. Do not ask for information that can be read from the corpus or supplied by a reversible assumption. Ask when the choice changes the target, architecture, task, risk, quantifiers, or admissible intervention.

## 10. Maturity criteria

A project is ready for a serious research plan when it has:

- a faithful scientific contract and at least a repairable EG verdict;
- a certified elimination or an explicitly bounded analogy status;
- passed or explicitly open integrability and carrier-admissibility gates;
- typed ledgers, architecture, task, risk, and quantifiers;
- a zero-tax boundary and either a positive witness or a precise open witness problem;
- a theorem ledger with provenance and falsifiers;
- a primary-source prior-art matrix;
- an experiment contract capable of refuting the main claim;
- a contribution ledger separating inheritance from increment;
- a referee audit with no hidden fatal gap.

It is manuscript-ready only when statements labeled as theorems are source-proved or derived with complete proofs, computations are reproducible, and novelty language matches both the checked evidence and the C/S/P/O/B provenance audit. An architecture-choice or intervention claim additionally requires explicit saturation status, a mechanism-matched contrast, and appropriately independent validation; otherwise scope the manuscript to the earlier completed gate.

## 11. Citation, release, and licensing gate

Before distributing a manuscript, skill bundle, dataset, model artifact, or derived research product:

1. Cite the canonical public preprint: Mian Huang and Xueqin Wang, *Elimination Geometry*, arXiv:2608.17646 [cs.LG] (2026).
2. Preserve result-specific citations to Core16, Extend17, and external primary antecedents; the monograph citation does not replace them.
3. Read `citation-and-licensing.md` and the package-root `LICENSE.md`.
4. Confirm which files are author-owned, separately licensed, third-party, vendored, or governed by dataset/model terms.
5. Treat the public package as source-available for noncommercial research, not OSI open source.
6. Do not infer commercial permission from file access, model execution, citation, or public arXiv availability. Require a separate written commercial license from Mian Huang and every other applicable rights holder.
7. Before a public commercial release or institutional license, obtain legal review of coauthor consent, third-party rights, the commercial-use definition, and the contact/contract process.

The skill can disclose and route these terms but cannot technically enforce them or issue a license on an author's behalf.
