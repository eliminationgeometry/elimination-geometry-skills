# License and Use Terms

Last updated: 2026-08-25

This package is publicly inspectable and available for noncommercial research use. It is **source-available**, but it is not represented as Open Source Software under the Open Source Initiative definition because its public licenses do not grant unrestricted commercial use.

## 1. License map

### A. Elimination Geometry research content and skill documentation

The public preprint

> Mian Huang and Xueqin Wang, *Elimination Geometry*, arXiv:2608.17646 (2026), https://arxiv.org/abs/2608.17646

is licensed under the [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-nc-sa/4.0/) (**CC BY-NC-SA 4.0**).

Unless a file states different terms, original EG research prose and original skill documentation in this package—including `SKILL.md` and the authored canonical-memory, routing, schema, and protocol files under `references/`—are offered under the same CC BY-NC-SA 4.0 license to the extent the applicable rights holder has authority to license them.

That license permits sharing and adaptation for noncommercial purposes, subject to attribution, indication of changes, and ShareAlike. It does not grant commercial-use rights.

### B. Original maintenance software

Unless a file states different terms, original software under `scripts/` is offered under the [PolyForm Noncommercial License 1.0.0](https://polyformproject.org/licenses/noncommercial/1.0.0/).

Required Notice: Copyright 2026 Mian Huang. Elimination Geometry skill package. Canonical research record: https://arxiv.org/abs/2608.17646

The PolyForm public license permits the software only for its defined noncommercial purposes. Commercial-use rights are not granted by that license.

### C. Bundled manuscripts, bibliographies, data, models, figures, and third-party material

Files that carry their own copyright notice or license remain governed by those terms. Third-party or vendored materials, datasets, model artifacts, bibliography records, and quoted material are not relicensed by this package. If a bundled file has no explicit public license, its inclusion does not grant rights beyond applicable law, an existing agreement, or permission from its rights holder.

## 2. Commercial use

Commercial use is not granted by the public licenses above. A separate written commercial license is required before using the licensed package material in or for, for example:

- a paid product, hosted service, commercial API, consulting deliverable, or fee-bearing training product;
- a proprietary internal workflow intended for commercial advantage or an anticipated commercial application;
- commercial redistribution, sublicensing, model training, fine-tuning, or retrieval services based materially on the package;
- marketing or product claims that use the EG name, framework, text, or bundled corpus.

Commercial licensing must be obtained from Mian Huang and any other applicable author or rights holder whose material is involved. Access to the files, execution by Codex or another model, or a citation does not itself provide commercial permission.

Questions about permissions and requests for commercial licensing may be sent to the official project contact:

> **Elimination Geometry Project**  
> [eliminationgeometry@gmail.com](mailto:eliminationgeometry@gmail.com)

Sending an inquiry, or receiving an acknowledgment, does not grant permission. Commercial authorization is valid only when confirmed in a separate written agreement by the applicable rights holders.

Nothing here limits rights that do not require permission under applicable law, including any applicable copyright exception or limitation.

## 3. Attribution

For scholarly use, cite the canonical preprint and preserve the arXiv link, author names, applicable license notices, and a clear indication of modifications. See `CITATION.cff` and `references/citation-and-licensing.md` for copy-ready metadata.

Attribution must not imply endorsement by the authors or rights holders.

## 4. No warranty

To the extent permitted by law, the package is provided as-is and without warranties. Research statements, code, certificates, and empirical artifacts retain the proof, provenance, and validation boundaries stated in the sources.

## 5. Rights-clearance note

This file records the intended public-use boundary; it is not legal advice. Before public commercial release, institutional licensing, or redistribution of the complete bundled corpus, the authors should obtain legal review confirming ownership, coauthor consent, third-party licenses, dataset/model terms, and the appropriate commercial contact process.
