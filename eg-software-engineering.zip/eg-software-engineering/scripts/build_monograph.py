#!/usr/bin/env python3
"""Build and verify the monograph snapshot bundled with an EG skill.

This is a maintainer utility. It copies the exact source, provenance records,
figures, and reproducibility artifacts needed for source-grounded research;
it deliberately excludes the compiled monograph PDF and LaTeX build debris.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path


ROOT_FILES = (
    ".latexmkrc",
    "README.md",
    "MONOGRAPH_ARCHITECTURE.md",
    "MANUSCRIPT_STATUS.md",
    "RELEASE_NOTES_v1_9.md",
    "CLAIM_STATUS.md",
    "PROOF_MAP.md",
    "SOURCE_MAP.md",
    "book_manifest.json",
    "main.tex",
    "egbook.sty",
    "references.bib",
    "thematic_index_crossrefs.tex",
    "build.sh",
    "build_windows.bat",
    "latexmkrc.example",
    "refresh_release_manifest.py",
    "ACTIVE_SET_DEPTH_SEPARATION_PRIORITY_AUDIT_2026-08-17.md",
    "ACTIVE_SET_THEOREM_PROOF_AUDIT_2026-08-17.md",
    "DEPLOYMENT_CONFLICT_THEOREM_PRIORITY_AUDIT_2026-08-17.md",
    "GIBBS_RIGIDITY_PRIORITY_AUDIT_2026-08-13.md",
    "LITERATURE_PRIORITY_NOTES_v1_6.md",
    "FLAGSHIP_LEARNING_THEOREM_FEASIBILITY.md",
    "OPERATIONALLY_EXPOSED_MEMORY_CONFLICT_GO_NO_GO.md",
    "PARTIAL_DOMAIN_FLAGSHIP_GO_NO_GO.md",
)

TREE_DIRS = (
    "frontmatter",
    "chapters",
    "chapter_appendices",
    "appendices",
    "part_notes",
    "figures",
    "reproducibility",
)

EXCLUDED_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", "tmp"}
EXCLUDED_NAMES = {".DS_Store"}

PARTS = (
    ("The Structural Realizability Problem", range(1, 5)),
    ("Native Defects and Elimination Calculus", range(5, 9)),
    ("Validity of Defects and Representations", range(9, 11)),
    ("Structural Obstructions under Shared Deployment", range(11, 16)),
    ("Resources, Operational Semantics, and Composition", range(16, 19)),
    ("Statistical Certification", range(19, 21)),
    ("Obstruction-Aware Learning and Structural Repair", range(21, 25)),
    ("Stress Tests, Boundaries, and Research Program", range(25, 28)),
)

STATEMENT_ENVS = (
    "definition",
    "assumption",
    "theorem",
    "proposition",
    "lemma",
    "corollary",
    "remark",
    "example",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_inline(value: str) -> str:
    value = re.sub(r"%[^\n]*", " ", value)
    value = re.sub(r"\\(?:textbf|emph|textit|texorpdfstring)\b", " ", value)
    value = value.replace("~", " ")
    return re.sub(r"\s+", " ", value).strip()


def extract_balanced(text: str, start: int, opening: str, closing: str) -> tuple[str, int]:
    if start >= len(text) or text[start] != opening:
        return "", start
    depth = 0
    for index in range(start, len(text)):
        char = text[index]
        if char == opening and (index == 0 or text[index - 1] != "\\"):
            depth += 1
        elif char == closing and (index == 0 or text[index - 1] != "\\"):
            depth -= 1
            if depth == 0:
                return text[start + 1 : index], index + 1
    return text[start + 1 :], len(text)


def line_number(text: str, position: int) -> int:
    return text.count("\n", 0, position) + 1


def command_entries(text: str, commands: tuple[str, ...]) -> list[tuple[int, str, str]]:
    pattern = re.compile(
        r"\\(" + "|".join(map(re.escape, commands)) + r")(?:\*)?(?:\[[^]]*\])?\s*\{"
    )
    entries: list[tuple[int, str, str]] = []
    for match in pattern.finditer(text):
        brace = text.find("{", match.start())
        value, _ = extract_balanced(text, brace, "{", "}")
        entries.append((line_number(text, match.start()), match.group(1), normalize_inline(value)))
    return entries


def statement_entries(text: str) -> list[tuple[int, str, str, str]]:
    pattern = re.compile(r"\\begin\{(" + "|".join(STATEMENT_ENVS) + r")\}")
    entries: list[tuple[int, str, str, str]] = []
    for match in pattern.finditer(text):
        cursor = match.end()
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        title = ""
        if cursor < len(text) and text[cursor] == "[":
            title, cursor = extract_balanced(text, cursor, "[", "]")
        following = text[cursor : cursor + 500]
        label_match = re.search(r"\\label\{([^}]+)\}", following)
        label = label_match.group(1) if label_match else ""
        entries.append(
            (
                line_number(text, match.start()),
                match.group(1).capitalize(),
                normalize_inline(title),
                label,
            )
        )
    return entries


def allowed_tree_file(path: Path) -> bool:
    return not any(part in EXCLUDED_DIRS for part in path.parts) and path.name not in EXCLUDED_NAMES


def source_files(book_root: Path) -> list[Path]:
    files: list[Path] = []
    for name in ROOT_FILES:
        path = book_root / name
        if path.is_file():
            files.append(path)
    for dirname in TREE_DIRS:
        root = book_root / dirname
        if not root.is_dir():
            continue
        files.extend(path for path in root.rglob("*") if path.is_file() and allowed_tree_file(path))
    return sorted(files, key=lambda path: path.relative_to(book_root).as_posix())


def copy_snapshot(book_root: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    for source in source_files(book_root):
        relative = source.relative_to(book_root)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def chapter_path(monograph_dir: Path, number: int) -> Path:
    matches = sorted((monograph_dir / "chapters").glob(f"ch{number:02d}_*.tex"))
    if len(matches) != 1:
        raise ValueError(f"expected one source for chapter {number}, found {len(matches)}")
    return matches[0]


def render_structure_index(monograph_dir: Path) -> str:
    metadata = json.loads((monograph_dir / "book_manifest.json").read_text())
    lines = [
        "# Monograph Structure and Statement Index",
        "",
        "> Generated by `scripts/build_monograph.py` from the bundled source. Use it to locate exact chapter statements and complete chapter-local proofs; it is not a substitute for hypotheses or proof text.",
        "",
        f"**Edition:** Version {metadata.get('version', 'unknown')} ({metadata.get('date', 'date unknown')})  ",
        f"**Title:** {metadata.get('title', 'Elimination Geometry')}  ",
        f"**Inventory:** {metadata.get('parts', '?')} parts, {metadata.get('chapters', '?')} chapters, {metadata.get('principal_theorem_like_results', '?')} formal-result families, {metadata.get('complete_proof_environments', '?')} complete proof environments.",
        "",
        "## Part and chapter map",
        "",
    ]
    for part_number, (part_title, chapter_numbers) in enumerate(PARTS, 1):
        lines.append(f"### Part {part_number}. {part_title}")
        lines.append("")
        for number in chapter_numbers:
            path = chapter_path(monograph_dir, number)
            text = path.read_text(errors="replace")
            commands = command_entries(text, ("chapter",))
            title = commands[0][2] if commands else path.stem
            relative = path.relative_to(monograph_dir).as_posix()
            lines.append(f"- Chapter {number}: [{title}](monograph/{relative})")
        lines.append("")

    lines.extend(["## Chapter locators", ""])
    for number in range(1, 28):
        path = chapter_path(monograph_dir, number)
        text = path.read_text(errors="replace")
        commands = command_entries(text, ("chapter", "section", "subsection"))
        title = commands[0][2] if commands else path.stem
        relative = path.relative_to(monograph_dir).as_posix()
        proof = monograph_dir / "chapter_appendices" / f"ch{number:02d}_proofs.tex"
        lines.extend(
            [
                f"### Chapter {number}: {title}",
                "",
                f"**Exact chapter:** [`monograph/{relative}`](monograph/{relative})  ",
            ]
        )
        if proof.exists():
            proof_rel = proof.relative_to(monograph_dir).as_posix()
            lines.append(f"**Complete proof file:** [`monograph/{proof_rel}`](monograph/{proof_rel})  ")
        lines.extend(["", "**Sections**", ""])
        for lineno, kind, heading in commands[1:]:
            indent = "-" if kind == "section" else "  -"
            lines.append(f"{indent} L{lineno}: {heading}")
        statements = statement_entries(text)
        if statements:
            lines.extend(["", "**Named statements**", ""])
            for lineno, kind, heading, label in statements:
                title_note = f" — {heading}" if heading else ""
                label_note = f" (`{label}`)" if label else ""
                lines.append(f"- L{lineno}: **{kind}**{title_note}{label_note}")
        lines.append("")

    lines.extend(["## Global appendices", ""])
    for path in sorted((monograph_dir / "appendices").glob("app*.tex")):
        text = path.read_text(errors="replace")
        commands = command_entries(text, ("chapter", "section", "subsection"))
        title = commands[0][2] if commands else path.stem
        relative = path.relative_to(monograph_dir).as_posix()
        lines.extend([f"### {title}", "", f"**Exact source:** [`monograph/{relative}`](monograph/{relative})", ""])
        for lineno, kind, heading in commands[1:]:
            indent = "-" if kind == "section" else "  -"
            lines.append(f"{indent} L{lineno}: {heading}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_manifest(monograph_dir: Path) -> str:
    metadata = json.loads((monograph_dir / "book_manifest.json").read_text())
    lines = [
        "# Monograph Source Manifest",
        "",
        "> Generated by `scripts/build_monograph.py`. Do not edit by hand.",
        "",
        f"Bundled edition: Version {metadata.get('version', 'unknown')} ({metadata.get('date', 'date unknown')}).",
        "The compiled monograph PDF is intentionally not bundled and is not a runtime dependency.",
        "The SHA-256 hashes below identify the exact source, provenance, figure, and reproducibility snapshot.",
        "",
        "| Bundled path | Bytes | SHA-256 |",
        "|---|---:|---|",
    ]
    for path in sorted(p for p in monograph_dir.rglob("*") if p.is_file()):
        relative = path.relative_to(monograph_dir).as_posix()
        lines.append(f"| `monograph/{relative}` | {path.stat().st_size} | `{sha256(path)}` |")
    return "\n".join(lines).rstrip() + "\n"


def build(book_root: Path, skill_root: Path) -> None:
    reference_dir = skill_root / "references"
    destination = reference_dir / "monograph"
    copy_snapshot(book_root, destination)
    (reference_dir / "monograph-structure-index.md").write_text(render_structure_index(destination))
    (reference_dir / "monograph-source-manifest.md").write_text(render_manifest(destination))


def check(book_root: Path, skill_root: Path) -> bool:
    reference_dir = skill_root / "references"
    destination = reference_dir / "monograph"
    errors: list[str] = []
    if not destination.is_dir():
        errors.append(f"missing bundled monograph directory: {destination}")
    else:
        expected = {path.relative_to(book_root) for path in source_files(book_root)}
        actual = {path.relative_to(destination) for path in destination.rglob("*") if path.is_file()}
        for relative in sorted(expected - actual):
            errors.append(f"missing bundled monograph file: {relative}")
        for relative in sorted(actual - expected):
            errors.append(f"unexpected bundled monograph file: {relative}")
        for relative in sorted(expected & actual):
            if sha256(book_root / relative) != sha256(destination / relative):
                errors.append(f"stale bundled monograph file: {relative}")

        structure_path = reference_dir / "monograph-structure-index.md"
        manifest_path = reference_dir / "monograph-source-manifest.md"
        if not structure_path.exists():
            errors.append("missing generated reference: monograph-structure-index.md")
        elif structure_path.read_text() != render_structure_index(destination):
            errors.append("stale generated reference: monograph-structure-index.md")
        if not manifest_path.exists():
            errors.append("missing generated reference: monograph-source-manifest.md")
        elif manifest_path.read_text() != render_manifest(destination):
            errors.append("stale generated reference: monograph-source-manifest.md")

    if errors:
        for error in errors:
            print(f"[ERROR] {error}")
        return False
    count = len(source_files(book_root))
    version = json.loads((destination / "book_manifest.json").read_text()).get("version", "unknown")
    print(f"[OK] Verified Version {version} monograph snapshot: {count} files")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--book-root", type=Path, help="Path to the Elimination_Geometry source directory")
    parser.add_argument("--check", action="store_true", help="Verify instead of rebuilding the bundled snapshot")
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    default_root = skill_root.parent.parent / "Elimination_Geometry"
    book_root = (args.book_root or default_root).resolve()
    required = ("book_manifest.json", "main.tex", "chapters", "chapter_appendices", "appendices")
    missing = [name for name in required if not (book_root / name).exists()]
    if missing:
        print(f"[ERROR] Book root is missing: {', '.join(missing)}")
        return 2

    if args.check:
        return 0 if check(book_root, skill_root) else 1
    build(book_root, skill_root)
    print(f"[OK] Built monograph resources in {skill_root / 'references' / 'monograph'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
