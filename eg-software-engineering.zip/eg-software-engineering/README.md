# EG Software Engineering

`eg-software-engineering` applies Elimination Geometry's task-first, local-to-global method to codebases, software architecture, integration, state, dataflow, distributed systems, numerical software, performance, reliability, compatibility, and deployment.

See [`SKILL.md`](SKILL.md) for operating instructions and the boundary with physical and scientific engineering analysis.

## Contact

For research collaboration, technical questions, corrections, citation questions, permission requests, and commercial licensing inquiries, contact:

> **Elimination Geometry Project**  
> [eliminationgeometry@gmail.com](mailto:eliminationgeometry@gmail.com)

This is the official public contact for the package. An inquiry does not itself grant permission; commercial authorization requires a separate written agreement from the applicable rights holders.

## Citation and license

Canonical reference: [*Elimination Geometry* — arXiv:2608.17646](https://arxiv.org/abs/2608.17646).

See [`CITATION.cff`](CITATION.cff), [`LICENSE.md`](LICENSE.md), and [`references/citation-and-licensing.md`](references/citation-and-licensing.md) for citation metadata and controlling use terms.
