# EG Software-Engineering Artifact Schemas

Use these records only when they improve multi-turn work, handoff, reproducibility, or a high-consequence change. Populate only relevant fields, preserve unknowns, and update an existing record instead of creating parallel versions.

## 1. Software state

```markdown
# EG Software State: <system/project>

- Mode: build | diagnose | optimize | verify
- Verdict: ordinary | EG-structured | certified EG | unresolved
- Task/SLO and native metric:
- Version, environment, platform, and workload:
- Reproduction status:
- Shared or restricted boundary:
- Earliest exposed failing interface:
- Minimal executable witness:
- Leading diagnostic account:
- Serious alternatives:
- Evidence grade: observed | reproduced | inferred | certified | validated | unresolved
- Change status: proposed | implemented | locally verified | integrated | operationally validated
- Next highest-information action:
- Files/configurations changed:
- Last updated:
```

## 2. Software system card

```markdown
# Software System Card

## Executable contract
- User/product objective:
- Input or workload envelope:
- Output/action/side effects:
- Correctness, performance, reliability, and compatibility metrics:
- Risk aggregation and quantifiers:
- Security, privacy, deployment, and resource constraints:
- Authorized interventions:
- Falsifying outcome:

## Typed system
- Raw/source state:
- Retained state, representation, key, or schema:
- Decoder/action/consumer:
- Call path, dataflow, protocol, or transition:
- User-visible observer or invariant:
- Identity, ownership, authorization, version, and lifecycle:
- Ordering, null/missing, units, precision, and provenance semantics:
- Recursive/future-update requirement:

## Local versus deployed
- Context/request/workload variable:
- Locally adequate behavior or configuration:
- Shared/restricted implementation grammar:
- What may adapt:
- What must remain common:
- Task quotient / ignored distinctions:
- Suspected eliminated distinction:
- Native failure metric or diagnostic proxy:

## Evidence
- Relevant repository instructions:
- Tests, logs, traces, profiles, and telemetry:
- Reproduction command/configuration:
- Smallest witness:
- Earliest unresolved gate:
```

If no shared grammar exists, solve the task as ordinary software. If no exact insertion or collision object exists, do not label a proxy a certified EG defect.

## 3. Failure and diagnostic ledger

```markdown
# Software Failure and Diagnostic Ledger

| ID | Observation | Evidence grade | Candidate account | Mechanism | Discriminating test | Result | Status |
|---|---|---|---|---|---|---|---|
| F1 | | observed/reproduced/inferred/certified/validated | specification; architecture; evidence; protocol; algorithm/numerics; implementation; resources | | | | open/supported/refuted/unresolved |

Earliest supported failing interface:
Alternative explanations still live:
Current verdict:
```

Do not mark a cause supported merely because a refactor fixes one example.

## 4. Reproduction and witness record

```markdown
# Software Witness Record: <ID>

- Target failure or claim:
- Artifact, revision, and configuration:
- Input/request/history/workload A:
- Input/request/history/workload B:
- Why the shared key/state/schema/model/policy treats them equally:
- Why the executable contract requires different behavior:
- Version, platform, permissions, resources, and lifecycle held fixed:
- Call/data/protocol transmission path:
- Exposing output, invariant, observer, or SLO:
- Old-system result:
- Minimal reproduction command/test:
- Zero-obstruction or task-invisible control:
- Repair implied by the witness:
- Scope and nonclaims:
```

## 5. Test or benchmark contract

```markdown
# Software Test or Benchmark Contract

## Decision
- Competing mechanisms:
- Result favoring each mechanism:
- Result leaving the diagnosis unresolved:

## Conditions
- Revision/build/configuration:
- Input, data, workload, and distribution:
- OS/runtime/dependencies/hardware:
- Concurrency, affinity, cache, warmup, compilation, and I/O:
- Seeds, repetitions, confidence intervals, and exclusions:
- Correctness, information, quality, and resource budgets:

## Controls
- Locally tuned or oracle baseline:
- Zero-obstruction control:
- Task-invisible/no-transmission control:
- Strong fixed-class implementation or numerical baseline:
- Generic equal-resource change:

## Metrics
- Correctness/task:
- Architecture/representation:
- Protocol/transmission:
- Algorithm/numerics:
- Latency/throughput/allocation/memory/I/O/network/energy:
- Initialization/refresh/synchronization/teardown:
- Reliability/error/security as applicable:

## Reproducibility
- Commands and configuration:
- Raw logs/traces/profiles/results:
- Acceptance and failure thresholds:
- Saved artifacts:
- Frozen or independent evaluation unit:
```

## 6. Code and contract change record

```markdown
# Software Change Contract

- Diagnosed witness and interface:
- Intended mechanism:
- Smallest proposed change:
- Files/components/configurations affected:
- Public API, schema, data, and behavior compatibility:
- State migration, replay, fallback, and rollback:
- Security, privacy, ownership, and authorization invariants:
- Resources added or removed:
- Out-of-scope behavior preserved:
- Regression that must fail before and pass after:
- Integration and benchmark obligations:
- Generic alternative or negative control:
- Risks introduced:
- Deployment and authorization boundary:
```

## 7. Verification matrix

```markdown
# Software Verification Matrix

| Layer | Claim | Test/evidence | Configuration | Result | Status |
|---|---|---|---|---|---|
| Unit/property/type/static | | | | | pass/fail/not run |
| Witness regression | | | | | |
| Contract/integration/end-to-end | | | | | |
| Replay/migration/continuation | | | | | |
| Zero-obstruction/task-invisible control | | | | | |
| Fixed-class saturation/numerical resolution | | | | | |
| Matched-quality resource benchmark | | | | | |
| Concurrency/fault/platform/security | | | | | |
| Frozen workload/staging/operational endpoint | | | | | |

Strongest conclusion authorized:
Commands and configurations run:
Skipped layers and rationale:
Remaining alternatives and operational risk:
```

## 8. Architecture decision record

```markdown
# Architecture Decision Record: <short title>

- Decision:
- Date/revision:
- Task, SLOs, and constraints:
- Reproduction and evidence:
- Minimal witness:
- Alternatives considered:
- Why the selected change is mechanism-matched:
- API, data, migration, security, and resource consequences:
- Tests and benchmarks completed:
- Deferred validation:
- Rollback or stop condition:
- Owner/approver when applicable:
```

This record documents reasoning; it does not authorize production deployment or replace organizational review.
