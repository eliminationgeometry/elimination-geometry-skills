# EG Software-Engineering Source Router

Use this router only when a software answer needs an exact EG definition, theorem, proof, algorithm, provenance statement, or corpus-backed comparison. The canon and playbook are sufficient for ordinary software work. A route identifies where to reread; it is not evidence by itself.

## 1. Source authority

1. Use `software-engineering-canon.md` for the practical operating method.
2. Use `monograph-canon.md` and `validation-dependency-map.md` for current book organization and gate semantics.
3. Use exact monograph chapters and proof appendices for book-proved statements.
4. Use exact Core16 or Extend17 TeX for manuscript-specific algorithms, experiments, and results summarized by the book.
5. Use repository evidence, official documentation, standards, and primary technical literature for actual software behavior, APIs, security, performance methods, and historical priority.
6. Use benchmarks and reproducibility artifacts only within their recorded workload, oracle, hardware, quality, and validation contracts.

Do not infer identity because the same formula or vocabulary appears in another field. Compare executable task, eliminated state, deployed grammar, quantifiers, transmission path, consequence, and evidence.

## 2. Monograph routes for software engineering

| Software need | Primary monograph route |
|---|---|
| local components pass, one shared deployment fails | Chapters 1–2 |
| separate specification, architecture, data, optimization, and implementation | Chapter 3 |
| shared prediction, graph, decision, and one-pass examples | Chapter 4 |
| native objectives, partial minimization, and exact defect identities | Chapter 5 |
| pointwise, plug-in, exactified, variational, and coupling branches | Chapter 6 |
| stale caches/fields, approximate inner solves, and exactification | Chapter 7 |
| graph smoothing, probability validity, and proper scores | Chapter 8 |
| local constraint consistency, integrability, and cycle repair | Chapter 9 |
| padding, target-calling, lifts, and visible complexity | Chapter 10 |
| architecture obstruction, saturation, and class-versus-solver diagnosis | Chapter 11 |
| transfer from representation mismatch to native loss | Chapter 12 |
| shared decisions, rectangularity, coordination, and memory | Chapter 13 |
| branches, singularities, roots, and spectral subspaces | Chapter 14 |
| state, chart, quotient, and randomized architecture repair | Chapter 15 |
| bits, states, compute, carrier loss, and decoder saturation | Chapter 16 |
| pipelines, replacement, contexts, ordering, and task visibility | Chapter 17 |
| repeated transformations, composition, base change, and limits | Chapter 18 |
| finite-data confidence worlds and common-deployment decisions | Chapter 19 |
| evidence compression and recursive certificate state | Chapter 20 |
| typed structural learning and deployed ML systems | Chapter 21 |
| saturation, diagnosis, matched repair, and validation | Chapter 22 |
| partial transport, cycles, holonomy, and recovery | Chapter 23 |
| applied mechanism laboratories and empirical boundaries | Chapter 24 |
| quantum/noncommutative software interfaces when genuinely relevant | Chapter 25 |
| stopping boundaries for structural explanations | Chapter 26 |
| falsifiable research-program design | Chapter 27 |

Use `monograph-structure-index.md` to locate exact statements and proof files. Read Appendix E for dependency wording and Appendix F for controlled terminology when needed.

## 3. Core16 routes

### Objectives, exactification, and numerical software

- `core16/eg1.tex`: primitive elimination, insertion defect, and P/G/X/V/C design contracts.
- `core16/eg2.tex`: integrability, representation integrity, semantic validity, converses, and leverage.
- `core16/x_algo.tex`: stale and approximate exactification, local rates, Schur-channel deflation, Ritz certificates, switching, and operational experiments.

Use for surrogate and profile computations, stale cached auxiliaries, approximate inner solves, numerical libraries, preconditioners, slow modes, branch switching, and matrix-free acceleration. Search current multifidelity, surrogate, MM/EM, variable-projection, preconditioning, deflation, and numerical-linear-algebra literature for inherited methods and priority.

### Pipelines, composition, and replacement

- `core16/eg3.tex`: hard/soft path composition, conditional KL, refinement, base change, and temperature.
- `core16/foundation.tex`: defect fibrations, towers, curvature, coherence, and abstract composition.
- `core16/operation.tex`: contextual equivalence, task envelopes, safe replacement, order, and operational resolution.

Use for multi-stage dataflows, compiler or model pipelines, module substitution, ordered transformations, chained compression, and local contracts that may not compose globally.

### Architecture, resources, and obstruction

- `core16/eot.tex`: metric, graph-flow, topological, packing, and incompatibility transfer into native lower bounds.
- `core16/cot.tex`: architecture choice, shared decisions, rectangularity, and coordination.
- `core16/singular.tex`: branches, discriminants, singular oracle geometry, and catastrophe taxes.
- `core16/lift.tex`: extended formulations, padding and target-calling no-go results, target-visible capacity, and computation-to-defect interfaces.
- `core16/architecture.tex`: deployment/evidence/recursive carriers, rate–distortion, transmission, exposure, and common actions.

Use for cache and state collisions, APIs and schemas, finite-memory machines, shared configuration, representations, streaming/sketching, platform branches, action menus, resource lower bounds, and current-versus-future behavior.

### Evidence, ML systems, and adaptive testing

- `core16/statistical.tex`: confidence worlds, simultaneous transport, architecture certificates, and detectability.
- `core16/certificate_stat.tex`: resolution, evidence carriers, posterior guidance, and recursive certificate state.
- `core16/egml.tex`: static model/architecture/statistics/optimization audit and OALI.
- `core16/egml2.tex`: adaptive acquisition, evidence repair, memory/state expansion, and adaptive OALI.

Use for data/ML pipelines, architecture evaluation, finite test evidence, monitoring, adaptive testing, deployment ambiguity, and separating scientific target, data, model class, training, implementation, and resources.

## 4. Extend17 routes

### Information, communication, compression, and acquisition

- `extend17/deployment_info.tex`
- `extend17/certificate_info.tex`
- `extend17/recursive.tex`
- `extend17/wavelet_acquisition.tex`

Use for task-aware serialization and compression, communication budgets, sketches, certificate carriers, active acquisition, and recursive state.

### Stateful, streaming, and history-dependent systems

- `extend17/timescale_eg.tex`
- `extend17/dependent.tex`
- `extend17/long_memory_forecasting.tex`
- `extend17/Mori_Zwanzig_Elimination_Geometry.tex`
- `extend17/task_visible.tex`

Use for event histories, finite-memory services, streaming models, temporal aggregation, current-output versus continuation equivalence, closure, and multiscale state.

### Multi-agent, scheduling, and operational systems

- `extend17/Strategic_Regret_Geometry.tex`
- `extend17/Recursive_Strategic_Elimination.tex`
- `extend17/queue.tex`
- `extend17/microstructure_event_order.tex`
- `extend17/execution_visible_market_states.tex`

Use for shared agent policies, recursive strategic state, queues, scheduling, event order, distributed summaries, and operationally visible state.

### Coarse-graining and stochastic dynamics

- `extend17/Task_Conditioned_Renormalization.tex`
- `extend17/continuous.tex`
- `extend17/Hidden_Entropy_Production.tex`

Use only when software implements coarse-grained stochastic state, diffusion, path-space compression, or task-conditioned macrostates; the domain model itself remains outside a purely software claim.

## 5. Software pattern routes

| Pattern | Nearest EG route | External authority also required |
|---|---|---|
| cache key or memoization collision | Chapters 15–17; `architecture.tex`, `operation.tex` | cache/library/runtime documentation |
| API/schema loses null, order, units, provenance, or version | Chapters 10, 15, 17 | schema/protocol specifications |
| current state correct, future transition wrong | Chapters 13, 15–17, 20; `recursive.tex` | state-machine, distributed-systems, or formal-methods literature |
| aggregate loses causality/event order | Chapters 17–18; event-order extensions | streaming/distributed-database literature |
| one model/config fails across environments | Chapters 1–3, 11–13, 19, 21–22 | ML systems or configuration-optimization literature |
| numerical solver slowed by stale/hidden mode | Chapters 6–7; `x_algo.tex` | numerical linear algebra and solver documentation |
| representation or resource lower bound | Chapters 10–12, 15–16 | complexity, coding, streaming, or communication literature |
| pipeline substitutions fail to compose | Chapters 17–18; `operation.tex`, `eg3.tex` | PL, compiler, API, or systems semantics |
| evidence insufficient to choose architecture | Chapters 19–22; statistical Core papers | statistics, experiment design, and benchmark methodology |

EG does not establish cryptographic security, privacy, linearizability, serializability, memory safety, or regulatory compliance merely by identifying information loss. Use the relevant formal definitions, tools, standards, and specialist review.

## 6. Exact-source loading rule

Reread exact sources before stating:

- a definition, formula, theorem, assumption, constant, rate, proof step, or algorithm guarantee;
- that the monograph proves rather than summarizes a result;
- that an EG mechanism transfers to a software architecture or algorithm;
- a novelty, priority, standards, security, or state-of-the-art claim;
- a benchmark value, complexity, oracle privilege, or validation conclusion;
- publication-ready technical prose or citations.

For book results, read the statement, assumptions, interpretation, proof roadmap, and proof appendix. For manuscript results, read the exact TeX, experiments, and bibliography. For software behavior, verify against the repository, running system, official documentation, and current primary sources even when EG supplies the structural interface.
