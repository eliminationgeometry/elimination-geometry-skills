# Core16 Full Abstracts

> Generated from all 16 bundled TeX sources in canonical reading order. Load this file completely during corpus initialization, after `core-canon.md`.

## Contents

1. Elimination Geometry I — `core16/eg1.tex`
2. Elimination Geometry II — `core16/eg2.tex`
3. Exactification and Optimization Certificates — `core16/x_algo.tex`
4. Elimination Geometry III — `core16/eg3.tex`
5. Elimination Obstruction Transfer — `core16/eot.tex`
6. Compositional Obstruction Transfer — `core16/cot.tex`
7. Foundations of Elimination Geometry — `core16/foundation.tex`
8. Quantum Elimination Geometry — `core16/quantum.tex`
9. Singular Elimination Geometry — `core16/singular.tex`
10. Lift Complexity — `core16/lift.tex`
11. Operational Semantics — `core16/operation.tex`
12. Statistical Elimination Geometry — `core16/statistical.tex`
13. Certificate Statistics — `core16/certificate_stat.tex`
14. Resource-Constrained Architectures — `core16/architecture.tex`
15. EG for Machine Learning and AI — `core16/egml.tex`
16. EG for Adaptive Learning Systems — `core16/egml2.tex`

---

## Core 01: Elimination Geometry I

**Full title:** Elimination Geometry I: A Certified Calculus of Auxiliary-Field Coupling  
**Exact source:** [`core16/eg1.tex`](core16/eg1.tex)

### Abstract

Elimination geometry studies what remains after an auxiliary variable is
optimized out: an exact, nonnegative defect that prices every nonoptimal
auxiliary choice in the units of the original objective.
Many statistical procedures eliminate latent posteriors, variational laws,
IRLS weights, spectral optimizers, or other inner states separately across
locations, tasks, and replicas.  Reusing those states nonlocally can improve
coherence or computation, but can also change the target, destroy touching,
or produce a certificate in the wrong units.  We develop an algorithmic
calculus starting from a certified
elimination
\[
 \calJ(\Theta)=\min_A\calH_0(\Theta,A),\qquad
 \calH_0(\Theta,A)-\calJ(\Theta)=\mathcal D_\Theta(A)\ge0,
\]
with a directed Bregman defect in conjugate-complete cases.  Pointwise
elimination (P) is the uncoupled baseline; plug-in globalization (G) inserts
an externally transformed field and pays its exact defect; exactification
(X) restores the original target score and accepts steps through a
finite-sample residual certificate, with a defect-adaptive trust law and
inner-optimality tolerances; variational coupling (V) optimizes the field
inside a penalized objective; and a separate fixed-marginal layer (C)
changes only cross-coordinate dependence.  Primal and dual insertion
certificates also cover convex--concave saddle elimination.  Part II audits
integrability, representation, and structural limits of this calculus.

Two worked statistical constructions make the certificates operational.
For quotient-safe spectral profiling, Ky Fan elimination gives an exact
rank-\(r\) insertion defect, feasible projector pooling realizes G, and a
graph-coupled V objective has exact block updates and an aggregate consensus
endpoint; an eigengap supplies the defect-to-subspace exchange condition.
For graph-indexed distributional forecasting, a signed Richardson proposal
is projected onto the CDF set.  Its linear core is an exact unconstrained
variational solution in the ambient Hilbert space.  If
\(\mathbf L^m\) has a positive off-diagonal entry---in particular on
unweighted paths with at least three vertices for \(m\ge2\)---the induced penalty fails the
Dirichlet gate at small coupling.  This diagnoses the raw probability
failure without equating the repaired G field with the CDF-constrained V
solution.  Projection restores validity and cannot worsen squared-CDF error
or graph roughness.  For empirical CDF input we derive an exact
bias--variance ledger with graph effective dimension
\(\operatorname{tr}(S_{\tau,m}^2)\), together with an unbiased fixed-filter
raw-risk estimate and an observable projection deduction.  On growing paths,
for every real source smoothness \(s>0\) and integer qualification \(m\ge s\),
the repaired forecast attains, in a calibrated regime, the sharp average-CRPS rate
\(N^{-1}+R^{2/(4s+1)}N^{-4s/(4s+1)}\); an embedded Bernoulli experiment
gives the matching minimax lower bound.  For \(s\le1\) the order-one Markov
resolvent needs no repair, whereas higher qualification for \(s>1\) loses
graph-universal linear probability validity and requires a nonlinear
validity interface.  Further EM, MM, amortized-inference, quantum-Gibbs, and
LogDet instances stress-test the certificates.

## Core 02: Elimination Geometry II

**Full title:** Elimination Geometry II: Integrability, Representation, and Structural Limits  
**Exact source:** [`core16/eg2.tex`](core16/eg2.tex)

### Abstract

Elimination geometry studies what remains after an auxiliary variable is
optimized out: an exact, nonnegative defect that prices every nonoptimal
auxiliary choice in the units of the original objective.
Part I introduces a constructive elimination--coupling calculus that takes a
declared certified lift as its interface.  This Part II audits that
interface, taking a certified elimination
\(\cJ(\Theta)=\inf_A\cH_0(\Theta,A)\) and its nonnegative defect
\(\cD_\Theta(A)=\cH_0(\Theta,A)-\cJ(\Theta)\) as primitive, in three
theorem families.

First, integrability.  Locally reported gaps form a repeated
partial-elimination tower exactly when they are nonnegative, touching, and
have zero circulation on every elementary elimination square; approximate
curvature bounds elimination-order ambiguity.  In finite spaces, Hodge
projection and a witness-constrained quadratic program construct a nearest
certified repair and split its cost exactly into curvature and
certification taxes, plus a globally supported period tax on a general
complex that is invisible to every local face test.

Second, representation and price.  A gate handles invertible coordinates
and surjective refinements, the latter being valid exactly when coherence
descends by fiberwise minimization; consequently no nonconstant strictly
convex separable raw-weight penalty survives duplication of
output-equivalent components.  Unrestricted lift design is vacuous: dummy
lifts make coherence free and target-calling lifts manufacture any local
positive-semidefinite metric.  Conditional on an admissible lift, the
fidelity--coherence frontier
\(\mathfrak F_\Theta(r)=\inf\{\cD_\Theta(A):\cR(A)\le r\}\)
separates irreducible coherence cost from external-design inefficiency.  An
augmented modal Gram block is a complete fingerprint of the unconstrained
quadratic lift--coupling germ under origin-preserving linear equivalence,
placing target-shift value, gradient, and transmitted outer curvature in one
positive-semidefinite exchange account.  Its contraction filter yields the
aligned Gaussian risk ledger and, for smoothers commuting with the penalty,
an exact reading of external inefficiency,
because every positive-definite self-adjoint contraction in the
unconstrained quadratic class is the variational solution of an induced
penalty.  Algebraic validity is not
semantic validity.  Bernstein spectral functions map every finite weighted
graph Laplacian to a possibly nonlocal Laplacian.  Conversely, a tunable
weighted three-node path gives an exact failure interval whenever a spectral
function grows locally faster than linearly.  Hence
\((I+\lambda L^\nu)^{-1}\) is Markov for every weighted graph and every
\(\lambda>0\) exactly for \(0<\nu\le1\), and the only graph-universal
polynomial spectral penalties are nonnegative multiples of \(L\).  This
bounds linear mechanisms, not probability-valued estimators: Part I's
nonlinear CDF repair escapes it, retains an exact
graph-effective-dimension risk bound, and attains the matching minimax CRPS
rate for every real graph-source smoothness on growing paths.

Third, converses and impossibility.  Target-\(k\)-jet preservation after
freezing a coupled lift forces subtraction of the defect \(k\)-jet, uniquely
modulo a \(k\)-flat term.  The canonical model splices the target's
low-order jet to the lift's higher-order tail; in a conjugate lift an exact
transmission map identifies which auxiliary perturbations reach X curvature,
and an affine natural-parameter map transmits none.  A perturbation theorem for
approximate defect jets yields quantitative score error, quasi-descent, and
stationary limits under summable certification error.  Fixed-marginal
coupling cannot improve additive coordinate targets and obeys a
dependence--benefit frontier.  In
entropy-regularized control, reversing the certified KL direction destroys
every dimension-free performance modulus.  In a noncommutative Gibbs fiber,
measured KL is only a lower certificate; one fixed measurement preserves an
entire faithful family's Umegaki defects exactly if and only if that family
commutes.  A classical Polyakov fiber checks the same ledger on a
degenerate continuum elimination.  All definitions used here are restated,
so Part II can be read
independently.

## Core 03: Exactification and Optimization Certificates

**Full title:** Exactification and Optimization Certificates: Local Rates, Leverage Deflation, and Certified Switching  
**Exact source:** [`core16/x_algo.tex`](core16/x_algo.tex)

### Abstract

Suppose a target is obtained by eliminating an auxiliary variable,
\(\cJ(\theta)=\inf_a\cH(\theta,a)\).  A field computed at another
problem, layer, or iteration can be cheaper and geometrically better
conditioned than a fresh pointwise field, but direct insertion changes the
target by the nonnegative defect
\(d_A(\theta)=\cH(\theta,A)-\cJ(\theta)\).  Defect-jet exactification
resolves this tension by keeping the target value and score exact while
allowing frozen auxiliary information to act only through higher-order
geometry.  It is the X branch of the P/G/X/V taxonomy, but exactification is
the descriptive name used throughout this paper.

We first consolidate the inherited exactification foundation into one
executable account.
Its canonical order-\(k\) model obeys the jet-splicing normal form
\[
 Q_{A,x}^{(k)}
 =T_x^k\cJ+(\Id-T_x^k)\cH(\cdot,A),
\]
up to a \(k\)-flat term.  Thus exactification takes the low-order jet from
the target and only the Taylor tail from the frozen lift.  For a
conjugate-complete lift
\[
 \cH(\theta,a)=c(\theta)+\Phi(a)-\langle a,\eta(\theta)\rangle,
\]
two frozen fields differ after exactification only through
\(-\langle A-B,\eta-T_x^k\eta\rangle\).  This yields an explicit
transmission operator and an affine no-go theorem for field selection.

The same inherited defect calculus supplies the safety layer.  Its Hessian
separates a positive pullback metric from a signed
mismatch--nonlinearity interaction, yielding a defect-scaled stabilization
and refresh law.  Inner optimality residuals produce computable value,
score, mismatch, and majorization budgets.  The independent increment then
couples this foundation to speed.  We recast the classical MM/EM tangent-map
rate identity for a general eliminated lift and show that, at an
oracle-consistent solution,
\[
 DT_X=(H+P)^{-1}P,\qquad P=C B_a^{-1}C^\top+R,
\]
where the first term is an auxiliary-coordinate-invariant Schur leverage,
\(R\) is declared stabilization, and derivatives of stale or lagged field
rules cancel to first order.  Classical invariant-subspace deflation with
optimal tail damping annihilates the \(r\) largest-leverage modes and has
remaining contraction
\((\lambda_p-\lambda_{r+1})/(\lambda_p+\lambda_{r+1})\); finite-rank
leverage is removed by a finite-rank correction.  A Ritz-residual theorem
in target-Hessian coordinates gives a common-rotation-safe certificate for
approximate leverage modes.  Finally, one switching theorem combines stale
fields, inexact inner scores, approximate leverage subspaces, and a
residual-safe fallback.  Under explicit forcing and repair assumptions it
proves global target stationarity, eventual accelerated-branch activation,
and recovery of the sharp local factor.  A reproducible nonlinear
elimination laboratory compares pointwise, plug-in, unrelaxed,
scalar-relaxed, and leverage-deflated constructions and reports target
score, measured contraction, refreshes, total Schur products, certificate
rejections, and wall-clock.

The resulting design is: fresh target score, retained geometry only while
its defect is certified, spectral correction only along
elimination-created slow modes, and target descent as the final gate.  This
statement is exact when an auxiliary envelope and insertion ledger exist;
for many deep-learning optimizers it is a disciplined design analogy rather
than an identity.

## Core 04: Elimination Geometry III

**Full title:** Elimination Geometry III: Certified Pushforwards, Base Change, and the Zero-Temperature Limit  
**Exact source:** [`core16/eg3.tex`](core16/eg3.tex)

### Abstract

Elimination geometry studies what remains after an auxiliary variable is
optimized out: an exact, nonnegative defect that prices every nonoptimal
auxiliary choice in the units of the original objective.
An auxiliary-variable certificate is useful at one elimination site only if
it survives composition, refinement, and a change of temperature.  This
paper develops a certified pushforward geometry for those operations.
For a chain of transition costs, hard elimination produces nonnegative
Bellman defects whose sum is exactly the excess path cost.  At finite
temperature, the pointwise log-normalizers are not defects: the canonical
nonnegative object is a conditional relative entropy.  Its chain rule gives
an exact decomposition of the global free-energy gap for arbitrary,
history-dependent trial laws.  On finite state spaces with strictly
positive reference kernels, the entire soft certificate dequantizes to the
hard pathwise defect ledger uniformly over arbitrary, possibly
temperature-dependent trial laws as temperature tends to zero.

The same construction is then made representation-aware.  A commuting
diagram of surjective refinements carries one common family of eliminated
objectives exactly when its edge reports have zero curvature and zero global
periods.  Nonnegativity and fiberwise touching upgrade the resulting
potential to a genuine tower of certified eliminations.  On finite diagrams,
with declared touching sections, orthogonal projection followed by a
witness-constrained convex projection constructs a nearest certified report
and splits repair cost exactly into integrability and certification taxes.

For a measurable refinement \(q:\widetilde{\cA}\to\cA\), disintegration of
the reference measure yields an exact finite-temperature base-change
operator.  The refined free energy equals the coarse free energy with the
pushforward cost, while every trial-law defect separates into a coarse
relative entropy and a conditional fiber relative entropy.  This gives a
universal quotient-faithfulness test: equality for all base objectives is
equivalent to equality of the descended cost itself.  It also identifies a
fiber-volume anomaly.  An approximate descended cost has an exact signed
residual ledger, with two-sided free-energy and oscillation-sensitive
Gibbs-law stability bounds.  On a pullback square, compatible
disintegrations satisfy a measured Beck--Chevalley identity; incompatible
conditional measures produce an explicit Radon--Nikodym anomaly.
Replicating a state changes the normalized Gibbs law only when the
transported reference mass is state dependent; normalized copies remove
the anomaly.

Finally, a conditional Varadhan theorem identifies the general hard target
under temperature-dependent fiber measures: fine energy is augmented by
the conditional large-deviation rate and reduced by exponential
fiber-volume entropy.  Ordinary fiber minimization and the finite
replication ledger are special cases.

Classical ingredients are separated from their joint use as an
objective-denominated certificate calculus.  Hidden-state inference,
entropy-regularized control, latent refinement, and entropic transport
illustrate the scope; noncommutative disintegration, gauge fibers, and
oscillatory path integrals remain boundaries.

## Core 05: Elimination Obstruction Transfer

**Full title:** Elimination Obstruction Transfer: Bregman Flow Duality, Monodromy, and Lower Bounds for Amortized Inference  
**Exact source:** [`core16/eot.tex`](core16/eot.tex)

### Abstract

Amortized inference replaces a pointwise optimization problem by one
deployed map.  Even when the pointwise variational family is adequate, the
map may be unable to follow the geometry or topology of its oracle field.
Existing decompositions identify the resulting amortization gap, but do not
in general turn architectural incompatibility into a computable lower bound
in objective units.

We develop an obstruction-transfer calculus for this purpose.  Starting
from certified eliminations
\[
 \cJ_i=\inf_a\cH_i(a),
 \qquad
 \cD_i(a)=\cH_i(a)-\cJ_i\ge0,
\]
we separate two steps: measure the distance from the oracle field to an
admissible class of global fields, then exchange that geometric distance
into the native defect \(\cD_i\).  On a finite transported graph, the
geometric problem is a Bregman projection subject to edge constraints.  A
Fenchel--Rockafellar calculation gives an exact flow dual: oracle
circulation is reduced by an admissibility support price and a
dual-Bregman congestion price.  Every edge flow is therefore a verifiable
lower certificate; optimizing the flow gives the exact obstruction.  In
the quadratic case this becomes a concave flow problem, yields closed-form
matching and hard-section certificates, and remains valid with approximate
pointwise oracles after residual-calibrated radius inflation.

At the population level, self-couplings of the data law produce sharp
transport lower bounds for Lipschitz inference maps and a general lower
witness for the fidelity--coherence frontier.  Under local strong
convexity, these bounds are denominated directly in negative-ELBO or other
profiled-objective units.  When the negative ELBO has a complete
conjugate form, the flow value equals the optimal architecture-level
amortization gap without a curvature conversion.  A second theorem family
treats symmetry.  If the exact oracle representatives form an embedded
finite cover with no continuous section, then every continuous labeled
encoder pays a worst-case monodromy tax.
Finite variation speed and a lower-mass condition upgrade this to a
positive population tax.  A probabilistic oracle section can avoid target
defect only by paying a separate entropy account, while the Schwarz genus
of the cover lower-bounds the number of local hard encoders needed for
zero defect.

For separated finite mixtures, an exchange loop of component labels
therefore forces a quantitative amortization gap for every single
continuous labeled encoder.  The obstruction is absent for collision-free
components on the line, where sorting supplies a global section, and is
present in dimensions at least two.  Pairing a cyclic double-well
normalized target density (and hence a possible posterior family) with a
single-Gaussian variational family gives a literal negative-ELBO example:
the oracle means form a nontrivial double cover and the exact minimax
amortization tax is available in closed form for every positive transverse
penalty.  The topological facts,
Bregman projection duality, and amortization-gap decomposition are
classical ingredients.  The contribution is their closure into
objective-denominated, computable impossibility certificates for
restricted inference maps.

## Core 06: Compositional Obstruction Transfer

**Full title:** Compositional Obstruction Transfer: Rectangularity, Architecture Base Change, and Dequantization  
**Exact source:** [`core16/cot.tex`](core16/cot.tex)

### Abstract

A certified defect can compose exactly for every trial law while its
minimum over a restricted architecture fails to compose.  This paper
studies that failure.  The basic object is the architecture obstruction
\[
 \mathfrak O_\beta(\mathfrak A;P^\star)
 =
 \inf_{Q\in\mathfrak A}\frac1\beta\KL(Q\|P^\star),
\]
the least finite-temperature defect attainable by an admissible class of
laws.  It is itself a certified elimination: every deployed law pays an
irreducible architecture tax plus an implementation tax inside the
architecture.

On a finite history tree, we form the rectangular hull by freeing every
conditional kernel that occurs locally in the architecture and allowing
those kernels to be pasted independently across histories.  The
rectangular obstruction satisfies an exact Bellman recursion.  For compact
classes of uniformly positive kernels, that recursion computes the
original obstruction for every full-support oracle if and only if the
architecture is rectangular.  Its failure is measured exactly by a
nonnegative coordination tax.  More strongly, the rectangular Bellman
values generate nonnegative local residuals whose expected sum is exactly
the coordination tax plus the within-architecture implementation tax.
Shared parameters, finite memory, and one network reused at many histories
are therefore not innocuous local restrictions: their cross-history
coupling has a price in the native relative-entropy units.  A shared-kernel
example evaluates this price in closed form as a geometric-pooling
normalization constant, while a two-stage binary example exhibits the
endogenous occupancy created by a shared mode.

For a fine-to-coarse representation, the law-level relative-entropy chain
rule lifts to an exact infimal base-change theorem.  The fine architecture
obstruction is the infimum of the coarse obstruction density plus a
coarse-law-dependent fiber realization tax.  Consequently an
objective-faithful representation need not be obstruction-faithful.
For every fine deployment, the same chain rule gives an exact three-level
ledger: coarse obstruction, irreducible fiber tax, and fine implementation
tax.
Universal equality of fine and coarse architecture obstructions holds
exactly when the fine architecture is saturated by the canonical oracle
fiber kernels; approximate saturation gives a sharp additive bound.

The zero-temperature question is treated at architecture level.  The fixed
class result follows from uniform law-level dequantization.  More generally,
for temperature-dependent compact architecture classes, the extended soft
functionals \(\Gamma\)-converge on the finite probability simplex under the
natural inner- and outer-limit conditions.  Minima converge, near
minimizers have hard-optimal cluster points, and total-variation Hausdorff
convergence gives the additive rate
\(\Lambda/\beta+\osc(D_\infty)h_\beta\).  The limit may remain a
relaxed randomized architecture; zero temperature alone does not force
determinism.  For a fixed architecture and its rectangular hull, the
coordination tax itself dequantizes at the sharper rate
\(\Lambda/\beta\), because the two nested minima share the same thermal
perturbation and only its oscillation matters.

Two structural applications close the calculus.  A memory-compression
theorem identifies the exact fixed-occupancy loss with the directed
log-pooling dispersion of oracle conditionals inside compression fibers.
For finite oracle covers, a downstream quotient retains a topological
obstruction exactly when its effective monodromy action has no fixed
class; quotienting can therefore cancel, rather than add, local monodromy
taxes.  Rectangularity, relative-entropy chain rules, \(\Gamma\)-convergence,
and covering-space monodromy are classical ingredients.  The contribution
is their closure into gates that determine when an infimum over
architectures commutes with conditioning, representation, and temperature.

## Core 07: Foundations of Elimination Geometry

**Full title:** Foundations of Elimination Geometry: Defect Fibrations, Obstruction Towers, and Interchange Coherence  
**Exact source:** [`core16/foundation.tex`](core16/foundation.tex)

### Abstract

An eliminated variable is usually treated as disposable.  Its exact
residual shows otherwise: the hidden states over each external problem form
a fiber, and objective excess is a nonnegative vertical coordinate that
vanishes precisely on the oracle locus.  We axiomatize this structure as a
\emph{certified defect fibration}.  A split relative version carries a
canonical zero-defect lift and an exact horizontal--vertical chain rule.

The certificate currency is rigid.  On finite probability spaces, a
nonnegative certificate that is lower semicontinuous, natural under
relabeling, strictly zero only at the oracle, and exactly compositional
under trial-weighted conditioning is a positive multiple of forward
relative entropy.  Product additivity is then automatic.  After fixing
temperature units, the Gibbs variational identity joins this soft currency
to measured base change and, uniformly over all trial laws, to hard excess
cost at zero temperature.

The fundamental obstruction-tower theorem describes what happens after a
restricted architecture is placed in the total space.  Its fine
obstruction is exactly the infimal convolution of the coarse defect with a
fiber-realization tax.  Under an attainment and separation package,
fine and coarse obstructions agree for every oracle if and only if the
architecture is saturated by every canonical zero-defect lift.  For
composable fibrations, realization taxes obey an associative Bellman law.
Rectangularity is recovered, without analogy, as simultaneous saturation
under the family of coordinate-replacement lifts.  This identifies
conditioning and representation base change as two instances of the same
closure gate.

We then study the calculus itself.  Every representation pipeline induces
a min-plus transfer operator and a path-realization tax.  The difference
between parallel path taxes is \emph{architecture curvature}; it gives
sharp upper and lower bounds on the change in every downstream optimized
objective, and vanishes exactly when no terminal objective can distinguish
the two paths.  On a finite cell complex, local architecture reports
integrate to a global obstruction potential exactly when all elementary
curvatures and global periods vanish.  Weighted Hodge projection gives a
nearest strictification and splits its squared error into
curvature--period and certification taxes.

Pairwise commutation at one certificate is not enough for three-way
coherence.  We define an interchange \(3\)-curvature as the diameter of the
six contextual min-plus composites.  A two-state, three-operator example
has zero pairwise curvature at the initial certificate but positive
interchange \(3\)-curvature; two states are minimal.  Thus conditioning,
base change, and temperature require contextual Beck--Chevalley checks, not
three isolated pairwise tests.  The framework's five companion papers
become interface corollaries of the fibration, tower, curvature, and
strictification theorems.  Classical fibration language, dynamic
programming, Hodge theory, and compositional convex analysis are kept
separate from the new architecture-level obstruction laws.

## Core 08: Quantum Elimination Geometry

**Full title:** Quantum Elimination Geometry: Gibbs Base--Change Rigidity, Conditional Sectors, and Recoverability  
**Exact source:** [`core16/quantum.tex`](core16/quantum.tex)

### Abstract

Classical Gibbs elimination admits an exact base-change law because a
reference measure can be disintegrated over every coarse state.  Partial
trace is the natural quantum analogue of marginalization, but a genuine
interaction generally produces a Hamiltonian of mean force that depends on
the externally imposed system Hamiltonian.  This paper identifies the exact
rigidity behind that failure.

Let \(R=R^\ast\) act on a finite-dimensional bipartite system
\(A\otimes B\), fix \(\beta>0\), and suppose there are a system operator
\(K=K^\ast\) and a scalar \(c>0\), both independent of \(F\), such that
\[
  \Tr_B e^{-\beta(F\otimes\1_B+R)}
  =c\,e^{-\beta(F+K)}
\]
for every Hermitian system Hamiltonian \(F\).  We prove that this happens
if and only if
\[
  R=K\otimes\1_B+\1_A\otimes L+\lambda\1_{AB}
\]
for some \(L=L^\ast\) and \(\lambda\in\mathbb R\).  Thus universal exact
quantum base change is equivalent to the absence of genuine
system--environment interaction.  The hypothesis can be weakened
substantially: proportionality of the two \emph{scalar} partition
functions for every \(F\) already forces the same conclusion.  The proof
passes through a constrained Gibbs--Fenchel dual, equality in Umegaki data
processing, a single Petz recovery channel for every system state, and the
rigidity of an extension channel that leaves all input states undisturbed.

The conclusion changes sharply when the admissible coarse Hamiltonians
belong to a commuting sector algebra.  We give an exact necessary and
sufficient condition: \(R\) must be block diagonal over the coarse sectors,
and the partial Gibbs operator of each block must be scalar on that sector.
For a maximal abelian algebra this is precisely a controlled Hamiltonian,
so genuine interaction is compatible with exact base change as long as
only classical sector fields are varied.

For a general interaction we derive an exact replacement ledger.  Every
trial-state Umegaki defect splits into a coarse Gibbs defect, the
nonnegative data-processing gap, and a signed Hamiltonian-of-mean-force
anomaly.  Universal recovery maps turn the data-processing gap into a
quantitative recoverability certificate.  In the rigid product case the
anomaly vanishes and the gap becomes an exact conditional relative
entropy, recovering the classical shape of disintegration.  Controlled
and transverse two-qubit models show explicitly where the commuting gate
holds and where external-field dependence enters.  The results delimit,
rather than assume, the noncommutative extension of certified classical
pushforwards.

## Core 09: Singular Elimination Geometry

**Full title:** Singular Elimination Geometry: Discriminants, Degree Obstructions, and Catastrophe Taxes  
**Exact source:** [`core16/singular.tex`](core16/singular.tex)

### Abstract

The regular theory of certified elimination is organized around a unique
oracle, a locally nondegenerate oracle branch, or a finite oracle cover
whose sheets remain uniformly separated.  Those hypotheses fail on a
discriminant: oracle branches collide, the action Hessian loses rank, and
the covering becomes a stratified map.  This paper develops an exact
minimax calculus for that singular regime.

The basic normal form is
\[
 H_\theta(a)=\left|a^k-r e^{i\ell\theta}\right|^2,
 \qquad
 a\in\C,\quad \theta\in S^1,
\]
where \(k\geq2\), \(r>0\), and \(\ell\in\Z\).  Every fiber has \(k\)
zero-defect roots.  Nevertheless, the least worst-case defect of a
continuous deployed field is
\[
 \inf_{A\in C(S^1,\C)}
 \sup_{\theta\in S^1}H_\theta(A(\theta))
 =
 \begin{cases}
  0, & k\mid\ell,\\
  r^2, & k\nmid\ell.
 \end{cases}
\]
The lower bound uses only winding number: an error strictly below \(r\)
would homotope \(A^k\) to the target loop through \(\C^\times\), forcing
\(\ell=k\wind(A)\).  The constant field \(A\equiv0\), which lies on the
collision stratum, attains the incompatible value \(r^2\).  Thus the exact
tax survives without strong convexity or uniform fiber separation and
scales continuously to zero as \(r\downarrow0\).

Three extensions turn the normal form into a singular calculus.  First,
an arbitrary nonvanishing loop has a two-sided catastrophe bound determined
by its radial clearance and winding class.  Second, a positively
homogeneous map \(F:\R^n\to\R^n\) gives the same exact constant on a
constant-radius target sphere whenever the target degree is not divisible
by the degree of the normalized map \(F/|F|\).  Third, for a complex
polynomial \(p\), a target loop with fixed-point-free root monodromy forces
worst-case residual at least its distance to the critical-value
discriminant.  A local ramification point of order \(m\) is analytically
conjugate to the radical normal form and hence inherits its exact tax.

The obstruction depends sharply on representation and risk aggregation.
Two local charts, a measurable selector, the unordered root set, or the
uniform root-valued probability measure all attain zero defect.  Moreover,
for any nonatomic sampling law the infimum of the \emph{average} defect
over continuous fields is zero: the unavoidable mismatch can be squeezed
into a vanishing seam.  The positive constant is therefore genuinely a
uniform deterministic architecture tax.  A real symmetric \(2\times2\)
conical-crossing model gives a parallel exact result: an oriented
continuous top eigenvector pays Rayleigh tax \(2r\) around an odd loop,
whereas the eigenprojector pays zero.

Covering-space lifting, degree, polynomial discriminants, ramification
normal forms, and geometric phase are classical.  The contribution is to
place them in the native units of a certified elimination objective and
to isolate exact, stable catastrophe taxes that remain meaningful as the
regular oracle geometry degenerates.

## Core 10: Lift Complexity

**Full title:** Lift Complexity: Intrinsic Admissibility, Slack Factorizations, and the Computational Gate for Elimination Geometry  
**Exact source:** [`core16/lift.tex`](core16/lift.tex)

### Abstract

An exact auxiliary lift can expose a useful coherence field, but it can
also expose a dummy coordinate or call an arbitrarily prescribed target.
Elimination Geometry II therefore restricts attention to an admissible
class of lifts.  The restriction is necessary, yet it leaves the class
exogenous.  This paper replaces the linguistic question ``which lifts are
allowed?'' by a geometric and computational question: how large a conic
extended formulation of the objective epigraph is required, and which
parts of its auxiliary carrier are actually seen by the target slack
operator?

For a continuous convex objective on a compact domain, we identify exact
conic lift complexity with the extension complexity of a truncated
epigraph body.  The classical slack-factorization theorem then
parameterizes every proper conic lift by a factorization of an object
intrinsic to the target.  Polyhedral and semidefinite lifts become
nonnegative and positive-semidefinite factorizations, respectively.  This
is the computational gate through which lift design enters Elimination
Geometry.

Finite size alone, however, does not cure the degeneracy.  We prove a
finite-complexity no-go theorem: from any exact lift one may append a
constant dummy field, an affine target-calling field, or---when a
second-order or semidefinite primitive is available---a quadratic field
whose frozen-oracle Hessian is an arbitrary prescribed positive
semidefinite matrix.  The overhead is independent of the coefficients of
the prescribed field.  Moreover, positive rescaling of the objective
preserves extension size while rescaling the native defect.  Thus cone
size by itself is neither an intrinsic admissibility criterion nor a
computational currency.

The repair is a slack-anchored reduced lift.  Its auxiliary carrier must
factor the target slack operator, redundant cone directions must be
removed by factorization quotients, and coherence must be invariant under
cone gauge and faithful under quotient refinement.  Dummy and
target-calling coordinates then disappear before the coupling frontier is
evaluated.  For this class we define a complexity-constrained frontier
\[
 \mathfrak F_{J,\cK}(m,r,\delta),
\]
the least true objective defect achievable by a quotient-reduced
\(\cK\)-lift of size at most \(m\), coherence budget \(r\), and one-sided
objective-fidelity error at most \(\delta\).  The exact frontier proposed
by unrestricted lift design is the slice \(\delta=0\).  Every deployed
lift admits an exact three-level ledger: complexity-limited coupled
obstruction, formulation-selection tax, and within-formulation
implementation tax.  The same defect also splits into approximation bias
and conic optimization slack.

In the common-fiber Legendre--Bregman regime, the reduced slack carrier
admits a second, target-visible reduction.  The conditional mean of the
dual oracle signature is the coarsest quotient of a deployment statistic
that preserves its optimal native defect.  Every further coarsening pays
an exact Bregman tax, and nested coarsenings telescope.  For finitely many
oracle types this produces an exact visible-capacity frontier, a positive
defect floor below the zero-defect cardinality threshold, and an
information-capacity lower bound.  Conic order and visible carrier
capacity remain distinct currencies: they interact only through an
explicit, quotient-faithful extraction theorem.

A simplex slack example shows why reduction is essential.  Duplicating
each nonnegative factor \(k\) times lowers a naive Euclidean factor
coherence from \(1\) to \(1/k\) without changing the represented convex
set.  The apparent gain is exactly a quotient artifact and vanishes on
the reduced carrier.  Finally, we state the conditional exchange theorem
that is actually available: a fixed, encoded, well-conditioned conic lift
with a self-concordant barrier converts barrier parameter and numerical
accuracy into certified objective defect.  Extension size, coefficient
length, conditioning, cone-oracle cost, and per-iteration linear algebra
are all required.  This locates linear, semidefinite, and
sum-of-squares formulations on a common
fidelity--coherence--complexity surface without claiming an unsupported
bridge from extension lower bounds to unrestricted time complexity.

## Core 11: Operational Semantics

**Full title:** Operational Semantics of Elimination Pipelines: Task Envelopes and Contextual Coherence  
**Exact source:** [`core16/operation.tex`](core16/operation.tex)

### Abstract

An elimination or representation pipeline is often audited at one input
certificate, even though the same module may later be placed behind a new
upstream objective, a new terminal loss, or a larger architecture.  We give
an operational semantics for safe substitution.  A finite pipeline is
represented by a min-plus path kernel \(K\), a typed grammar \(\cG\)
specifies its legal contexts, and a task system \(\fT\) specifies the
admissible upstream--downstream objectives.  Closing \(\fT\) under every
context pullback gives the least context-stable audit
\(\Cl_{\cG}\fT\).  Put
\[
 \mathsf Q_{\cG,\fT}K
 =\mathsf E_{\Cl_{\cG}\fT}K,
 \qquad
 (\mathsf E_{\fT}K)(y,x)
 =\sup_{(f,g)\in\fT}
 \{\mathsf V_K(f,g)-f(x)-g(y)\}.
\]
Our main theorem identifies a single universal contextual completion:
\[
 d_{\cG,\fT}^{\mathrm{ctx}}(K,L)
 =d_{\Cl_{\cG}\fT}(K,L)
 =\|\mathsf Q_{\cG,\fT}K-\mathsf Q_{\cG,\fT}L\|_\infty.
\]
This equality absorbs exact contextual completion as its first clause.  The
same theorem proves that the displayed distance is the pointwise least
task-adequate grammar-nonexpansive pseudometric, that its zero set is the
greatest grammar congruence contained in base task equivalence, and that
\(\mathsf Q_{\cG,\fT}K\) is the unique pointwise-least representative of
the resulting fully abstract quotient.  When the grammar is closed under
the canonical representatives, re-enveloped composition on its
grammar-valued fixed points is associative.

The algebraic engine is the task envelope \(\mathsf E_{\fT}\): it preserves
exactly the declared optimized values and realizes their distance
isometrically.  Zero-input audit, finite tomography, and metric resolution
are instances of this engine, not competing main theorems.

For metric task contracts we identify the envelope with a double metric
erosion and obtain an exact resolution profile.  For \(n\) operations we
identify contextual ordering curvature with the
\(\mathsf Q_{\cG,\fT}\)-diameter of the permutation kernels and bound it by
an inversion-weighted sum of contextual pairwise swap budgets.  A worked
two-state finite-memory screening pipeline exhibits all three phenomena:
every ordering is invisible to the zero-input contract, a legal precontext
creates a value gap of one, and the entire resolution profile is the closed
form
\(\max\{0,\min(1,a-1,b)\}\).  The results apply to certified elimination by
taking edge defects as min-plus kernels, but require no prior elimination
geometry terminology.

## Core 12: Statistical Elimination Geometry

**Full title:** Statistical Elimination Geometry: Stable Obstructions and Honest Architecture Certificates  
**Exact source:** [`core16/statistical.tex`](core16/statistical.tex)

### Abstract

Elimination geometry gives deterministic certificates for whether a
shared architecture can realize a family of pointwise optima, how much
defect it must pay, and which tasks can observe that defect.  In data
analysis, however, the defect, the admissible architecture grammar, and
the operational kernels are estimated.  A deterministic obstruction can
then be either stable, statistically identifiable, or genuinely
undecidable from the available information.  We develop a statistical
layer that separates these cases.

First, simultaneous lower and upper defect envelopes, together with
inner and outer architecture grammars, produce finite-sample honest
brackets for every architecture frontier.  The result is uniform over
resource budgets and therefore remains valid after data-dependent model
selection.  Second, the persistent atlas number of a defect is
horizontally interleaved under uniform perturbations.  Although the
integer-valued atlas curve can jump, its inverse $K$-chart loss frontier
is exactly $1$-Lipschitz; the constant is sharp.  Third, min-plus task
envelopes and contextually closed kernels are nonexpansive in sup norm.
Consequently, native and observable architecture certificates inherit
the same simultaneous confidence event without a second statistical
argument.

These transport results yield a canonical three-way decision:
certified feasible, certified impossible, or statistically unresolved.
The third outcome is necessary.  For the radical architecture
$a\mapsto a^k$ on the circle, the one-chart defect is either zero or one
according to divisibility of the target degree.  Without a coverage or
regularity assumption, localized windings make every uniformly valid
binary procedure no better than guessing, while any honest ternary
procedure must often return unresolved.

Under an $L$-Lipschitz assumption and bounded angular observation error,
we give an exact finite mixed-integer description of all degrees
compatible with the data.  Divisibility of this identification set gives
an honest architecture certificate.  A sharp local spacing condition
collapses the set to one degree.  For the square-root architecture under
uniform random design, the resulting upper bound and a hidden-winding
parity lower bound match at order
$L\{\log L+\log(1/\alpha)\}$.  Thus the statistical price of certifying a
global elimination architecture is governed by coverage of the places
where an obstruction can hide, not merely by pointwise estimation error.

## Core 13: Certificate Statistics

**Full title:** Certificate Statistics: Validity, Resolution Complexity, Task-Relative Sufficiency, and Recursive Updating  
**Exact source:** [`core16/certificate_stat.tex`](core16/certificate_stat.tex)

### Abstract

A statistical conclusion is usually reported as an estimate, a posterior,
or a significance label.  None of these objects by itself records the
population worlds still compatible with the data, the operational boundary
being audited, whether a binary declaration is uniformly justified, why the
answer remains unresolved, or what information should be collected next.  We
develop \emph{certificate statistics}, a unified theory in which the primary
finite-information output is a typed, auditable certificate and the central
dynamic question is the cost of resolving its unresolved state.

The theory separates three levels that are often conflated: a population truth
label, a finite-data confidence certificate, and a prior-relative posterior
color.  A confidence world induces the canonical feasible--unresolved--
impossible certificate, which is honest and maximally decisive under
worldwise correctness.  Simultaneous confidence sequences make the same
certificate valid under adaptive querying and stopping.  For adaptive
experiments, opposite-certificate alternatives define a max--min
Kullback--Leibler information and hence a resolution characteristic time.  In
a Gaussian multichannel threshold problem this time has an exact AND/OR
phase change: proving feasibility pays for every near-boundary channel,
whereas proving impossibility may concentrate on one strongest obstruction.
A transparent anytime specialization of established Box and deficit-tracking
ideas attains both constants.

We next ask which observation compressions preserve this cost.  The standard
conditional-KL chain rule gives exact certificate data processing, and a new
slack theorem shows
that lossless certificate complexity requires preserving binding alternatives,
not every parameter likelihood ratio.  Locally, the conditional-score map on
the nuisance-quotiented tangent space yields task sufficiency, task
completeness, and a minimum modulus whose inverse square controls sample
inflation.  This distinguishes lossless, stably lossy, ill-posed, and
nonidentifiable evidence carriers.

Bayesian updating supplies a different ledger.  Expected task-posterior loss
equals conditional mutual information, but arbitrarily small prior-average
loss can coexist with infinite worldwise certificate complexity.  Moreover,
the current task posterior need not determine the next useful experiment.  We
therefore specialize strong belief bisimulation to a certificate-colored
belief process and call the resulting largest congruence the recursive
certificate posterior quotient.  It
preserves every declared finite-horizon resolution problem and gives exact
state and chart lower bounds.  Finally, CR-BayesTrack uses posterior task
information only within a worldwise certificate-optimal allocation face and
stops with a likelihood-ratio martingale.  It is anytime valid and, under the
stated finite-model regularity, attains the almost-sure optimal leading
certificate constant; expected-time equality additionally requires uniform
integrability.  The resulting theory
links validity, information acquisition, evidence compression, and recursive
state without adding their distinct information currencies or changing
Bayes' identity.

## Core 14: Resource-Constrained Architectures

**Full title:** Elimination Geometry of Resource-Constrained Architectures: Typed Capacity, Rate--Distortion, and Certified Deployment  
**Exact source:** [`core16/architecture.tex`](core16/architecture.tex)

### Abstract

A resource-constrained system has at least three nonexchangeable capacity
questions.  A deployment carrier must preserve the oracle distinctions needed
to execute an action; an evidence carrier must preserve the likelihood
directions needed to authorize that action at fixed confidence; and a
recursive belief carrier must preserve the observation-labeled future
contexts needed to decide what to measure next.  We develop a typed
architecture theory in which these branches meet only through a declared
task, model, and action contract.  Exactness or raw size on one branch cannot
certify another.

The deterministic deployment branch retains a complete quantitative
rate--distortion and operational backbone.  A resource grammar indexed by
size and coherence budgets $(m,r)$ generates carrier--decoder architectures.
In a common-fiber Legendre--Bregman problem, conditional expectation of the
dual oracle signature gives the canonical deployment carrier, and the native
distortion has the exact second-elimination form
\[
 \Dnat(m,r)=\inf_Z\{\Cphi(Z)+\Psi_{m,r}(Z)\},
\]
where the terms are carrier information loss and decoder-class
nonsaturation.  Hard simplex--Potts grammars yield an exact inverse minimum
$q$-cut capacity, while normalized continuous conic grammars yield a
resolution-dependent metric-entropy bound with a sharp dimension exponent.
Strong convexity converts these capacities into Bregman quantization floors.

Native distortion is not automatically operational loss.  A sharp two-gate
theorem separates transmission of the native defect into a min-plus kernel
from exposure by a contextually closed task contract.  Finite contracts give
an exact visibility transform and a margin-clipped lower bound; compact
metric contracts give a sharp resolution coefficient.  We then add the
finite-information deployment interface.  For a confidence world $C$, the
pointwise statement $\forall\theta\in C\,\exists A_\theta$ is separated from
the deployable statement $\exists A\,\forall\theta\in C$.  Their minimax gap
creates a new typed unresolved state: every compatible world may be
individually feasible although no common architecture is safe to deploy.
An anytime confidence world certifies either a common witness or uniform
impossibility without confusing this conflict with statistical uncertainty.

For a declared architecture-action color, opposite-action worlds induce a
max--min Kullback--Leibler resolution time.  Evidence compression can only
increase this time, with equality under the certificate slack criterion.
Closing deployment, certificate, and contextual colors under every
observation-labeled update produces a joint recursive quotient.  It is the
coarsest exact shared state in the finite one-sided setting and gives exact
minimum state and chart bounds.  A certificate-guided expansion controller
therefore routes different failures to different repairs: deployment atlas
expansion, sensor or record repair, recursive state refinement, contextual
repair, or further active sampling.

On an equally weighted path with hard routing and quadratic local loss, the
deterministic backbone remains explicit: the effective deployment carrier
size is $\min\{m,n,1+\lfloor r/w\rfloor\}$, native distortion is balanced
scalar quantization error, and contextual distance is a clipped discrete
covering radius.  The resulting paper links resource grammar, typed capacity,
native loss, contextual observability, finite-information authorization, and
certified deployment without adding their distinct currencies into one
spurious scalar loss.

## Core 15: EG for Machine Learning and AI

**Full title:** Elimination Geometry for Machine Learning and AI: Certified Architecture Realizability and Obstruction-Aware Learning  
**Exact source:** [`core16/egml.tex`](core16/egml.tex)

### Abstract

Learning theory traditionally separates approximation, estimation, and
optimization error.  In modern amortized and shared architectures, however,
the usual approximation account hides two different failures.  A local model
family may be unable to express the pointwise oracle, or the local oracles may
each be adequate but impossible to assemble into one deployable encoder,
policy, world model, memory state, or representation contract.  The first is
\emph{local model inadequacy}; the second is a \emph{global architecture
realizability gap}.  More data and better optimization can remove neither
gap in general.

We formulate this distinction through elimination geometry.  Pointwise
optimization generates an exact nonnegative defect in the units of the
original objective.  Restricting the resulting oracle field to a deployable
architecture produces an architecture obstruction: the smallest native
defect attainable by that class.  We prove a high-probability four-account
theorem and then close its statistical gap: one simultaneous confidence set
for the native defect, architecture grammar, and operational kernel gives
honest brackets over an entire resource frontier, remains valid after
data-dependent budget selection, and induces a necessary three-way decision---
certified feasible, certified impossible, or statistically unresolved.  In a
common-fiber
Legendre--Bregman carrier--decoder architecture, we further identify this
floor with a native architecture rate--distortion function and give its exact
internal ledger
\[
 \Delta_{\rm arch}(\cA_{m,r})
 =\Dnat(m,r)
 =\inf_Z\{\Cphi(Z)+\Psi_{m,r}(Z)\}.
\]
The two terms are carrier information loss and decoder-class nonsaturation.
The canonical retained state is the conditional dual oracle signature, not
raw width or parameter count.  A positive native floor becomes a downstream
contextual separation only through additional transmission and task-exposure
conditions; contextual curvature is therefore not a third additive tax.

We then give computable lower certificates: an obstruction-transfer
principle, a sharp transport bound for Lipschitz architectures, an exact
convex flow dual on finite calibration graphs, a closed-form
parameter-sharing tax, and exact topological taxes whose value depends on the
output contract and risk aggregation.  The resulting account distinguishes
carrier insufficiency, decoder nonsaturation, statistical generalization,
optimization reachability, and operational observability without converting
them into one artificial currency.

These results motivate \emph{Obstruction-Aware Learning and Inference}
(OALI), a certificate-guided workflow that estimates local oracles, tests a
declared single architecture, selects a repair such as an atlas, quotient,
set-valued or randomized output, memory refinement, rectangularization, or
semantic projection, and validates improvement on an independent test split.
We prove the corresponding finite-library held-out guarantee and distinguish
OALI from generic mixture-of-experts and unconstrained architecture search.
For hard-atlas repairs, a persistent loss--atlas coordinate gives the exact
chart-budget/uniform-loss frontier.  Uniform defect error interleaves the
integer atlas curve horizontally and perturbs its inverse loss frontier by at
most the same error.  OALI therefore distinguishes certified structural
infeasibility, a certified atlas, statistical nonidentification, and incomplete
certificate computation; under a uniform local certification radius it also
has a packing-based finite-termination guarantee.
Amortized variational inference, shared conditional policies, latent-state
compression, symmetric mixtures, and validity-constrained prediction provide
canonical interfaces.  The theory is deliberately conditional on a declared
oracle family, architecture class, output semantics, and aggregation rule; it
does not claim that every neural-network failure is structural or topological.

## Core 16: EG for Adaptive Learning Systems

**Full title:** Elimination Geometry for Adaptive Learning Systems: Certificate-Directed Acquisition, Recursive Capacity, and Architecture Expansion  
**Exact source:** [`core16/egml2.tex`](core16/egml2.tex)

### Abstract

The first Elimination Geometry for Machine Learning (EGML) theory separates
local model inadequacy from the failure of one deployable architecture to
realize a field of locally correct answers.  That theory is static: after an
architecture is audited, an unresolved system may need more data, a different
observation channel, additional recurrent state, a larger deployment grammar,
or simply more optimization, but the architecture ledger alone cannot choose
among these interventions.

We develop an adaptive sequel.  A learning system is typed by three
noninterchangeable carriers: a deployment carrier from operating inputs to
actions, an evidence carrier from raw experiments to retained observations,
and a recursive carrier from beliefs to the state used for future acquisition.
Their effective currencies are respectively native distortion,
fixed-confidence characteristic time, and recursive state or chart
complexity.  We prove a no-compensation theorem: unlimited resources in one
branch do not in general repair blindness or collision in another branch.
Thus the correct object is a resource region, not an additive total error.

For a finite reachable belief process, the recursive certificate
congruences imported from the companion Certificate Statistics manuscript
produce a depth-indexed visible-capacity tower
\[
 N_0\le N_1\le\cdots\le N_\infty.
\]
Every depth-$h$ exact architecture needs at least $N_h$ states; finite chart
budgets obey a matching lower bound; and every strict refinement returns the
experiment, observation, and successor block witnessing the missing state.
The depth-indexed architecture interpretation is constructive and terminates
at the unique minimal exact recursive carrier.  We use the companion's
predictive-closure theorem as an interface for projected online Bayes
updates, identify the recursion as assumed-density filtering, and introduce
a task-visible order-curvature diagnostic.  An exact four-state mean-field
example has curvature $1/8$.

The Adaptive EGML Realization Theorem combines these coordinates without
adding them.  Any worldwise-valid learning system obeys a retained-evidence
sample lower bound, a recursive state lower bound, and the static EGML native
deployment floor.  Under finite-model regularity these coordinates are
simultaneously attainable by a lossless evidence carrier, the minimal
recursive quotient, an admitted deployment witness, and a posterior-guided
tracking rule whose stopping decision remains worldwise.  This theorem
supports AR-OALI, an active-resolution version of Obstruction-Aware Learning
and Inference.  AR-OALI routes a typed witness to data acquisition, evidence
repair, recurrent splitting, deployment expansion, or optimization.  A
finite laboratory shows that full-parameter entropy, present task posterior,
certificate information, recursive state, and deployable action can all rank
the same resources differently.
