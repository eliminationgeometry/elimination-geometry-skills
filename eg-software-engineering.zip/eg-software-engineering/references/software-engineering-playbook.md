# EG Software-Engineering Playbook

Read this file after the software-engineering canon when the task needs code, software architecture, distributed systems, data/ML pipelines, performance, APIs, stateful services, or numerical software. Apply only the sections relevant to the request.

## 1. Start from the executable contract

Inspect before abstracting:

- repository instructions, build system, public interfaces, tests, and deployment configuration;
- the smallest reproducible input and expected behavior;
- logs, traces, counters, profiles, resource limits, and environment differences;
- version, platform, concurrency, data, and feature-flag conditions;
- which files or systems the user authorized changing.

Write the acceptance metric in operational units: exact output, error class, latency percentile, throughput, allocation, memory peak, energy, availability, recovery time, numerical tolerance, or another declared endpoint.

Do not infer an architectural failure from a broad symptom before reproducing the local behavior.

## 2. Common software eliminations and shared grammars

| Mechanism | Locally available object | Shared/restricted object | Typical lost distinction |
|---|---|---|---|
| Cache or memoization | result for the full request state | one cache key/value policy | omitted request, version, tenant, locale, permission, or dependency state |
| Serialization or API schema | complete internal object | stable wire representation | ordering, null/missing, units, precision, type, provenance, or future-update data |
| Shared model/configuration | per-workload best parameters | one model or global configuration | environment-, hardware-, cohort-, or regime-specific behavior |
| State machine or agent memory | complete history | finite retained state | histories with equal current output but different legal continuations |
| Distributed aggregation | ordered or node-local events | counts, averages, sketches, or replicated summary | event order, causality, identity, tail behavior, or conflict history |
| Scheduler or allocator | per-job optimal resource/action | one policy under a fixed menu | workload priorities, deadlines, affinity, or rare resource combinations |
| Compiler/build target | per-target transformation | common IR, optimization pass, or binary | platform semantics, precision, ABI, or hardware cost |
| Data/ML feature pipeline | raw task-visible evidence | fixed feature, embedding, or compressed record | rare class, group, temporal, causal, or deployment distinctions |
| Numerical library | per-instance solver/preconditioner | one solver rule or fixed basis | conditioning, spectrum, stiffness, branch, or constraint activity |

The table suggests questions; it does not certify a defect. Confirm the actual code path and task.

## 3. Architecture and integration diagnosis

Use this sequence when modules pass locally but the system fails:

1. Name the end-to-end task and the interface at which each module's guarantee is stated.
2. Check whether the guarantees compose: types, units, ordering, ownership, lifecycle, error semantics, retry/idempotency, and timing.
3. Identify the representation or state discarded at every boundary.
4. Find two system states that the boundary treats equally but the downstream task treats differently.
5. Trace that pair through the call graph or protocol until it is exposed or annihilated.
6. Add an integration test at the earliest boundary that can reproduce the difference.
7. Repair that boundary before rewriting downstream code.

Typical witnesses include:

- `null`, missing, empty, and default collapse to one wire value but require different actions;
- two versions share a cache entry but dependencies changed;
- a retry duplicates a non-idempotent action;
- an aggregate preserves totals but removes causal order;
- one shared error code erases retryable versus permanent failure;
- each service uses internally consistent units but the interface does not encode them;
- a component contract is pointwise while deployment requires one common configuration.

## 4. Stateful, streaming, and distributed systems

Current-output equality is not state equivalence. For two candidate states (s,s'), test:

- same output now;
- same behavior for each legal next input or event;
- same successor equivalence class after that event;
- same authorization, side effects, timers, retries, and recovery behavior;
- same result under reordering, duplication, partition, and replay allowed by the system contract.

Useful controls:

- deterministic replay with event order preserved and permuted;
- snapshot/restore and version migration tests;
- duplicate, delayed, lost, or reordered message injection;
- partition and recovery traces;
- state-key collision enumeration on a small domain;
- linearizability, serializability, idempotency, or consistency checks when those are the declared contract.

A larger state is not automatically a repair. Retain the minimal transition- or task-visible distinction, then verify memory, migration, and compatibility costs.

## 5. Performance and resource analysis

Keep class limitation separate from a weak implementation.

### Baseline ledger

Record:

- workload distribution and worst-case/percentile quantifier;
- warmup, caching, compilation, I/O, and concurrency conditions;
- hardware, versions, thread/process counts, affinity, and power mode;
- latency, throughput, allocations, peak memory, network bytes, storage, energy, and error rate as relevant;
- initialization, refresh, preprocessing, synchronization, and teardown costs;
- the information and quality contract solved by each baseline.

### Discriminating tests

- Compare per-workload tuned choices with the single deployed choice.
- Sweep the suspected resource while holding information and objective fixed.
- Profile the witness path, not only aggregate runtime.
- Separate algorithmic operations from framework overhead and refresh cost.
- Check scaling in problem size, condition number, concurrency, data skew, and hardware.
- Run a zero-obstruction regime in which the shared policy should match local choices.
- Compare the matched repair with a generic equal-budget increase.

Do not call an optimization “faster” when it changes accuracy, stopping tolerance, information, compilation privilege, or target objective without reporting the change.

## 6. Data and machine-learning systems

Separate:

- scientific or product target;
- local model adequacy;
- shared encoder/model/feature architecture;
- sampling and generalization;
- training/optimization;
- data processing and implementation;
- deployment drift, latency, and resource constraints.

Potential witnesses include two cohorts, environments, tasks, histories, or rare regimes mapped to the same representation while requiring different predictions or actions. Verify that the distinction is visible to the declared loss and persists under realistic deployment.

Controls for an architecture claim:

- per-context or oracle upper baseline;
- multiple strong optimizers and adequate training budget inside the fixed class;
- equal-data/equal-compute comparison;
- group, tail, temporal, and out-of-distribution metrics tied to the witness;
- a task-invisible distinction as a negative control;
- mechanism-matched representation/state repair;
- frozen or held-out validation after architecture selection.

Posterior confidence, model score, and operational authorization are different. Do not gate a deployable branch on labels, spectra, true environments, or oracle states unavailable at runtime.

## 7. Numerical and scientific software

For solvers, simulation code, and optimization libraries, record:

- mathematical target and constraints;
- discretization and representation class;
- residual and task-error definitions;
- conditioning, stiffness, spectral gaps, active sets, branches, and singular regimes;
- inner and outer tolerances, initialization, stopping, refresh, and fallback rules;
- precision, determinism, parallel reduction order, and hardware behavior.

Distinguish:

- model-form error;
- discretization/representation error;
- iterative/optimization error;
- floating-point and implementation error;
- downstream task error.

Use manufactured or exact small solutions, conservation tests, order-of-accuracy studies, tolerance sweeps, condition-number regimes, branch-switch tests, and cross-implementation comparisons. A small residual need not imply small task error without stability or exposure.

When stale fields, approximate inner solves, approximate eigenspaces, or branch switching matter, test them together under the operational acceptance and fallback rules. Count factorization, matrix/vector products, synchronization, refreshes, memory, and wall-clock—not iteration count alone.

## 8. APIs, schemas, and compatibility

An interface is a quotient: it declares which internal distinctions consumers may no longer see. Before changing it, inventory:

- task-visible fields and units;
- missing/default/null semantics;
- ordering and multiplicity;
- version and feature negotiation;
- identity, authorization, provenance, and tenant scope;
- precision and lossy conversions;
- forward and backward compatibility;
- recursive use by future consumers.

A repair may add a field, split a type, version a schema, preserve ordering, expose provenance, or narrow the supported contract. Test old/new producer–consumer combinations and migration/replay behavior.

## 9. Security and reliability boundary

EG can help locate a lost security- or reliability-relevant distinction, but it does not establish cryptographic security, privacy, safety, or regulatory compliance. Use threat models, adversarial tests, formal security definitions, current standards, and specialist review.

Do not log secrets or personal data merely to gain observability. Treat redaction and minimization as part of the carrier contract.

## 10. Software verification matrix

Choose the smallest sufficient set:

| Layer | Purpose | Example evidence |
|---|---|---|
| Unit/local | local implementation and invariants | unit, property, type, static, or exact-small-instance test |
| Witness regression | preserved lost distinction | test that fails under the old quotient/key/state |
| Integration | guarantee composes across interfaces | contract, protocol, migration, replay, or end-to-end test |
| Negative control | task-invisible differences remain harmless | equal-output or no-transmission control |
| Saturation | fixed class was fairly exercised | optimizer sweep, exhaustive small case, profile, tolerance study |
| Resource | repair meets budget | benchmark with matched quality/information and full cost ledger |
| Robustness | operating envelope and faults | perturbation, load, concurrency, chaos, or platform matrix |
| Independent | selection did not consume evaluation | frozen benchmark, held-out workload, or external reproduction |

Report skipped layers and why they are not needed for the claimed scope.

## 11. Compact software checkpoint

```text
Task/SLO:
Reproduction:
Shared boundary:
Minimal collision or witness:
Earliest exposed failure:
Leading account and alternatives:
Discriminating test:
Smallest matched change:
Tests and benchmarks run:
Remaining risk:
```
