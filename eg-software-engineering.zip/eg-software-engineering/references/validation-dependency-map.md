# Validation and Dependency Map

This is the mandatory startup rendering of the monograph's Appendix E. It preserves the dependency semantics that should govern every EG explanation, audit, theorem proposal, experiment, and intervention. For exact quotation or publication use, reread [`monograph/appendices/appE_dependency.tex`](monograph/appendices/appE_dependency.tex).

## Governing interpretation

The workflow is:

```text
define elimination
  -> derive a native defect
  -> audit integrability and carrier admissibility
  -> choose an architecture-obstruction theorem
  -> add resource and operational assumptions
  -> construct a statistical certificate
  -> test saturation, repair, and validation
```

Every arrow means **next audit gate**. It is not a theorem implication. A transition may require a new theorem, modeling assumption, empirical design, or independent validation. In particular:

- a native defect does not imply an architecture obstruction;
- a positive obstruction does not imply operational visibility;
- operational visibility does not imply finite-sample resolution;
- a statistical certificate does not prove empirical saturation;
- saturation does not prove that a proposed repair improves a held-out endpoint.

## Gate table

| Gate | Required object or evidence | If missing |
|---|---|---|
| 1. Elimination | declared target-preserving elimination | remain analogy-only |
| 2. Native defect | exact insertion identity, orientation, nonnegativity, touching | no native EG tax |
| 3a. Integrability | one global objective or a quantified/repaired curvature-period residual | local reports cannot be assembled silently |
| 3b. Carrier admissibility | intrinsic lift, factorization, quotient-faithful extraction, or model-specific gate | padding/target-calling may make complexity vacuous |
| 4. Architecture obstruction | explicit shared grammar, risk aggregation, representation class, and witness quantifiers | no structural lower-bound claim |
| 5a. Resource exchange | theorem connecting bits/states/charts/compute to native loss | ledgers remain incomparable |
| 5b. Operational transmission | legal path, kernel, dynamics, or context carrying the mismatch | no downstream consequence |
| 5c. Task exposure | declared observer distinguishes the transmitted mismatch | native cost may be invisible |
| 6. Statistical certificate | simultaneous confidence world, stable transport, and resolution contract | no honest finite-data decision |
| 7a. Saturation | evidence that the fixed architecture reaches its diagnosed floor | cannot attribute failure to architecture |
| 7b. Matched repair | intervention changes the failed interface under comparable contracts | improvement may be generic or confounded |
| 7c. Independent validation | held-out or independently frozen endpoint plus matched controls | no confirmed architecture-choice conclusion |

## Constructive spine

1. Establish a conjugate or other certified defect identity.
2. Keep P/G/X/V/C target and auxiliary-field contracts distinct.
3. Use exactification and approximate-jet certificates only under their stated oracle and acceptance conditions.
4. For graph distributional prediction, separate CDF validity repair from CRPS risk decomposition and from graph-universal minimax classification.

## Validity spine

1. Flat integrability audits whether local defect reports arise from one potential.
2. Hodge, coexact, harmonic, and period terms diagnose or repair nonintegrable fields.
3. Lift Complexity excludes dummy and target-calling carriers.
4. A target-visible quotient or quotient-faithful extraction reaches deployment capacity only after its model-specific gate is proved.

## Architecture spine

1. Architecture obstruction is a second elimination over a declared deployment class.
2. EOT supplies regular metric and flow transfer bounds.
3. COT supplies rectangularity and coordination decompositions.
4. Singular EG supplies exact catastrophe taxes when regular assumptions fail.
5. Atlas, quotient, set-valued, and randomized repairs change the deployment contract; they are not free improvements inside the old class.

## Resource, semantics, and composition spine

1. Resource rate–distortion separates carrier information loss from decoder nonsaturation.
2. Operational semantics determines contextual and task visibility.
3. Foundations and composition theory govern tower associativity, base change, conditioning, refinement, and limits.

## Statistical and intervention spine

1. Simultaneous defect and grammar envelopes bracket architecture frontiers.
2. Persistent inverse frontiers require stability before transport through a confidence world.
3. Three-way decisions preserve honest unresolvedness.
4. Certificate Statistics separates resolution effort from evidence compression and posterior guidance.
5. Typed realization joins finite-information authorization, recursive closure, deployment capacity, context, and one common action without identifying their units.
6. OALI requires saturation testing, mechanism-matched repair, and independently validated improvement under matched contracts.

## No-circularity checks

### Graph–CRPS

The book-proved CDF validity repair and exact CRPS risk decomposition do not use the graph-universal probability-validity classification. The complete sharp path minimax theorem is sourced to EG I/II and is logically independent of the book proof. Do not use one as an unstated premise for the other.

### Exactification

Constructive exactification restores target tangency without the converse theorem. Target descent requires a separate candidate-wise defect-remainder or acceptance condition. The later converse characterizes first-order target-preserving frozen-lift models as defect-jet corrections modulo a flat term; it must not be used circularly to justify the constructive step.

## Audit rule

Enter the map at the earliest gate needed for the requested conclusion. Later gates may remain intentionally out of scope, but they must not be reported as passed by implication. When a gate is open, name the missing theorem, assumption, experiment, or validation artifact rather than hiding it inside a broad “EG applies” statement.
