# EG Software-Engineering Canon

This is the mandatory lightweight operating memory for `eg-software-engineering`. It translates the Elimination Geometry monograph and task-visible research logic into repository-grounded software decisions. It does not replace exact EG sources, repository instructions, tests, official documentation, security standards, or operational authorization.

## 1. Mission

Ask:

> When locally correct or locally tuned software behavior must pass through one reusable implementation, state, schema, protocol, model, or resource contract, which task-visible distinctions are lost, where does the loss first occur, and what smallest code or interface change restores the required behavior?

Use this discovery order:

```text
executable task and SLO
  -> typed software system
  -> task quotient
  -> locally adequate behavior
  -> deployed shared grammar
  -> lost distinction
  -> native failure or diagnostic proxy
  -> minimal executable witness
  -> call/data/protocol transmission and exposure
  -> discriminating test
  -> smallest matched code or contract repair
  -> regression, integration, resource, and operational verification
```

Every arrow is a question, not an automatic implication.

## 2. Scope boundary

Use this canon when the primary artifact is code, tests, build/deployment configuration, APIs, schemas, caches, state machines, protocols, data/ML pipelines, numerical implementations, or runtime profiles.

Do not use it merely because a physical or scientific model happens to be implemented in software. If acceptance depends on governing equations, material laws, geometry, boundary conditions, experiments, or physical validation, the task is engineering analysis. In a mixed task, state which software interface is being judged.

## 3. Three levels of software analysis

Keep separate:

1. **Local correctness or adequacy:** each function, module, request, workload, tenant, platform, or environment can behave correctly or be tuned on its own.
2. **Shared realizability:** one legal code path, key, schema, model, protocol, state update, configuration, or resource budget can serve all declared contexts.
3. **Evidence and authorization:** reproductions, tests, traces, profiles, and operational controls are sufficient to identify the mechanism and justify a change.

Passing unit tests does not prove end-to-end realizability. A system collision does not show available telemetry can detect it. A plausible diagnosis does not authorize a broad rewrite or deployment.

## 4. Software translation of EG objects

| EG object | Software interpretation |
|---|---|
| Context or world \(x\) | request, tenant, workload, dataset, version, environment, platform, event history, or numerical regime |
| Local oracle \(a_x^\star\) | locally best result, state, configuration, action, representation, schedule, basis, or solver choice |
| Shared grammar \(\mathfrak A\) | one implementation, API, key, schema, model, state update, policy, binary, or resource contract |
| Local objective \(H_x(a)\) | correctness loss, latency, memory, energy, availability, regret, numerical error, or product loss |
| Eliminated target \(J(x)\) | best attainable local value after optimizing the auxiliary choice |
| Native defect | exact excess in the declared objective after inserting a non-oracle choice |
| Carrier | stored, serialized, transmitted, cached, embedded, or retained state |
| Quotient | distinctions intentionally treated as equivalent by the executable contract |
| Witness | smallest input pair, trace, history, event order, platform, workload, or mode exposing the loss |
| Transmission | call graph, dataflow, protocol, state transition, deployment path, or numerical operation |
| Exposure | user, consumer, invariant, SLO, security boundary, or downstream task distinguishes the mismatch |
| Saturation | the fixed class has been fairly implemented, optimized, and exercised |
| Matched repair | a code or contract change acting on the interface identified by the witness |

Do not invent a formal objective when the repository supplies only observable behavior. A reproducible collision can support an EG-structured diagnosis without certifying a native defect.

## 5. Task-relative software sufficiency

No cache key, state, schema, embedding, aggregate, model, or compression is simply sufficient. It is sufficient for a declared consumer, continuation, authorization context, version policy, risk aggregation, and tolerance.

Examples:

- a key can be sufficient for current reads and unsafe after dependency or permission changes;
- an aggregate can preserve totals while losing causal or event order;
- a state can emit the correct answer now and fail under the next legal input;
- a schema can preserve values while losing units, provenance, null semantics, or future migration data;
- one numerical stopping rule can work on typical instances and fail a task-visible singular regime.

Define task equivalence before counting states, bits, fields, parameters, ranks, or resources.

## 6. Local freedom versus deployed grammar

The grammar must state what may adapt and what must remain common. Useful contracts include:

- one code path, API, binary, or schema across versions and clients;
- one cache key or retained state across requests and histories;
- one model, encoder, configuration, or policy across cohorts and environments;
- one aggregate or replicated summary across event orders and nodes;
- one solver, basis, precision, or stopping rule across numerical regimes;
- fixed latency, memory, bandwidth, energy, storage, or compute budgets.

The key quantifier is:

```text
each context has some correct or adequate implementation choice
does not imply
one legal deployed choice is correct or adequate for every context.
```

## 7. Native task cost before proxy cost

Prefer the real contract: failed output, invariant violation, latency percentile, throughput, allocation, memory peak, availability, recovery time, numerical task error, privacy/security property, or product loss.

Parameter distance, state count, width, rank, residual, bit count, iteration count, and wall-clock are separate accounts. Relating a proxy to user-visible loss requires a proof, specification, or controlled experiment.

When an exact elimination exists,

\[
J(x)=\inf_a H_x(a),
\qquad
D_x(a)=H_x(a)-J(x)\ge 0,
\]

certify exactness, orientation, nonnegativity, and touching before calling \(D_x\) a native defect.

## 8. Typed diagnostic accounts

| Account | Typical question | Matched response |
|---|---|---|
| Target/specification | Is the requirement, metric, or local algorithm wrong? | correct the target or algorithm |
| Architecture/representation | Does the shared class merge task-distinct states or omit an action? | refine the key, state, schema, model, or action grammar |
| Evidence/workload | Do tests and telemetry cover the relevant contexts? | acquire evidence; retain unresolvedness |
| Operation/protocol | Do ordering, retry, lifecycle, ownership, or composition change behavior? | repair the protocol or pipeline |
| Algorithm/numerics/optimization | Is the legal class adequate but poorly searched or resolved? | improve the method inside the class |
| Implementation/integration | Is code, configuration, precision, build, or interface behavior defective? | fix the implementation |
| Resources/environment | Do compute, memory, bandwidth, I/O, latency, or platform constraints bind? | change allocation or the resource contract |

Do not exchange accounts without evidence. A successful refactor can mask rather than identify the original cause.

## 9. Witness-first diagnosis

A useful witness demonstrates the failure and suggests the repair. Seek:

- two inputs collapsed by a key, schema, embedding, or state but requiring different behavior;
- two histories with equal current output and different next transitions;
- one event-order permutation with equal aggregates and different outcomes;
- two versions, tenants, permissions, or platforms sharing state that must differ;
- two workloads requiring incompatible local configurations;
- one numerical branch, active set, or mode that controls task error or runtime;
- one retry, replay, migration, or failure sequence that exposes missing lifecycle information.

Keep the executable contract fixed. A witness that changes versions, permissions, workload, or guarantees without declaring the change does not diagnose the original system.

## 10. Transmission and exposure

Trace:

```text
lost distinction
  -> retained carrier/decoder
  -> call path, protocol, or transition
  -> declared observer, invariant, or SLO
```

If a later stage annihilates the mismatch, it is not user-visible loss for that task. It may still be a contract escape, security concern, or future-compatibility risk—but that is a different claim requiring its own observer.

## 11. Saturation and matched repair

Before blaming architecture, reproduce the failure, inspect the actual code path, test strong implementations and configurations inside the fixed class, profile the witness path, check platform and lifecycle conditions, and use an exact small case or zero-obstruction control when possible.

Let the witness route the repair:

| Witness | Matched intervention |
|---|---|
| key/schema/state collision | refine the key, schema, state, or decoder |
| equal current output, different continuation | retain recursive state or update signature |
| event order erased | preserve the minimal task-visible order or causality data |
| missing action or policy branch | expand the legal action/deployment grammar |
| fixed class adequate, search misses it | improve algorithm, numerics, or optimization inside the class |
| slow transmitted mode | precondition, deflate, refresh, or restructure that channel |
| no observer sees the difference | narrow the claim; do not redesign |

Connect every material edit to an invariant or witness. Add the narrowest regression that would have failed before the change, then verify integration and resource consequences.

## 12. Stateful and recursive correctness

Current-output equality is not behavioral equivalence. For candidate states \(s,s'\), test:

- current outputs;
- behavior under every relevant next input or event;
- successor-state equivalence;
- authorization, side effects, timers, retries, and recovery;
- replay, duplication, reordering, partition, and migration allowed by the contract.

A larger state is not automatically better. Retain the minimal continuation-visible distinction and account for migration, memory, privacy, and compatibility costs.

## 13. Verification ladder

Choose the smallest sufficient set and state omissions:

1. unit, property, type, static, or exact-small-instance tests;
2. regression for the minimal witness;
3. contract, protocol, migration, replay, and end-to-end integration;
4. zero-obstruction and task-invisible controls;
5. fixed-class saturation, optimizer, tolerance, or platform study;
6. matched-quality performance and resource ledger;
7. concurrency, fault, security, compatibility, and operating-envelope tests;
8. frozen workload, independent reproduction, staging, or monitored rollout appropriate to authorization.

Do not call a benchmark faster when it changes correctness, information, compilation privilege, initialization, refresh cost, or stopping rules without reporting the change.

## 14. Evidence grades and verdicts

- **Observed:** present in supplied code, logs, tests, traces, or profiles.
- **Reproduced:** regenerated under a recorded environment and configuration.
- **Inferred:** best current explanation, with alternatives stated.
- **Certified:** supported by a proof, exhaustive check, formal contract, or exact identity at the claimed scope.
- **Validated:** confirmed on a frozen or appropriately independent operational endpoint.
- **Unresolved:** current evidence does not select a conclusion.

The verdict is `ordinary`, `EG-structured`, `certified EG`, or `unresolved`. Evidence grade and verdict are independent.

## 15. Anti-patterns and source boundary

Avoid:

- declaring an architecture problem from one failed run;
- adding width, data, compute, caching, or state without locating the bottleneck;
- treating unit tests as end-to-end evidence;
- treating current output equality as state equivalence;
- changing several boundaries and claiming a mechanism-specific gain;
- using labels, true environments, or oracle spectra in a deployable branch;
- calling a numerical search failure an impossibility result;
- forcing EG onto an ordinary bug, missing test, unsafe mutation, or unsupported security claim.

This canon is an operating guide, not a theorem source. For exact EG claims, use `software-engineering-source-router.md` and reread the routed chapter, proof appendix, or paper. For current library behavior, APIs, standards, security, product facts, and historical priority, use authoritative official or primary sources and repository evidence.
