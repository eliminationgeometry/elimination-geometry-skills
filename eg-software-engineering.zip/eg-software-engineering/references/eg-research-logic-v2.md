# Elimination Geometry Research Logic v2

## From task-visible elimination to theorem and matched repair

> A shareable research protocol distilled from the Elimination Geometry program.  
> Version 2.0 — 2026-08-12

## 1. What this document is for

This document presents a way of thinking about research problems. It is not a manuscript-review checklist and it is not a dictionary for relabeling familiar errors.

Its purpose is to help a collaborator turn a vague concern about compression, sharing, recursion, inference, or deployment into a precise mathematical program:

1. identify the distinction a task actually needs;
2. locate where a declared architecture eliminates that distinction;
3. prove the obstruction in its native mathematical unit;
4. show that an admissible task can expose it;
5. use the witness to determine the appropriate repair;
6. decide whether the direction should proceed, be reformulated, or stop.

The central question is not whether a model is “large enough.” It is:

> When local freedom is replaced by a shared carrier, grammar, state, decoder, or action family, which task-relevant distinctions cease to be representable, and what theorem identifies the loss and its minimal repair?

Ordinary approximation error, finite-sample uncertainty, misspecification, computational difficulty, and unsuccessful optimization do not become Elimination Geometry merely because they involve information loss or limited capacity.

---

## 2. The EG thesis

Let \(\theta\in\Theta\) denote a world and \(c\in\mathcal C\) an admissible context. If every world or context could use its own locally adequate construction \(a_{\theta,c}^\star\), there might be no local difficulty. A real system, however, is usually required to reuse something: one representation, finitely many charts, a compressed statistic, one recurrent state, a restricted measurement menu, or one deployable action family.

An EG mechanism contains four ingredients:

1. **Local oracle:** different worlds or contexts may require different locally adequate objects.
2. **Shared grammar:** the implementable system forces those objects through a declared common carrier or construction class.
3. **Elimination:** the shared construction merges, removes, or makes inaccessible a distinction present at the oracle level.
4. **Exposure:** some admissible decision, context, intervention, observation, or future update can still see that distinction.

The fourth ingredient makes the geometry task-relative. A representation may be exact for one task and lossy for another. There is no task-free notion of “sufficient,” “minimal,” or “lossless.”

The program can be summarized as

`contract -> type -> preliminary task quotient -> oracle -> grammar -> eliminate -> native defect -> refine quotient -> zero-defect/converse -> minimal witness -> expose -> certify when statistical -> route -> realize`

This is a discovery order. A final domain paper may use different terminology and exposition.

---

## Quick start — apply the logic to a new problem

> Given a research problem, develop it using the Elimination Geometry research logic. Begin with the scientific construction rather than a manuscript review or a list of generic mathematical risks.
>
> 1. State the task, admissible worlds, contexts, and success quantifiers.
> 2. Define the preliminary task equivalence induced by that contract and quotient obvious nuisance distinctions.
> 3. Construct the local oracle.
> 4. Specify the shared carrier, grammar, state, decoder, or action restriction.
> 5. Identify the eliminated task-visible distinction, define its native defect, and refine the quotient to the distinctions that actually bind the obstruction.
> 6. Formulate a zero-defect criterion and test the converse.
> 7. Find the smallest valid witness, finite when the mathematics permits.
> 8. Prove how the witness is exposed by a declared scientific operation.
> 9. Derive a lower bound or necessary resource requirement.
> 10. Let the witness route a matched repair and propose a construction that approaches or attains the bound.
> 11. If the problem is statistical, separate posterior guidance from valid authorization and retain `unresolved` when required.
> 12. End with the smallest exact laboratory and a `proceed / revise / stop` decision.
>
> Clearly distinguish proved derivations, conjectures, numerical diagnostics, literature-dependent claims, imported tools, owned contributions, and nonclaims. Do not fill an unknown link with terminology; convert it into a specific lemma, counterexample, experiment, or literature task.

The remainder of this document explains the logic behind these steps, gives two reusable proof skeletons, and records four project laboratories.

---

## 3. The research engine

### Phase I — Discover the obstruction

#### 3.1 Start from the task, not from a preferred model

State:

- the scientific output or decision;
- the world class and admissible contexts;
- the loss, validity condition, or operational tolerance;
- the quantifiers: pointwise, uniform, minimax, worldwise, prior-average, current-context, or future-context;
- what may honestly remain unresolved.

The contract determines which distinctions matter. Changing the task can change the answer from exact to impossible without changing the representation at all.

#### 3.2 Type the objects before relating them

Keep logically different objects separate. In particular:

- truth, estimate, posterior belief, and confidence authorization;
- raw observation, retained evidence, and recursive state;
- admissible architecture, solver output, and deployed action;
- present decision sufficiency and sufficiency for future updates.

Equal dimension or identical numerical form does not make two types interchangeable.

#### 3.3 Define the preliminary task quotient

Declare \(\theta\sim_{\mathsf T}^{(0)}\theta'\) when every task and admissible context in the initial contract treats \(\theta\) and \(\theta'\) identically. Quotient obvious nuisance, gauge, padding, and task-invisible variation before selecting a capacity measure.

This is preliminary because the native obstruction may later reveal that only part of this quotient boundary actually binds the theorem.

#### 3.4 Solve the local-oracle problem

Ask what each world or context could achieve if it received its own construction. For example, with local action class \(\mathcal Q_\theta\) and native loss \(L_\theta\), define

\[
J(\theta)=\inf_{a\in\mathcal Q_\theta}L_\theta(a),
\qquad
D_\theta(a)=L_\theta(a)-J(\theta)\ge 0.
\]

The insertion defect \(D_\theta(a)\) is useful because the original problem—not an arbitrary proxy—supplies its unit. In other problems the native object may instead be a collision, non-factorization, non-closure, curvature, contextual inconsistency, path-law divergence, or partial-identification width.

#### 3.5 State the shared grammar exactly

Specify what must be common and what may adapt. A statement such as “the model has finite capacity” is not yet a grammar. A usable grammar might require:

- one encoder and decoder across worlds;
- at most \(k\) charts;
- a fixed measurement menu;
- one statistic retained from every sample;
- a state update in a declared finite family;
- one action available before the world is resolved.

The obstruction lives in the gap between local freedom and this legal shared family.

### Phase II — Turn the obstruction into a theorem

#### 3.6 Derive the native defect first

Measure what the shared grammar loses before translating it into downstream risk. The preferred objects are exact:

- an insertion identity or minimax gap;
- failure to factor the oracle through the carrier;
- collision of task-distinct worlds in one carrier fiber;
- failure of a projected update to close;
- a sharp identification region;
- an integrability, commutation, monodromy, or curvature obstruction.

A downstream performance gap may mix architecture, estimation, optimization, and computation. Isolating the native obstruction prevents the wrong repair.

#### 3.7 Refine the task quotient

The native obstruction often reveals which alternatives actually bind. Refine the preliminary quotient accordingly before final state, bit, chart, information, or capacity bounds. The object to preserve is not the full world. It is the binding distinction in the task quotient.

#### 3.8 Characterize zero defect and test the converse

Do not stop with a sufficient condition. Ask:

- When is exact realization possible?
- Is the condition necessary as well as sufficient?
- Which tempting reverse implication fails?
- Does the failure disappear under another representation, task, aggregation, or regularity class?

A compact broken converse is productive evidence. It often identifies the exact boundary of the theorem and the next research question.

#### 3.9 Find the minimal witness

Compress an abstract obstruction into the smallest valid witness:

- two worlds mapped to the same carrier;
- two histories with the same current state but different future refinements;
- one event or experiment separating a collided pair;
- one context reversing an action ranking;
- one binding opposite-label alternative;
- one incompatible chart cycle or genuinely global obstruction.

Make the witness finite when the mathematics permits. Do not force a topological or asymptotic obstruction into a false finite form.

#### 3.10 Prove exposure

A native defect is not automatically a scientific loss. Prove that an admissible reader can see it—as decision loss, regret, a context-envelope gap, stopping-time cost, recursive-state demand, deployment failure, or partial identification of value.

This separates two legitimate outcomes:

- **exposed obstruction:** the current scientific contract is affected;
- **contract escape:** the native difference is invisible to the stated task, so the claim must be narrowed or a different exposing task declared.

#### 3.11 Let the lower bound reveal the algorithm

A useful lower bound should identify its binding alternative, collision, allocation, or capacity requirement. That object should dictate the construction. A lower bound that supplies only a rate but no bottleneck is less informative than one that tells us where to measure, which state to split, or which action must be added.

### Phase III — Turn the theorem into a repair

#### 3.12 Route the witness to the layer that failed

| Witness | Bottleneck | Matched repair |
|---|---|---|
| opposite-label worlds receive too little information | evidence resolution | acquire or reallocate measurements |
| raw data distinguish worlds but the retained statistic does not | evidence carrier | repair the statistic or sensor |
| current state merges histories with different future transitions | recursive carrier | split the state/chart or change the update |
| the correct action is absent from the admissible family | deployment carrier | expand the action/deployment grammar |
| the architecture admits a valid solution but the procedure misses it | optimization/implementation | improve the solver within the same architecture |
| the native distinction has no legal exposing operation | contract/exposure | narrow the claim or add a scientifically legitimate context |

“Use a larger model” or “collect more data” is not a matched repair unless the witness identifies that resource as the bottleneck.

#### 3.13 Prove realization

Close the loop with a construction that attains the zero-defect condition or matches the obstruction bound, exactly or at the claimed rate. The strongest form of an EG result has both directions:

\[
\text{current grammar fails for a proved reason}
\quad+\quad
\text{a witness-directed repair is sufficient and attainable}.
\]

---

## 4. Two reusable theorem skeletons

### 4.1 Factorization, collision, and exact finite capacity

Let \(T_c(\theta)\) denote the oracle output relevant to context \(c\), and let \(E(\theta)\in\mathcal Z\) be a shared carrier.

If, for some admissible \(c\),

\[
E(\theta)=E(\theta')
\qquad\text{but}\qquad
T_c(\theta)\ne T_c(\theta'),
\]

then no deterministic decoder \(d_c:\mathcal Z\to\mathcal A_c\) can reproduce the oracle output in both worlds. The triple \((\theta,\theta',c)\) is an elimination witness.

Conversely, exact realization requires each task map to factor through the carrier:

\[
\Theta
\xrightarrow{\ E\ }
\mathcal Z
\xrightarrow{\ d_c\ }
\mathcal A_c.
\]

Equivalently, every fiber of \(E\) must lie inside one class of the task quotient. Thus an exact carrier may preserve extra nuisance information, but it may not merge task-distinct classes. The quotient map \(\Theta\to\Theta/{\sim_{\mathsf T}}\) is the coarsest unconstrained exact carrier. For a restricted grammar, fiber constancy remains necessary and becomes sufficient only when the induced decoder also satisfies the declared measurability, continuity, causal, computational, or implementation conditions.

The following finite scalar theorem shows the complete proof pattern. Let \(\Theta\) and \(\mathcal C\) be finite, let \(T_c(\theta)\in\mathbb R\), and fix an encoder \(E:\Theta\to\mathcal Z\). The decoder family is unrestricted: each \(d_c:E(\Theta)\to\mathbb R\) may be chosen independently, with no continuity, causality, shared-parameter, or further grammar constraint. Define the task-fiber diameter

\[
\operatorname{diam}_{\mathsf T}(E)
=
\max_{z\in E(\Theta),\,c\in\mathcal C}
\left\{
\max_{\theta:E(\theta)=z}T_c(\theta)
-
\min_{\theta:E(\theta)=z}T_c(\theta)
\right\}.
\]

Then

\[
\inf_d\max_{\theta,c}
\left|d_c(E(\theta))-T_c(\theta)\right|
=
\frac12\operatorname{diam}_{\mathsf T}(E).
\]

**Proof.** On any fiber and context, one decoder value must approximate both the minimum and maximum task values, so the triangle inequality gives an error of at least half their separation. Choosing the midpoint of those two extremes on every fiber-context pair attains the bound. Therefore

\[
\operatorname{diam}_{\mathsf T}(E)=0
\quad\Longleftrightarrow\quad
E(\theta)=E(\theta')\Rightarrow \theta\sim_{\mathsf T}\theta'.
\]

If the encoder may use at most \(m\) states and there are no further grammar restrictions, exact realization is possible if and only if

\[
m\ge \left|\Theta/{\sim_{\mathsf T}}\right|.
\]

The lower bound follows because task-distinct classes cannot share a state; the quotient encoder attains it. A maximizing \((\theta,\theta',c)\) is simultaneously the obstruction witness and the context exposing the exact minimax error.

This elementary theorem is a calibration, not a novelty claim. It is deliberately small enough to display the full obstruction–witness–exposure–attainment loop. With a restricted decoder grammar, the midpoint may be inadmissible and a separate constrained theorem is required. For vector outputs and other losses, the midpoint radius is replaced by the appropriate fiberwise Chebyshev or decision radius. Topological, stochastic, continuous, and asymptotic problems may require non-factorization, non-closure, cocycles, curvature, or limiting separation rather than a finite pair.

### 4.2 Statistical resolution and authorization

For a finite sequential statistical experiment, let \(q:\Theta\to\mathcal Q\) be the task label, \(\mathcal E\) the experiment menu, and \(P_{\theta,e}\) the observation law under world \(\theta\) and experiment \(e\). At round \(t\), an experiment \(e_t\) is chosen from the past and the next observation is conditionally independent with law \(P_{\theta,e_t}\). Fix \(\delta\in(0,1/2)\), assume the opposite-label set is nonempty, and define

\[
\operatorname{Alt}_q(\theta)
=
\{\lambda:q(\lambda)\ne q(\theta)\}
\]

and the task-relative characteristic information

\[
I_q^*(\theta)
=
\sup_{w\in\Delta(\mathcal E)}
\inf_{\lambda\in\operatorname{Alt}_q(\theta)}
\sum_{e\in\mathcal E}w_e\,
\mathrm{KL}\!\left(P_{\theta,e}\,\|\,P_{\lambda,e}\right).
\]

For a worldwise \(\delta\)-correct procedure—one that stops with finite expectation and outputs the true task label with probability at least \(1-\delta\) in every world—the standard change-of-measure argument yields

\[
\mathbb E_\theta[\tau]
\ge
\frac{\operatorname{kl}(1-\delta,\delta)}{I_q^*(\theta)},
\]

with the usual infinite interpretation when \(I_q^*(\theta)=0\). The proof compares \(\theta\) with every opposite-label \(\lambda\):

\[
\sum_e \mathbb E_\theta[N_e(\tau)]
\mathrm{KL}\!\left(P_{\theta,e}\,\|\,P_{\lambda,e}\right)
\ge \operatorname{kl}(1-\delta,\delta),
\]

then optimizes the expected sampling proportions. Under the finite setup and finite relevant KL divergences, the extrema are attained: a binding alternative and optimal allocation form the statistical witness and blueprint for acquisition. If the procedure may immediately return `unresolved` while counting as correct, this lower bound does not apply; that is a different decision contract.

If an anytime-valid confidence sequence \((C_t)\) satisfies

\[
\mathbb P_\theta\{\theta\in C_t\text{ for every }t\}\ge1-\delta,
\]

then stopping when \(C_t\ne\varnothing\) and \(q\) is constant on \(C_t\) authorizes the label. An empty confidence world is `model conflict`, not a vacuous authorization. If the available budget ends while a nonempty \(C_t\) crosses several labels, the correct output is `unresolved`. Matching the lower-bound constant requires a separate attainment theorem; it does not follow from the converse alone.

The change-of-measure lower bound and confidence-sequence stopping rule are imported statistical tools. The EG-specific work is to define the correct task quotient and opposite-label set, determine what the evidence carrier preserves, and connect the binding witness to acquisition or representation repair.

---

## 5. What counts as evidence

A useful evidence ladder is below. Each stronger statement needs a stronger proof object.

| Research statement | Evidence that justifies it |
|---|---|
| the shared grammar eliminates a distinction | exact collision, non-factorization, non-closure, positive native defect, or valid global obstruction |
| zero defect holds exactly under condition \(C\) | necessity-and-sufficiency theorem with its regularity assumptions |
| at least \(k\) states, charts, bits, measurements, or actions are needed | lower bound after quotienting task-invisible distinctions |
| the obstruction matters scientifically | exposure or transmission theorem for a declared task |
| a repair is matched | the construction separates the witness or attains the lower bound |
| finite data authorize a conclusion | worldwise, simultaneous, selective, or anytime-valid certificate appropriate to the procedure |
| a numerical result supports the mechanism | a prespecified experiment tied to the theorem gate, with the numerical claim kept distinct from the theorem |

Examples and simulations are excellent mechanism detectors. They do not establish uniform quantifiers. A theorem about a native defect does not establish operational importance without exposure. An impossibility theorem does not establish that a particular repair is optimal without a matching construction.

### Statistical evidence: truth, guidance, and authorization

When data enter the problem, distinguish:

- **truth label:** what is true in the data-generating world;
- **confidence certificate:** what the data authorize with a declared validity guarantee;
- **posterior or design score:** what may guide the next observation;
- **deployment action:** what is executed.

For a binary feasibility problem, a canonical honest output is `feasible / impossible / unresolved`, optionally with `model conflict`. More generally, return a certified task label or `unresolved`. The unresolved state is productive: it records that the current confidence world crosses task labels. It is not a failed analysis and should not be converted into a label by posterior confidence alone.

For adaptive acquisition or stopping, authorization must remain valid under the adaptation. Posterior information can rank experiments or break ties inside a worldwise-valid face; it does not replace the certificate without a calibration theorem.

---

## 6. Carriers and resource accounts

A **carrier** says where information or action lives:

- deployment carrier;
- evidence carrier;
- recursive carrier.

An **account** says how a deficiency is measured:

1. native architecture defect;
2. operational exposure;
3. statistical evidence or resolution cost;
4. recursive capacity;
5. computation;
6. optimization or implementation.

These are not one universal scalar budget. Equal bit counts or dimensions do not make carriers interchangeable. More deployment capacity cannot reconstruct evidence deleted by a sensor; more observations of a deterministically collapsed statistic do not recover the erased distinction; a larger state cannot implement an unavailable action; a better optimizer cannot remove a class-level impossibility.

Cross-account compensation is a theorem to be proved, with assumptions, direction, and units—not a default modeling convenience.

---

## 7. Lessons learned across the EG program

### 7.1 No loss or sufficiency claim is task-free

A compression can preserve a terminal output while losing a path property, preserve total workload while losing a class-sensitive decision, or preserve displayed depth while leaving a tagged execution unidentified. Always ask: *safe for which task and under which continuations?*

### 7.2 Quotient before counting

Ambient parameter dimension, raw history count, model size, and storage bits often include nuisance or padding. Count the task-visible equivalence classes, binding alternatives, or transition signatures instead.

### 7.3 Native obstruction before downstream risk

The same observed performance gap can arise from architecture, evidence, recursion, computation, or optimization. First identify the native failure; only then prove how it transmits to the task.

### 7.4 A witness is more useful than a global score

A world pair, event order, hidden cancellation location, binding alternative, or one-step transition split often reveals more than a global diagnostic. It identifies both why the architecture fails and what must change.

### 7.5 Broken converses are theory, not debris

A positive path-space discrepancy need not imply terminal discrepancy. Current decision sufficiency need not imply recursive sufficiency. Prior-average information need not imply worldwise resolvability. These failures define the precise theorem boundary.

### 7.6 Current sufficiency is not recursive sufficiency

Two states can give the same answer now yet respond differently to the same future observation. A recursive carrier must preserve observation-labeled transition behavior, not only the current label.

### 7.7 Belief and authorization are different

Posterior belief may guide acquisition, but an honest certificate authorizes a declaration. If the evidence permits both task labels, `unresolved` is the correct output.

### 7.8 Lower bounds should design algorithms

The best lower bounds expose their binding face. Opposite-label alternatives suggest an allocation; a collision suggests a split; a missing action suggests expansion; a slow mode suggests deflation. The converse should shape the construction.

### 7.9 Exactness is often preserved by less information than expected

The correct carrier need not preserve all raw information. It must preserve the distinctions that bind the declared task. This is why task quotienting precedes capacity measurement.

### 7.10 EG is a discovery logic, not mandatory terminology

A domain paper should be self-contained. If its problem, obstruction, proof, repair, and limit are clearer in native language, there is no need to foreground EG terminology or require the reader to know companion papers.

---

## 8. Four compact project laboratories

These examples illustrate the logic. Each result below is `proved in its current source under the stated assumptions`; that status does not mean independent verification or publication readiness, and none is a universal claim beyond its declared model.

### 8.1 Full path versus terminal law

*Source laboratory: “Path-Space Distillation Taxes in Generative Diffusions”; internal source snapshot 2026-08-12, `add_tex13/continuous.tex`, Theorem “Exact \(K^{-2}\) temporal compression floor” and Proposition “Endpoint and radial contract escape.” Source available on request.*

In a time-compressed diffusion model, Girsanov's identity and orthogonal projection turn the best \(K\)-stage student error into a native path-space quantity. Here a stage is one shared drift field over a time cell, not a numerical solver step, and the partition into \(K\) cells is optimized. For a rotating Ornstein–Uhlenbeck family, let \(\alpha\) be the slope of the angular schedule, \(A\) its skew generator, and \(T\) the time horizon. Against the declared Girsanov-admissible \(K\)-stage state-feedback class, the current source obtains the exact floor

\[
\inf_{K\text{-stage students}}\mathrm{KL}(\text{teacher path}\,\|\,\text{student path})
=
\frac{\alpha^2\lVert A\rVert_{\mathrm F}^2T^3}{24K^2}.
\]

The attaining piecewise-skew linear student—and, more generally, every student in the stated skew-linear comparison class—has the same one-time marginals and radial path law as the teacher. This invariance is not asserted for every measurable student in the larger class over which the floor is taken.

**Evidence and lesson:** Girsanov and Hilbert projection are imported tools; the source contribution is their declared \(K\)-stage exact floor together with the explicit contract-escape construction. A native path obstruction does not imply an endpoint obstruction; the lower bound belongs to the full-path contract.

### 8.2 Event counts versus the quote-move regulator

*Source laboratory: “Event-Order Geometry of Limit Order Books”; internal source snapshot 2026-08-12, `extra_tex5/microstructure_event_order.tex`, Theorems “Quantized Lindley regulator identity,” “Universal typed minimality of the trace carrier,” and “Exact identification set from event counts.” Source available on request.*

At a regenerative best queue, additions and removals do not commute. Let \(q\) be initial visible depth, \(b\) the depth installed after depletion, \(S\) terminal net signed flow, and \(M\) the running prefix minimum of that flow. Event counts retain \(S\) but discard \(M\). In the declared unit-event, fixed-reset grammar, the quote-move count satisfies

\[
K=\max\left\{0,\left\lceil\frac{1-q-M}{b}\right\rceil\right\},
\qquad
Q_{\mathrm{end}}=q+S+bK.
\]

The pair \((S,M)\) composes recursively and is the coarsest universal exact carrier for all starting/reset depths and terminal queue/quote-move-count readouts. It does not reconstruct the complete sequence of quote-move times.

**Evidence and lesson:** the Lindley regulator and bicyclic/min-plus composition are classical ingredients; the source contribution is the queue-task typed minimality and sharp count fibers. The repair is the generated statistic \(M\), not an unspecified larger feature set. The result concerns the quote-move regulator and terminal readouts, not tagged fills or profitability.

### 8.3 Quantum base change: the quantifier changes the theorem

*Source laboratory: “Quantum Elimination Geometry: Gibbs Base-Change Rigidity, Conditional Sectors, and Recoverability”; internal source snapshot 2026-08-12, `all_tex15/quantum.tex`, Theorems “Universal Gibbs base-change rigidity” and “Commuting-sector base-change gate.” Source available on request.*

Let \(A\) and \(B\) be finite-dimensional system and environment spaces, \(R\) their total reference Hamiltonian, \(K\) an effective system Hamiltonian, and \(\beta>0\) a fixed inverse temperature. Suppose one \(K\) and one constant \(c>0\), both independent of the external system field \(F\), must satisfy for every Hermitian \(F\),

\[
\operatorname{Tr}_B e^{-\beta(F\otimes I+R)}
=c\,e^{-\beta(F+K)}.
\]

The current source proves the exact characterization, for some environment Hamiltonian \(L\) and scalar \(\lambda\),

\[
R=K\otimes I+I\otimes L+\lambda I,
\]

so no genuine interaction survives. When \(F\) is restricted to \(\sum_jf_jP_j\), with fixed \(K=\sum_jk_jP_j\), the gate becomes

\[
[R,P_j\otimes I]=0,
\qquad
\operatorname{Tr}_B e^{-\beta R_j}
=c\,e^{-\beta k_j}P_j
\quad\text{for every }j
\]

for one common \(c>0\), where \(R_j\) is the \(j\)-th block. In rank-one sectors, controlled interactions can survive.

**Evidence and lesson:** Gibbs/Fenchel duality, Umegaki data processing, and Petz recovery are imported; the current source claims the all-fields Hamiltonian characterization and its exact sector gate as the assembled increment, subject to domain prior-art verification. The obstruction is not the slogan “quantum systems do not commute.” It is determined by the external-field quantifier and admissible coarse grammar.

### 8.4 Current certificate versus future experiment choice

*Source laboratory: “Certificate Statistics: Validity, Resolution Complexity, Task-Relative Sufficiency, and Recursive Updating”; internal source snapshot 2026-08-12, `all_tex15/certificate_stat.tex`, Theorems “Recursive quotient theorem” and “Minimal exact recursive state.” Source available on request.*

Let \(\chi\) denote the present certificate color. Two belief states may have the same \(\chi\) but require different next experiments or transition to different future certificate classes after the same observation. In the source theorem's finite hypothesis/experiment/observation setting, additionally restricted to a finite reachable belief set \(\mathcal R\) closed under positive-probability updates, observation-labeled partition refinement produces the largest certificate-respecting update-stable equivalence. If its quotient has \(N_\chi\) classes, every exact deterministic recursive carrier needs at least \(N_\chi\) reachable states.

**Evidence and lesson:** strong belief bisimulation and fixed-point partition refinement are imported; the certificate coloring, state/chart consequences, and authorization interface are the source-level increment. Any exact carrier must refine the quotient, giving the state lower bound. Preserve future transition signatures, not just today's answer. Posterior information may guide sampling, while an anytime-valid certificate authorizes stopping.

---

## 9. Decide whether to proceed

### Proceed

Proceed when the direction has:

- a precise task-relative elimination mechanism;
- an exact native object or sharp obstruction;
- a witness that changes a scientific decision or intervention;
- a self-contained theorem gate with a zero-defect criterion, converse/lower bound, exposure, or constructive attainment.

### Revise

Revise when the mechanism appears real but the task, quotient, grammar, exposure operation, certificate, or repair layer is not correctly typed. Turn each missing link into a lemma, counterexample, small experiment, or literature question.

### Stop the EG formulation

Stop the EG formulation when the claimed increment reduces to an ordinary approximation or estimation bound, a standard sufficiency theorem, generic computational difficulty, or a capacity slogan that never changes a declared decision. The underlying problem may remain worthwhile; EG is simply not adding a theorem.

---

## 10. Evidence and scope note

This protocol is a synthesis of recurring proof patterns and boundary lessons across the current Elimination Geometry research corpus. The abstract logic is intended to travel across domains; the examples above inherit the assumptions and scope of their respective source manuscripts.

The relevant contribution categories are:

- **imported tool:** a classical identity, concentration result, rate–distortion theorem, bisimulation argument, queueing recursion, or domain theorem;
- **adapted consequence:** a known tool specialized to the declared task and grammar;
- **owned interface:** a new connection among native obstruction, task exposure, certificate, recursion, or deployment;
- **owned theorem:** a new exact criterion, converse, lower bound, minimal witness, realization, or sharp identification result;
- **nonclaim:** the adjacent conclusion that the result deliberately does not establish.

The research logic itself does not prove that every proposed EG direction is novel, correct, or publication-ready. Those judgments require source-level proofs and domain-specific prior-art work.
