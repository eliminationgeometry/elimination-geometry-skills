# Extend17 Abstracts and Domain Router

> Generated from all 17 bundled TeX sources. Load this file completely during corpus initialization.

## Contents

1. **Information theory and certificate design**
   - 1.1 Deployment Information Radius — `extend17/deployment_info.tex`
   - 1.2 Certificate Information Bottleneck — `extend17/certificate_info.tex`
   - 1.3 Recursive Rate--Distortion — `extend17/recursive.tex`
   - 1.4 Certificate-Directed Wavelet Acquisition — `extend17/wavelet_acquisition.tex`
2. **Game theory and strategic learning**
   - 2.1 Information-Limited Strategic Regret — `extend17/Strategic_Regret_Geometry.tex`
   - 2.2 Recursive Strategic State Compression — `extend17/Recursive_Strategic_Elimination.tex`
3. **Time series, dependence, and dynamical closure**
   - 3.1 Time--Scale Elimination Geometry — `extend17/timescale_eg.tex`
   - 3.2 Dependent Elimination Geometry — `extend17/dependent.tex`
   - 3.3 Fractional-Memory Forecasting — `extend17/long_memory_forecasting.tex`
   - 3.4 Mori--Zwanzig Closure — `extend17/Mori_Zwanzig_Elimination_Geometry.tex`
   - 3.5 Projected Return-Kernel McMillan Degree — `extend17/task_visible.tex`
4. **Statistical physics, diffusion, and renormalization**
   - 4.1 Task-Conditioned Renormalization — `extend17/Task_Conditioned_Renormalization.tex`
   - 4.2 Path-Space Distillation Taxes — `extend17/continuous.tex`
   - 4.3 Hidden Entropy Production — `extend17/Hidden_Entropy_Production.tex`
5. **Queueing and market microstructure**
   - 5.1 Task-Visible State-Space Collapse — `extend17/queue.tex`
   - 5.2 Event-Order Geometry of Limit Order Books — `extend17/microstructure_event_order.tex`
   - 5.3 Execution-Visible Market States — `extend17/execution_visible_market_states.tex`

---

## 1. Information theory and certificate design

### 1.1 Deployment Information Radius

**Full title:** Deployment Information Radius: Boundary-Safe Restricted Centers and Evidence-Calibrated Authorization  
**Exact source:** [`extend17/deployment_info.tex`](extend17/deployment_info.tex)

#### Abstract

If a different predictive distribution may be selected in each compatible
world, log-loss regret is zero.  If one distribution must be deployed before
the world is resolved, the value is instead
\[
  \inf_Q\sup_{\theta\in\cC}\KL(P_\theta\|Q).
\]
This is the classical information radius: on finite alphabets it equals the
capacity of the virtual channel \(\theta\mapsto P_\theta\).  We use that
identity as a calibration result, not as a new theorem.

The first increment concerns restricted deployment.  For every nonempty
closed convex \(\cA\subseteq\Delta(\cY)\), including faces with zero
coordinates, we give an exact finite-value criterion and prove the
extended-valued strong duality
\[
 \inf_{Q\in\cA}\sup_\theta\KL(P_\theta\|Q)
 =\sup_\pi\left\{
      I_\pi(\Theta;Y)
      +\inf_{Q\in\cA}\KL(P_\pi\|Q)
   \right\}.
\]
without assuming that every deployable law has full support.  We also give the
correct variational certificate for the resulting second-argument KL
projection; the usual additive Pythagorean formula for an information
projection does not apply in this orientation.

The second increment turns evidence separation into an authorization time.
For finite i.i.d. evidence models, a likelihood-ratio confidence sequence and
a deployment-safe world cluster yield an explicit Chernoff--R{\'e}nyi sample
bound.  A stopped-transcript change-of-measure converse proves that inverse
evidence KL is an unavoidable expected-time cost.
With probability at least \(1-\alpha-\beta\), the bound simultaneously retains
the true world, removes every world outside the safe cluster, resolves the
declared label, and certifies worst-world deployment regret at most
\(\eps+\eta_T\).  Classical equalizer, support, tensorization, and data
processing facts are retained only to expose what this evidence-to-deployment
bridge does and does not use.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 1.2 Certificate Information Bottleneck

**Full title:** Certificate Information Bottleneck: Exact Finite Quantizer Design, Worldwise Reliability, and Bit--Sample Tradeoffs  
**Exact source:** [`extend17/certificate_info.tex`](extend17/certificate_info.tex)

#### Abstract

An evidence representation should not be judged only by how much mutual
information it retains on average.  A valid certificate must separate every
true world from the opposite-task worlds that can invalidate its conclusion.
For a multichannel experiment and task map \(q\), the relevant information at
world \(\theta\) is
\[
 \cI_M^{q,*}(\theta)
 =\max_{w\in\Delta_K}\min_{\lambda:q(\lambda)\ne q(\theta)}
   \sum_{e=1}^K w_e
   \KL(P_{\theta,e}M_e\|P_{\lambda,e}M_e),
\]
where \(M_e\) is a parameter-independent evidence compressor.  We study the
\emph{certificate information bottleneck}: minimize a declared rate of
\(M=(M_e)\) subject to retaining a prescribed level of this information
simultaneously at every protected world.

The paper's substantive finite result completely solves a nondegenerate
three-world, four-symbol deterministic quantizer problem.  The optimal
certificate values with one through four output cells are
\(0,1.144945,1.226593,1.470671\), yielding the exact cardinality bottleneck at
every target.  In the same experiment, the binary quantizer maximizing
\(I(q(\Theta);Z)\) is strictly different from the certificate-optimal
quantizer and retains only \(0.666169\), rather than \(1.144945\), nats of
worst-world KL.  A separate parametric construction proves that such a strict
ranking reversal persists even when mutual information uses the correct task
label.

For operational calibration, the raw-to-compressed KL chain rule writes a
target-retention constraint as an elementary loss ledger, and the standard
change-of-measure argument gives sample and cost-normalized communication
converses for the induced compressed experiment.  For independent erasure we
prove the stopped reveal-count identity needed to charge actual transmitted
symbols and state only the resulting converse normalization, not an unproved
two-sided operational equality.  Classical, imported, and new components are
identified explicitly.  The resulting analysis separates Bayes-average
relevance, worldwise reliability, rate, samples, and unresolvedness as
different currencies.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 1.3 Recursive Rate--Distortion

**Full title:** Recursive Rate--Distortion for Context Quotients: Exact Countdown Curves, Graph Universality, and Causal Refresh  
**Exact source:** [`extend17/recursive.tex`](extend17/recursive.tex)

#### Abstract

A representation can be sufficient for the current output and insufficient
for the next legal update.  A finite task-colored predictive system generates
canonical depth classes \(C_h(S)\) by observation-labeled partition
refinement.  Classical model minimization, source coding, characteristic
graphs, bisimulation metrics, and directed information then attach different
currencies to the same quotient.  We make those inheritances explicit rather
than presenting them as new theorems.

The main new result is an exact positive-distortion calculation.  In a
countdown system with \(m+1\) equiprobable protected states, unit discount, and
depth \(1\le h\le m\), the behavioral metric is Hamming distance on the
\(h+1\) recursive classes.  Writing
\[
 J_h=\log(m+1)-\frac{m+1-h}{m+1}\log(m+1-h),
\]
we prove the complete curve
\[
 R_h(D)=
 \begin{cases}
 J_h-h_2(D)-D\log h,&0\le D<h/(m+1),\\
 0,&D\ge h/(m+1).
 \end{cases}
\]
The converse is a sharp Fano bound and the achievability proof gives an
explicit test channel.  Since the current-color metric is identically zero on
the protected states, this formula is also an exact rate-gap theorem for using
the wrong, myopic distortion: a zero-rate carrier misses any recursive target
\(D<h/(m+1)\).

We also prove that context-generated side-information graphs are universal:
every finite simple graph occurs already at depth zero.  Thus the quotient
tower alone cannot imply perfectness or a closed graph-entropy formula; extra
side-information structure is genuinely necessary.  For the behavioral
metric, monotone iteration has a least fixed-point limit even at unit discount,
while strict discount gives the familiar unique contraction fixed point.
Finally, standard persistent-versus-innovative examples and a corrected public
update lemma separate resident state from causal refresh.  The resulting
account keeps worst-case memory, average state information, side-information
coding, lossy rate, refresh communication, and statistical evidence as typed
rather than additively interchangeable resources.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 1.4 Certificate-Directed Wavelet Acquisition

**Full title:** Certificate-Directed Wavelet Acquisition: Opposite-World Information, Tree-Constrained Sensing, and Lossless Evidence Compression  
**Exact source:** [`extend17/wavelet_acquisition.tex`](extend17/wavelet_acquisition.tex)

#### Abstract

Wavelet acquisition is commonly directed by coefficient magnitude, local
energy, or reconstruction error.  Those criteria can be orthogonal to the
evidence needed for a statistical decision.  We formulate every wavelet
tree node as an experiment and direct acquisition by its Kullback--Leibler
information against task-opposite worlds.  For a finite world model and a
task map that may identify several worlds with the same answer, the local
characteristic information is a max--min allocation over nodes.  A
change-of-measure theorem shows that its reciprocal is the unavoidable
leading fixed-confidence sample cost.

The formulation separates three restrictions.  A downward-closed tree
budget determines which scales can be activated; a measurable evidence
carrier determines what part of each acquired coefficient is retained; and
an adaptive allocation determines how often each active node is queried.
Tree selection is an explicit mixed-integer max--min program.  Evidence
compression obeys an exact KL chain rule.  The Certificate Statistics slack
theorem specializes to a finite-slack zero-tax gate: compressed observations
preserve the raw characteristic information
if and only if some raw-optimal allocation loses no more KL against every
alternative than that alternative's raw slack; every binding opposite
world must lose exactly zero weighted information.

The tree restriction has two quantitative consequences.  First, on a
complete depth-\(h\) Gaussian tree we construct reciprocal exponential
separations between certificate-visible budget and ordinary best-term
reconstruction width: either quantity can be \(2^h\) while the other is only
\(h+1\).  Second, when the activated subtree is selected from the same data,
the expected sampling frequencies need not belong to any single feasible
subtree.  We identify the correct convexified occupancy set and prove the
corresponding adaptive-menu lower bound; the nonconvex tree-budget value is
recovered only under an explicit stabilization condition.

Two witnesses show why energy is not a certificate.  A node can have
arbitrarily large energy and zero opposite-world information, while a
low-energy node can be decisive.  Moreover, for Gaussian wavelet
coefficients with means \(\mu\) and \(-\mu\), magnitude, energy, and squared
coefficient carriers have identical laws in the two worlds and hence zero
retained KL, although the signed coefficient has KL
\(2\mu^2/\sigma^2\).  With multiple alternatives, the optimal sampling
allocation balances binding KL rates rather than choosing the single most
energetic or most informative node.

We give a certificate-directed acquisition template combining worldwise
likelihood-ratio stopping, budgeted subtree activation, KL-designed
thresholds, forced exploration, and allocation tracking.  Its stopping
rule is nonasymptotically valid under adaptive acquisition.  Under stated
identifiability, stabilization, and uniform-integrability conditions, its
sample complexity attains the tree-budget characteristic time.  The result
turns wavelet nodes from reconstruction objects into typed experiments and
makes scale choice, thresholding, and active sampling answerable to the
same decision certificate.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

## 2. Game theory and strategic learning

### 2.1 Information-Limited Strategic Regret

**Full title:** Information-Limited Strategic Regret: Exact Observer--Rate Frontiers, Certificate-Optimal Sampling, and Strategic Response Ledgers  
**Exact source:** [`extend17/Strategic_Regret_Geometry.tex`](extend17/Strategic_Regret_Geometry.tex)

#### Abstract

We study robust strategic regret when an observer must both identify the
payoff world and choose the counterfactual deviation that exposes a common
deployment.  For finite convex architectures the baseline value is
\[
  V(\cC,\cQ,\cD)
  =\min_{q\in\cQ}\max_{(\theta,\phi)\in\cC\times\cD}
    g_{\theta,\phi}(q).
\]
The classical minimax dual is a joint distribution on world--deviation
pairs.  Our first result turns its dependence into a resource rather than a
binary product-versus-joint comparison.  With a fixed world prior, constrain
the observer channel \(K(\phi\mid\theta)\) by
\(I(\Theta;\Phi)\le B\).  The resulting value \(V_\pi(B)\) is attained,
nondecreasing and concave in \(B\), and satisfies a sharp zero-information
endpoint together with a Pinsker transmission bound.  For an \(m\)-world
action-identification family we obtain the entire frontier in closed form:
\(V_m(B)=1-D_m(B)-1/m\), where
\(\log m-h_2(D_m)-D_m\log(m-1)=B\).  Thus strategic observer power has an
exact rate--regret curve, not merely a qualitative coupling premium.

Our second result makes the joint certificate statistically operational.
For a regular finite saddle problem with unique deployment \(q^\star\) and
certificate \(\lambda^\star\), the value gradient with respect to an
unknown gain coefficient is exactly
\(\lambda_e^\star q_x^\star\).  Under independent Gaussian payoff samples
we derive the local Cram\'er--Rao bound and the optimal allocation
\(w_{ex}\propto\lambda_e^\star q_x^\star\sigma_{ex}\); the plug-in saddle
value and a two-stage pilot design attain the bound asymptotically.  In a
reproducible \(18\times15\) stress test, uniform sampling has asymptotic
scaled MSE \(30\), whereas certificate sampling has value \(1\); at
\(N=24000\), the feasible two-stage design reduces RMSE by a factor of
\(4.37\).

Classical minimax duality, \(\Phi\)-equilibrium constraints, public versus
private randomization, and commitment effects are retained as explicitly
labelled calibrations.  They yield an audited capacity/observer ledger and a
three-term equilibrium-response decomposition, while the information
frontier and certificate-optimal experiment are the paper's load-bearing
results.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 2.2 Recursive Strategic State Compression

**Full title:** Recursive Strategic State Compression: Approximate Shapley Quotients, Lifted Exploitability, and Quantized Regret Memory  
**Exact source:** [`extend17/Recursive_Strategic_Elimination.tex`](extend17/Recursive_Strategic_Elimination.tex)

#### Abstract

Exact probabilistic bisimulation and partition refinement already provide
the classical answer to when a finite labeled transition system can be
minimized.  This paper asks the quantitative question needed by strategic
compression: when rewards and block-transition laws are only approximately
preserved, how much zero-sum value and exploitability can be lost, and how
many bits of recursive regret state are needed for a declared task?

For a discounted finite zero-sum stochastic game and a proposed quotient,
let \(\eps_r\) bound every one-step reward error and let \(\eps_p\) bound the
total-variation error of every action-pair block transition.  We prove the
finite-horizon recursion
\[
 E_0=\eps_0,\qquad
 E_{h+1}=\eps_r+\gamma E_h+\gamma\eps_p B_h,
 \quad
 B_h=\gamma^hW+R\sum_{j=0}^{h-1}\gamma^j,
\]
and show that \(E_h\) controls the uniform fine-to-quotient value error.
For \(\gamma<1\), the stationary bound is
\[
 E_\infty=\frac{\eps_r}{1-\gamma}
   +\frac{\gamma R\eps_p}{(1-\gamma)^2}.
\]
Any quotient saddle pair lifted to the fine game has pointwise
best-response gap at most \(2E_\infty\), even when a deviator observes the
fine state.  An actionless family makes the transition term asymptotically
sharp.  The theorem also separates a value-only transition contract from
the stronger observation-complete contract required to preserve public
signal laws.

For regret matching we replace a qualitative infinite-state observation by
an exact rate--distortion law.  Along a positive radial family \(cr\) and an
authorized update \(\delta\), the post-update policies form an \(\ell_1\)
line segment of explicit length \(L_I\).  The exact minimax distortion of an
\(N\)-code carrier is \(L_I/(2N)\); with \(b\) bits it is
\(L_I/2^{b+1}\).  The same number is the worst error over all bounded local
payoff queries.  A reproducible 15-state stress test verifies the Shapley
and lifted-exploitability certificates over 500 perturbed games and checks
the bit-rate law numerically.  Classical exact refinement and UCT collisions
are retained only as calibration and routing diagnostics, with their prior
art stated explicitly.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

## 3. Time series, dependence, and dynamical closure

### 3.1 Time--Scale Elimination Geometry

**Full title:** Time--Scale Elimination Geometry: A Typed Audit of Carrier Deletion, Crossband Restrictions, and Dynamic Separation  
**Exact source:** [`extend17/timescale_eg.tex`](extend17/timescale_eg.tex)

#### Abstract

Time-series prediction and multiresolution analysis eliminate information
along different axes.  The temporal filtration records when information is
available; a scale carrier records which distinctions are retained.  A third
restriction may keep every scale coordinate while forbidding crossband
prediction.  Conflating these contracts can hide forecasting loss, confuse
carrier failure with decoder failure, or introduce future leakage.

This paper is a typed audit rather than a new projection calculus.
Conditional-expectation Pythagoras gives the carrier and decoder ledger, and
ordinary least-squares Pythagoras gives the linear architecture ledger.  In
the block-covariance case, projection onto scale-separated predictors reduces
to the classical pinching map: its residual is exactly the weighted energy of
the two crossband blocks.  We record this identity as a calibration result,
not as the paper's novelty, and sharpen the general commutator lower
certificate to its optimal constant.

The structural result is a \(d=Kr\) dimensional stationary Gaussian VAR
family whose dynamics transport \(r\)-dimensional resolution blocks along an
arbitrary permutation.  For a retained block set \(S\), the carrier tax is
\(\rho^{2h}r(K-|S|)\), while the crossband tax is
\(\rho^{2h}r|S\mathbin{\triangle}\pi^{-h}(S)|\).  More generally, the latter
is twice \(\rho^{2h}\) times the sum of squared sines of the principal angles
between a resolution subspace and its transported copy.  A two-scale swap is
the smallest specialization, not the only witness.

We also make the statistical and operational interfaces explicit.  In an
independent Gaussian transition experiment, estimating the crossband
commutator has minimax squared risk
\(\asymp \min\{B^2,\sigma^2s(d-s)/n\}\); ordinary least squares attains the
rate, and a conditionally unbiased estimator of the squared crossband tax has
an exact variance formula.  For nonlinear decisions, a declared conditional
loss envelope gives a transmission modulus: deploying the carrier-Bayes
action incurs at most twice the corresponding conditional integral
probability metric, and at most \(2L W_1\) for uniformly \(L\)-Lipschitz
losses.  A reproducible \(24\)-dimensional Monte Carlo experiment verifies the
horizon formula, debiasing identity, and estimation scaling.

The operator commutator used for the linear calibration is the literal matrix
commutator; it is not the elimination--coupling interchange gap used in the
general elimination-geometry manuscripts.  The connection to elimination
geometry is instead the typed order of carrier deletion, decoder restriction,
task observation, and causal deployment.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 3.2 Dependent Elimination Geometry

**Full title:** Dependent Elimination Geometry for Distributional Prediction: Exact Modal Taxes and Sharp Dependence-Aware Minimax Rates  
**Exact source:** [`extend17/dependent.tex`](extend17/dependent.tex)

#### Abstract

Dependence enters distributional learning through two different channels.
A history contains predictive information that a finite architecture may
compress, while repeated observations create correlated estimation noise.
We keep these channels separate before asking which losses survive a
downstream task.  Classical Hilbert projection, CRPS propriety, finite-sample
long-run covariance, graph Wiener filtering, and blocking arguments provide
the accounting layer; we state their provenance explicitly.

The first new result prices nonstationary graph noise exactly.  Let the
graph-source covariance \(Q\) commute with a Laplacian \(L\), put
\(M=Q+\Sigma\), and let \(A^\star=QM^{-1}\) be the unrestricted Wiener
rule.  For a simple graph spectrum, in graph Fourier coordinates
\(\widetilde Q=\operatorname{diag}(q_i)\), the best graph-modal rule has
multiplier \(d_i=q_i/\widetilde M_{ii}\) and its exact architecture tax is
\[
 \Delta_{\rm dep}
 =\operatorname{tr}(\widetilde Q\widetilde M^{-1}\widetilde Q)
   -\sum_i\frac{q_i^2}{\widetilde M_{ii}}.
\]
For arbitrary multiplicities we prove matching commutator certificates,
up to the condition number of \(M\) and the ratio between the largest and
smallest distinct Laplacian eigenvalue gaps.  Thus noncommutation is not only
a zero-versus-positive gate: it quantitatively controls the entire weighted
projection loss.  A two-mode formula and a bounded binary-CDF construction
make the tax explicit and show that CDF repair need not be its cause.

The second new result is a genuinely dependent minimax lower bound.  On
growing paths, under \(0\preceq\Gamma_n\preceq\kappa I\), projected
Richardson smoothing has risk
\[
 \frac{\kappa}{N}
 +R^{2/(4s+1)}\left(\frac{\kappa}{N}\right)^{4s/(4s+1)}.
\]
We construct an independent-across-vertices but temporally persistent
refresh Markov panel whose finite-horizon covariance obeys the same envelope
and whose effective number of innovations is of order \(n/\kappa\).
Assouad's method then gives the matching lower bound, including its
\(\kappa\)-dependence, for \(1/4\le\kappa\lesssim n\).  This replaces the
independent subexperiment used in the earlier version.

The surrounding distributional ledger identifies the canonical predictive
carrier \(F_Z=\mathbb E(F_{\mathcal D}\mid Z)\), the exact marginal-to-
predictive CRPS exchange term, CDF-projection repair, covariance plug-in
stability, and gap-block tuning.  A reproducible 24-node Monte Carlo study
checks the exact modal formula: the measured tax is zero for commuting noise
and agrees with the positive predicted value under a rank-one graph-spectral
factor.  Predictive information, sampling dependence, graph realizability,
and semantic validity therefore remain separate, but the two nontrivial
interfaces now have exact quantitative theorems.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 3.3 Fractional-Memory Forecasting

**Full title:** Finite-State Taxes for Fractional-Memory Forecasting: Quantitative Stability--Gain Tradeoffs, Typed Carriers, and Robust Deployment  
**Exact source:** [`extend17/long_memory_forecasting.tex`](extend17/long_memory_forecasting.tex)

#### Abstract

Continuous-time linear-RNN approximation theory already establishes a
general curse of memory and analyzes its optimization consequences.  We
study a complementary discrete-time boundary regime in which the target
kernel is square summable but not absolutely summable, so the usual uniform
bounded-input operator norm is infinite.  In a Gaussian fractional-memory
experiment the oracle kernel is
\(g_k(d)=\Gamma(k+d)/\{\Gamma(d)\Gamma(k+1)\}\), \(0<d<1/2\), and forecast
excess mean-squared error is exactly squared \(\ell_2\) kernel distance.

The main result is a finite-tolerance no-compensation theorem.  If a stable
recurrent impulse response satisfies \(|r_k|\le B\rho^k\), then its error is
bounded below by an explicit fractional tail after the first index at which
\(B\rho^k\le g_k(d)/2\).  Consequently, attaining excess error \(\epsilon\)
forces either \(\rho\uparrow1\) at a quantified rate or an exponentially
large envelope \(B\); for a contractive realization, \(B\) is the
input--readout gain, while for a nonnormal realization it also prices
transient amplification.  A matching \(K\)-state FIR witness attains both
orders, so the alternative is not merely one-sided.  This strengthens the
qualitative fact that no
finite rational recurrence realizes \((1-z)^{-d}\), for which we also give a
finite Hankel certificate.  Exact ledgers are derived for a delay line,
positive exponential modes, and wavelet carriers, without equating their
different capacity currencies.  A constructive \(K\)-node Gauss--Jacobi
realization matches the first \(2K\) fractional coefficients and gives the
explicit positive-state upper bound
\(D_K^{\mathrm{frac}}(d)\le D_{2K}^{\mathrm{FIR}}(d)\).

When \(d\) is uncertain, orthogonal projection shows that nonlinear
prediction and independent randomization cannot beat the Hilbert-space
Chebyshev radius of the oracle family.  For two worlds the common-deployment
tax is exactly one quarter of their squared kernel distance.  We derive the
pullback metric of the fractional family in closed form and show that it
diverges as \(2/\{\pi(1-2d)^3\}\) near the stationarity boundary.  The paper
also distinguishes this common-innovation kernel metric from the
statistical Fisher information for an observed Gaussian fractional model.
It therefore contributes discrete \(\ell_2\) stability--gain and robust-
deployment geometry, rather than claiming priority for the general
long-memory curse.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 3.4 Mori--Zwanzig Closure

**Full title:** Mori--Zwanzig Closure from One Trajectory: Simultaneous Defect Certificates, Sharp Visit Complexity, and Returned-Memory Spectra  
**Exact source:** [`extend17/Mori_Zwanzig_Elimination_Geometry.tex`](extend17/Mori_Zwanzig_Elimination_Geometry.tex)

#### Abstract

Coarse variables can agree on every current output and still fail to form a
closed dynamical state.  Classical lumpability identifies this failure with
noninvariance of the block-constant subspace, while the classical
Mori--Zwanzig identity factors its dynamical return into injection, hidden
propagation, and readout.  We use those facts as calibration and study the
statistical question they leave open: can closure and returned memory be
certified from one passively observed trajectory?

For a finite colored Markov kernel with known positive reference \(\pi\), we
normalize the injection by the orthonormal block basis,
\[
 \mathfrak J_\pi(\Pi)
 =\sum_{B\in\Pi}
   \left\|\mathsf Q_\Pi\mathsf K
   \frac{\mathbf1_B}{\sqrt{\pi(B)}}\right\|_{L^2(\pi)}^2
 =\|\mathsf Q_\Pi\mathsf K\mathsf P_\Pi\|_{\rm HS}^2.
\]
From a single trajectory, at every stopping time and simultaneously over all
source states, target blocks, and candidate splits, we construct explicit
bounds \(L_n\le\mathfrak J_\pi(\Pi)\le U_n\).  The proof samples departures
at state-visit times, so serial dependence requires no effective-sample-size
fiction: mixing controls only how quickly the trajectory visits every state.
A Doeblin corollary converts visit complexity to clock time.  A split of size
\(\delta\) is certified after
\(O\{\delta^{-2}[\log(|S||\Pi|/\alpha)+\log(1/\delta)]\}\) visits to its two
states, and a two-point lower bound proves the \(\delta^{-2}\log(1/\alpha)\)
dependence unavoidable even under direct state resets.  The upper certificate
also gives a confidence-valid finite-memory horizon whenever the unresolved
propagator has declared geometric decay.

We finally give an exactly solvable \(2m\)-state family.  Its normalized
injection is \(m a^2/2\), independent of a persistence parameter \(\rho\),
whereas its lag-\(k\) returned-memory eigenvalues are
\(a^2\sin^2\theta\,(\rho-a\cos\theta)^k\).  Thus equal one-step defects can
have sharply different memory lifetimes, and the slowest hidden mode can be
completely invisible at the return gate.  A reproducible 16-state experiment
checks the simultaneous certificates and the exact spectrum.  The new
results are the trajectory-uniform two-sided certificate, its near-minimax
visit complexity, and this joint injection--return family---not the
underlying projection or lumpability identities.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 3.5 Projected Return-Kernel McMillan Degree

**Full title:** Projected Return-Kernel McMillan Degree: Separating Open-Loop Memory, Closed-Trajectory Visibility, and Dynamic Closure  
**Exact source:** [`extend17/task_visible.tex`](extend17/task_visible.tex)

#### Abstract

Eliminating hidden variables can generate memory even when the retained
variables have a simple current output.  This note identifies three capacities
that are easily conflated: the McMillan degree of a task-projected open-loop
return kernel, visibility of a hidden perturbation in the actual closed
trajectory, and the state dimension required to close the resolved memory.

For the block recursion
\[
 u_{t+1}=Au_t+Bv_t,
 \qquad
 v_{t+1}=Cu_t+Dv_t,
\]
and task readout \(y_t=T u_t\), elimination of \(v_t\) generates the
projected return kernels
\[
 G_k=TBD^kC,
 \qquad k\ge0.
\]
Let \(\cR_C\) be the hidden subspace reachable from the injection \(C\), and
let \(\cN_{TB}\) be the unobservable subspace of the auxiliary triple
\((C,D,TB)\).  The projected return quotient is
\[
 \cV_{\rm pr}=\cR_C/(\cR_C\cap\cN_{TB}).
\]
By the classical Kalman--Ho--Kalman minimal-realization theorem, its dimension
equals the rank of the infinite block Hankel matrix
\(\mathscr H_G=(G_{i+j})_{i,j\ge0}\), the minimum dimension of an exact
time-homogeneous linear realization of this projected kernel, and the
reachable--observable dimension of \((C,D,TB)\).  We call this number
\(r_{\rm pr}\), the projected return-kernel McMillan degree.  It is not, in
general, the dimension of a carrier that reproduces the actual task trace.

To expose the distinction, set
\(M=\left[\begin{smallmatrix}A&B\\C&D\end{smallmatrix}\right]\),
\(Y=[T\ 0]\), and \(Jv=(0,v)\).  Closed-trajectory invisibility is governed by
\(YM^tJv=0\) for every \(t\), while exact closure of the resolved memory is
governed by the unprojected kernels \(BD^kC\).  We give explicit systems with
\(r_{\rm pr}=0\) although an injected hidden mode changes \(y_t\), and with
\(r_{\rm pr}=1\) although two generated hidden directions are visible in the
closed trajectory.  Always
\[
 r_{\rm pr}\le r_{\rm cl}
 :=\operatorname{McMillan}\{BD^kC\},
\]
and the inequality can be strict; closed-trajectory visibility is a different
full-system observability contract and need not equal either rank.

For the projected kernel we also record two modest consequences: a
finite-horizon Eckart--Young lower certificate and a confidence-valid,
one-sided singular-value rank witness.  The certificate states that every
smaller \emph{linear} recurrent carrier incurs squared per-lag error at least
\(\min(a,b)^{-1}\) times the squared truncated-Hankel tail.  Verification code
checks the algebra, the strict-separation examples, and the certificates.

The contribution is therefore a dictionary and a warning for elimination
models, not a new realization theorem: projection of a one-step return,
visibility in a feedback trajectory, and closure of the resolved recursion
are three typed questions and must not share one unqualified ``memory rank.''

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

## 4. Statistical physics, diffusion, and renormalization

### 4.1 Task-Conditioned Renormalization

**Full title:** Task-Conditioned Renormalization: Multiscale Projection-Tax Conservation, Task Transmission, and Nonmonotone Architecture Windows  
**Exact source:** [`extend17/Task_Conditioned_Renormalization.tex`](extend17/Task_Conditioned_Renormalization.tex)

#### Abstract

Repeated real-space coarse graining is usually followed by projection into a
restricted interaction grammar, but the way successive projection errors
compose is rarely made explicit.  We prove an exact multiscale conservation
law.  Let \(P_k\) be the exact law at scale \(k\), let \(Q_k\) be its
forward-KL projection into an exponential grammar \(\cA_k\).  Without a
closure assumption we obtain an exact ledger with a signed interchange
remainder.  That remainder vanishes universally if and only if the grammars
are projectively consistent,
\(q_{k\#}\cA_k\subseteq\cA_{k+1}\).  Under this sharp condition, with
\(\Delta_k=\beta^{-1}\KL(P_k\|Q_k)\),
\[
 \boxed{\Delta_k=\Delta_{k+1}+H_k+C_k,}
\]
where \(H_k\) is the conditional KL hidden in eliminated fibers and
\(C_k=\beta^{-1}\KL(Q_{k+1}\|q_{k\#}Q_k)\) is a cross-scale recentering
tax.  Hence \(\Delta_0=\Delta_m+\sum_{k<m}(H_k+C_k)\), with no untyped
``accumulated truncation error.''  For bounded downstream observables we also
derive a transmission inequality in which \(C_k\) is exactly the surcharge
for replacing the pushed-forward fine projection by the newly refitted
coarse projection.

An arbitrary-dimensional tied-product Bernoulli family makes every term
closed form.  Deleting coordinate \(j\) from a set \(S\) gives
\(H=\beta^{-1}\kl(p_j\|\bar p_S)\) and
\(C=\beta^{-1}(|S|-1)\kl(\bar p_{S\setminus j}\|\bar p_S)\).  Every
elimination order telescopes to the same total heterogeneity, but divides it
differently between hidden-fiber and recentering mechanisms.  A reproducible
64-dimensional experiment verifies all 63 scale ledgers for three adaptive
orders; a separate verifier checks 11,200 randomized identities.

We then revisit the standard five-spin Ising decimation example as a
calibration, with its textbook pair and four-body couplings explicitly
cited.  The pairwise forward-KL tax \(\Delta_2(K)\) is positive away from
zero but tends back to zero as \(|K|\to\infty\); a reproducible
one-dimensional calculation locates its numerical peak at
\(|K|=1.266048\) with value \(0.0141693\) for \(\beta=1\).  Thus the
four-body architecture is selected only in a bounded coupling window, not a
half-plane.  Moreover, the exact and pair-projected laws agree on every
Walsh monomial of degree at most three; four-spin parity is the unique
monomial direction that distinguishes them.

Exact Gibbs marginalization, exponential-family Pythagorean geometry,
deterministic annealing, and the local star identity are retained only as
classical calibrations.  The multiscale conservation theorem, its task
transmission corollary, the high-dimensional family, and the nonmonotone
architecture window are the paper's load-bearing results.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 4.2 Path-Space Distillation Taxes

**Full title:** Path-Space Distillation Taxes in Generative Diffusions: Temporal Compression, Exact \(K^{-2}\) Floors, and Contract Escape  
**Exact source:** [`extend17/continuous.tex`](extend17/continuous.tex)

#### Abstract

Diffusion distillation replaces a time-resolved teacher by a cheaper
student.  Whether this compression must lose information depends first on
what the student is required to reproduce: a full stochastic path, a
filtered trajectory, or only a terminal sample.  We develop an exact
path-space calculus for this distinction.

For two nondegenerate diffusions with the same volatility, Girsanov's
identity makes teacher-to-student path relative entropy an
occupation-weighted squared drift error.  We restrict the student to
\(K\) temporal stages, allowing an otherwise arbitrary measurable state
map in every stage.  Orthogonal projection then yields an exact
architecture ledger: path defect equals an irreducible temporal
compression tax plus the student's within-architecture implementation
error.  The tax has a conditional-variance form and, when the teacher
marginals admit densities, a pairwise oracle-variation formula that
charges drift differences only where the corresponding state
distributions overlap.

The flagship example is a time-inhomogeneous rotational
Ornstein--Uhlenbeck teacher.  Its one-time marginals are all standard
Gaussian, but its angular path dynamics vary linearly in time.  Against
every Girsanov-admissible \(K\)-stage state-feedback student, the optimal
teacher-forced path KL is exactly
\[
  \frac{\alpha^2\lVert A\rVert_{\mathrm F}^2T^3}{24K^2}.
\]
Within the natural stationarity-preserving control class, the same formula
holds for the forward KL and hence for the stochastic-control
orientation.  For this teacher the constant is exact, and equal-width
stages are optimal.

The same example also proves the necessary negative result.  Every
student in that control class has exactly the teacher's one-time
marginals, and even the entire radial path law is unchanged.  Thus a
positive path tax need not imply any terminal-distribution tax.  More
generally, an exact relative-entropy chain rule under a measurement or
filtering channel splits path defect into observed defect and a hidden
conditional-path anomaly.  Consequently, the \(K^{-2}\) floor is a
lower bound for a declared path contract, not a universal lower bound on
one- or few-step generation.  This contract-sensitive separation places
temporal architecture error alongside, rather than in place of, model,
generalization, optimization, and numerical-discretization errors.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 4.3 Hidden Entropy Production

**Full title:** Hidden Entropy Production under Contractive Observation: Exact Path Ledgers, Rotating Diffusions, and Certificate-Optimal Sensors  
**Exact source:** [`extend17/Hidden_Entropy_Production.tex`](extend17/Hidden_Entropy_Production.tex)

#### Abstract

Irreversibility is a property of a forward path law relative to a declared
reversed path law.  A sensor sees only a contraction of that experiment and
can therefore report equilibrium even when the hidden process sustains a
probability current.  We give an exact elimination-geometry account of this
loss and connect it to statistical certification.

For any forward path law \(\mathbb P\), physically reversed reference
\(\mathbb P^\dagger\), and common observation channel \(K\), relative-entropy
disintegration gives
\[
 \underbrace{\KL(\mathbb P\|\mathbb P^\dagger)}_{\text{total entropy production}}
 =
 \underbrace{\KL(\mathbb P K\|\mathbb P^\dagger K)}_{\text{observed}}
 +
 \underbrace{\E_{\mathbb P K}
   \KL\!\left(\mathbb P(\cdot\mid Y)\|\mathbb P^\dagger(\cdot\mid Y)\right)}_{
   \text{hidden conditional-path anomaly}}.
\]
The identity holds for deterministic or noisy sensors.  Nested sensors yield
an additive exposure ledger, and Blackwell refinement can only increase
observed entropy production.

The flagship family is a rotating Ornstein--Uhlenbeck diffusion
\[
 \dd X_t=\{-\tfrac12X_t+\omega(t)AX_t\}\dd t+\dd W_t,
 \qquad A^\top=-A,
 \qquad X_0\sim N(0,I).
\]
All one-time marginals are standard Gaussian.  For a driven protocol, the
physical reference reverses the protocol and then the trajectory.  Its
forward-time drift is \(-x/2-\omega(t)Ax\), and the exact mean total entropy
production is
\[
 \Sigma_{\rm phys}(\omega)
 =2\norm{A}_{\Fro}^2\int_0^T\omega(t)^2\dd t.
\]
By contrast, directly reversing trajectories from the same forward
experiment gives
\(\Sigma_{\leftarrow}(\omega)
=\norm{A}_{\Fro}^2\int_0^T
\{\omega(t)+\omega(T-t)\}^2\dd t/2\), a lower bound that agrees with physical
production exactly for time-symmetric protocols.
Endpoint and radial-path observations see zero entropy production, so the
entire value is hidden.  For block-diagonal rotations, a sensor that records
\(q\) complete rotation planes observes exactly the sum of their block
contributions; choosing the \(q\) largest angular blocks is optimal.

The same family sharply distinguishes thermodynamic irreversibility from
teacher--student compression.  For \(\omega(t)=\alpha t\), the best
\(K\)-stage compression KL is
\[
 \frac{\alpha^2\norm{A}_{\Fro}^2T^3}{24K^2},
\]
whereas total physical entropy production is
\(2\alpha^2\norm{A}_{\Fro}^2T^3/3\).  Their ratio is \(1/(16K^2)\);
the ratio to direct trajectory-reversal asymmetry remains \(1/(12K^2)\).
An arbitrary teacher--student KL is therefore not entropy production.

Finally, observed entropy production is shown to be the native information
rate for a directional certificate.  Any test with both errors at most
\(\delta<1/2\) based on \(n\) independent observed paths must satisfy
\(n\Sigma_{\mathrm{obs}}\ge\kl(1-\delta\|\delta)\), while the observed likelihood
ratio is an exact e-process under the reversed law.  Sensor design can thus be
stated either as maximizing exposed dissipation or minimizing certified
sample complexity, without conflating physical, observational, and
statistical accounts.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

## 5. Queueing and market microstructure

### 5.1 Task-Visible State-Space Collapse

**Full title:** Task-Visible State-Space Collapse in a Marked Class-Blind Queue: Exact Control-Regret and Evidence Crossovers  
**Exact source:** [`extend17/queue.tex`](extend17/queue.tex)

#### Abstract

State-space collapse (SSC) replaces a high-dimensional queueing state by a
low-dimensional workload.  It is usually interpreted geometrically: after
scaling, the queue-length vector approaches a lifted workload manifold.  We
ask a different question.  When does this geometric approximation remain
safe for a declared downstream decision or statistical experiment?

After recalling standard value-of-information and plug-in decision bounds,
we analyze a two-class egalitarian processor-sharing $M/M/1$ queue.  Its key
mechanism is independent marking: class labels are iid marks independent of
the class-blind total-count trajectory.  The geometric total-count law then
makes every finite-$\delta$ calculation explicit.  With load
$\rho=1-\delta$, the scaled class vector
$X_\delta=\delta(N_1,N_2)$ collapses in mean square to
$(W_\delta/2,W_\delta/2)$ at rate $\sqrt{\delta}$, where
$W_\delta=\delta(N_1+N_2)$.

That same collapse has three incompatible task consequences.  First, a
bounded majority-selection task has optimal workload-only regret
\[
 \frac12\left(1-\sqrt{\frac{\delta}{2-\delta}}\right)
 \longrightarrow \frac12,
\]
so geometric SSC alone does not protect even bounded losses.  Second, for a
class-directed linear task with sensitivity $\kappa_\delta$, the exact
workload-only regret is
\[
 \cR_\delta
 =\kappa_\delta\frac{(1-\delta)\sqrt{\delta}}
 {2\sqrt{2-\delta}}.
\]
Hence $\kappa_\delta=\delta^{-\alpha}$ gives a safe--critical--unsafe rate
crossover at $\alpha=1/2$.

Third, workload can be sufficient for total congestion while being useless
for evidence.  For two worlds whose class proportions are
$1/2\pm c\delta^\beta$, the entire unmarked total-count path has identical
law and therefore zero Kullback--Leibler divergence at every horizon.  A
single marked stationary snapshot has exact Hellinger affinity
\[
 \frac{\delta}
 {1-(1-\delta)\sqrt{1-4c^2\delta^{2\beta}}},
\]
which yields a second local-alternative boundary at $\beta=1/2$ and an exact
independent-snapshot sample scale.

Independent marking, the queueing product form, decision-transfer bounds,
and classical SSC theory are imported.  The contribution is their
task-conditioned composition: an exact reduction rate, an exact
control-regret law, and a strict performance/control/evidence carrier
separation inside one queue.  This motivates \emph{task-safe SSC}:
every reduction must declare the downstream loss and observation contract
that it promises to preserve.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 5.2 Event-Order Geometry of Limit Order Books

**Full title:** Event-Order Geometry of Limit Order Books: Noncommuting Queue Updates, Sharp Aggregation Bounds, and a Depth--Sampling Crossover  
**Exact source:** [`extend17/microstructure_event_order.tex`](extend17/microstructure_event_order.tex)

#### Abstract

Short-horizon market-microstructure models often aggregate limit additions,
liquidity removals, and cancellations into event counts or an order-flow
imbalance.  Such a summary treats the events inside an interval as if they
commuted.  At a best quote they do not: replenishment followed by removal can
leave the quote standing, while the same two events in the reverse order can
deplete the queue and move the price.

We isolate this mechanism in a regenerative best-queue model.  Starting from
depth $q$, a unit addition increases depth by one; a unit removal decreases it
by one, except that a removal at depth one moves the quote by one tick and
reinitializes depth at $b$.  For an event word, let $S$ be terminal net flow
and $M$ its running prefix minimum.  We prove that the number $K$ of quote
moves is the discrete regulator
\[
 K=\max\left\{0,
 \left\lceil\frac{1-q-M}{b}\right\rceil\right\},
 \qquad Q_{\rm end}=q+S+bK.
\]
The pair $(S,M)$ composes recursively under a noncommutative min-plus product
and is the coarsest universal exact carrier for terminal queue and price
readouts in this grammar.  The product is the classical bicyclic-monoid
product in different coordinates; the new statement is the typed minimality
for this queue/price readout.  Event counts retain $S$ but delete $M$.

We then characterize the entire count fiber.  If an interval contains $A$
additions and $R$ removals, the compatible quote-move counts are exactly all
integers between
\[
 K_L=\max\left\{0,
 \left\lceil\frac{R-A-q+1}{b}\right\rceil\right\},\qquad
 K_U=\max\left\{0,
 \left\lceil\frac{R-q+1}{b}\right\rceil\right\}.
\]
This gives sharp minimax reconstruction error.  In a two-sided extension, the
same side-specific counts can imply opposite signed price changes; even after
the terminal price is supplied, total quote variation can remain partially
identified.

Finally, conditional on $m$ additions and $m$ removals in uniformly random
order, the reflection principle gives, for $k\ge1$,
\[
 \Pp(K\ge k)=
 \frac{\binom{2m}{m+q+b(k-1)}}{\binom{2m}{m}}.
\]
The numerator is zero when its lower index exceeds $2m$.
If $n=2m$ and $q/\sqrt n\to\theta$, then
$\Pp(K>0)\to e^{-2\theta^2}$.  Count-only classification of whether the
quote moved has a nonzero critical error and is maximally ambiguous at
$\theta=\sqrt{\log 2/2}$.  This is a smooth depth--sampling crossover, not a
thermodynamic phase transition; its critical event scale is quadratic in
visible depth.

Queue-depletion models, reflected processes, the ballot theorem, and empirical
order-flow imbalance are classical ingredients.  The contribution is their
task-conditioned composition: an exact event-order carrier, a sharp
order-erasure identification region, and a depth--sampling crossover law.  The
paper concerns price formation and intrainterval path reconstruction, not a
tagged order's fill, adverse selection, or a claim of trading profitability.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.

### 5.3 Execution-Visible Market States

**Full title:** Execution-Visible Market States: Sharp Fill and Value Bounds from Market-by-Price Histories  
**Exact source:** [`extend17/execution_visible_market_states.tex`](extend17/execution_visible_market_states.tex)

#### Abstract

Historical limit-order-book studies often insert a hypothetical passive order into a
market-by-price (MBP) tape and report a single fill label.  Under price-time priority,
that label need not be identified: MBP reports aggregate depth changes but deletes the
location of a cancellation relative to the hypothetical order.  We formulate this as a
pathwise partial-identification problem.  For a unit tagged order at one FIFO price
level, we prove that every MBP event prefix admits an exact constant-time recursion for
the set of still-possible queue ranks.  The set is always an integer interval
$[\ell_k,u_k]$, while a companion support records every feasible fill step.  The
endpoints are the coarsest exact prospective carrier for answering, under all future
trade sizes and at fixed displayed quantity, whether a fill is possible and whether
it is certain.  Conservative and optimistic endpoint queue updates already appear in
execution practice; our result is that their simultaneous interval is the exact
identified set, has no holes, and preserves every feasible fill step.  Coupling this
support to fill-time markouts yields a sharp conditional maker-value interval, not a
point estimate.  When the interval straddles an aggressive or flat alternative, we
apply the classical two-action minimax-regret rule to obtain a task-specific
value of the cancellation-location information deleted by MBP.  An independent
fine-queue enumerator verifies the recursion on 89,275 compatible exhaustive paths;
additional random, value, and stylized ambiguity checks all pass.  The result is a
measurement theorem, not an empirical fill model: probabilities inside the identified
set require order-level outcomes or explicit structural restrictions.  We close with a
data-tiered protocol that prevents snapshot depletion from being mislabeled as own
execution.

#### Full-text loading rule

Read the exact source before stating a theorem, reproducing a formula, auditing novelty, comparing assumptions, or extending this paper's result.
