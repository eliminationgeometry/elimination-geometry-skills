# Claim Status

## Formal-result provenance audit

Having a complete book proof is not a novelty claim. Appendix G now audits
all 37 fully proved formal-result families row by row using five classes: classical/imported
(`C`), direct specialization or derived lemma (`S`), possible narrow
program-specific increment (`P`), unresolved priority-audit candidate (`O`),
and book-level synthesis/interface
(`B`). Appendix G is the single consolidated provenance ledger; the chapter
statements are not interrupted by repeated audit boxes.

The count records proof coverage, not 37 independent contributions. Most rows
are classical, direct specializations, or book-level interfaces. The finite
target-calling construction, radical value, and evidence-slack criterion are
retained as useful narrow consequences rather than asserted new mechanisms.
The dedicated result-level review of universal Gibbs base-change rigidity is
now closed: Jenčová--Petz's factorization and quantum-exponential-family
sufficiency theorems imply it as a finite-dimensional Hamiltonian
specialization.  It is coded `S`, not an unresolved originality candidate.
The new active-set conflict/saturation/repair-depth family is coded `O`: its
exact quantitative combination was not located, but independent priority is
not established.  No theorem in the 37-result proof inventory is currently
presented as an independently established original theorem.

## Established source-based results reproduced with complete book proofs

The book states and proves, in unified notation, 37 formal-result families covering:

- the exact and high-probability four-component learning decompositions;
- conjugate/Bregman native-defect identities;
- associativity of obstruction towers;
- jet exactification and its converse normal form;
- CDF validity repair and graph-roughness contraction;
- regular oracle-variation transport lower bounds;
- rectangular Bellman recursion and the coordination-residual decomposition;
- the exact radical catastrophe tax;
- atlas saturation;
- flat integrability of local elimination defect fields;
- target-calling no-go, conic lift--factorization, and the target-visible
  quotient/extraction transfer;
- resource-constrained architecture rate--distortion;
- task envelopes and contextual full abstraction;
- the soft conditional chain theorem for composed Gibbs kernels;
- honest architecture-frontier brackets, atlas stability, and three-way certification;
- the distinction between pointwise feasibility and one common deployable witness;
- observational-overlap deployment conflict, its finite-sample regret lower
  bound, and the solver/information/architecture repair trichotomy;
- a strict-KKT two-neighborhood Jacobian conflict modulus, quantitative
  one-pass code/native-loss saturation, proximal repair contraction, and an
  explicit sufficient native-loss crossing depth;
- the distinction between posterior credibility and worldwise validity;
- the characteristic-information lower bound for worldwise resolution;
- exact certificate preservation under evidence-slack domination;
- recursive certificate quotients and the universally minimal exact state;
- the typed realization interface joining deployment, evidence, recursive state, and one common certified architecture action;
- typed non-compensation among deployment, evidence, and recursive carriers;
- held-out finite-library comparison;
- the OALI population-improvement template;
- noisy partial-transport and cycle/global-section recovery;
- universal Gibbs base-change rigidity.

The complete proofs are located at the end of their respective chapters.  Supporting classical theorems remain cited or summarized in the global technical appendices.

## Established source-based results discussed but not fully reproduced

The following advanced source results are discussed for context, but their complete proofs are not reproduced in the book:

- the graph-universal probability-validity classification and complete CRPS path minimax theorem in Chapter 8;
- the universal Bellman--rectangularity converse and the architecture base-change, saturation, and dequantization refinements summarized in Chapters 13 and 18;
- the exact low-dimensional and budget-two data-selection frontiers, with their auxiliary-law and merge--split certificates, summarized in Chapter 16;
- the computer-assisted Marton Markovity counterexample, credit--semantic-tax identity, and repaired three-level obstruction theory summarized in Chapter 18; its exact instance, saved certificates, and replay verifier ship under `reproducibility/marton_markovity/`;
- the full Hodge, nearest-flat, and nearest-certified repair theory summarized in Chapter 9;
- the hidden-winding impossibility, mixed-integer degree identification, and matching degree-recovery rates summarized in Chapter 19;
- the commuting-sector classification, replacement/recoverability identities, and lossless-classicalization variants summarized in Chapter 25.

Their detailed proofs remain in the indicated companion manuscripts.  None is counted among the 37-result proof-coverage inventory above.

## Book synthesis

The following are organizing syntheses rather than claims that one source paper proved a single universal theorem:

- the certification ladder;
- the four-component population-risk decomposition as the book's principal learning decomposition;
- the joint map from native defect through architecture obstruction, operational exposure, statistical certification, and repair;
- the seven-step radical certification chain linking native defect, covering lift,
  architecture obstruction, visibility, confidence world, common witness,
  and an OAI code-path audit as the concrete artifact-integrity step, without treating
  Part VIII as an additional inference;
- the four recurring laboratories used to compare mechanisms across domains.

## Reproducible mechanism and empirical checks

Chapter 23 adds a deterministic radical-loop code-path audit.  Its fixed
two-chart rule is the same architecture on every world because the deployed
input contract explicitly exposes the target value; the chart label remains
part of the repaired output.  One seeded pool of 240 loops checks the exact
finite-grid degree routine, the common atlas, the full-root-set witness, the
even- and odd-degree analytic identities, and the collapsed-root identity.
The worldwise one-chart witness reads generator parameters and is explicitly
not treated as a deployable common baseline.  The package under
`reproducibility/radical_loop/` uses only the Python standard library and
contains unit tests, per-loop output, a machine-readable summary, and content
hashes.  Exact target values and a public uniform phase-derivative bound are
part of the synthetic contract; no model is fitted and no held-out population
inference is claimed.  The audit is not a noisy-data, learned-routing,
optimization, or application result.

The end of Chapter 23 records how these already established objects compose
into one seven-step certification loop.  That table is a book-level synthesis,
not an additional theorem or an expansion of the executable audit's claim
class.

Chapter 24 now distinguishes mechanism checks, failed frozen confirmation,
benchmark closure, and a patient-level scientific-dataset confirmation:

- digits R2 gives the targeted and generic repairs the same native carrier
  and the same 6,144-MAC budget; all 12 frozen gates pass, but the split was
  already used by R1 and therefore does not count as a fresh replication;
- WDBC-R1 remains rejected after 11 of 12 gates because its preregistered
  permuted-gradient lower-bound gate failed;
- diabetes R1 passes all 12 gates on 89 untouched confirmatory patients and
  changes the frozen decision from one pass to one pass plus two proximal
  steps at the same 288-MAC and information contracts.  This is not an
  external-person replication or a clinical-utility result;
- a separate fit-free, post-confirmation theorem-alignment audit freezes the
  binary coordinate, restricts the other nine features to the training-minmax
  box, and selects strict KKT rows 17/68.  It certifies a one-pass native-loss
  floor of `3.5584910e-05` and computes 24 proximal steps as a conservative
  sufficient depth for a tolerance at 90% of that floor.  This was not an R1
  gate and is not an independent prospective validation of the new theorem
  family or a population-support result;

- the posterior-family Monte Carlo laboratory combines exactly enumerable
  binary Gibbs kernels with a 300-replication analytic Gaussian-posterior
  particle pilot over 41 targets and 21 anchors; it checks localization order,
  perturbation bounds, exact-ratio reuse, and the ESS overlap gate, while
  withholding wall-clock and application-scale claims;
- the cytometry smoke test uses ten generated sample units, 39 marker coordinates, 24 designed populations, and a graph of cycle rank 16; it reports sample-bootstrap and Wilson intervals for matching, rare-population, missing-branch, unresolvedness, and cycle diagnostics.

The cytometry check starts from generated local components with known labels.
It does not assess cell clustering, establish biological gain, or count as a
completed Samusik analysis. Both checks have content-addressed code,
machine-readable output, deterministic seeds, a vendored source snapshot, and
a checked artifact manifest under `reproducibility/ch24/`; the default run has
no dependency on files outside that directory.

## Open directions

The book does not claim completed general results for:

- arbitrary data-dependent OALI architectures without sample splitting;
- universal random-set or PAC-Bayes generalization for learned atlases;
- globally minimal atlas construction on general graphs;
- arbitrary neural-network nonconvex convergence;
- application-scale posterior-family Monte Carlo reuse with nonlinear targets,
  adaptive source selection, long-trajectory overlap, and full wall-clock
  accounting;
- unrestricted computational lower bounds from lift size;
- positive average-risk singular taxes without regularity or complexity assumptions;
- general continuous-state rectangularity and coordination taxes;
- a completed real-data Samusik confirmation;
- universal superiority of OALI over generic mixtures, ensembling, or additional compute.
- independent priority confirmation and a prospectively frozen or external-
  person validation of the active-set conflict/saturation/repair-depth
  family;
- a distinct learning theory generated by finite partial domains or
  operational exposure alone.  The first go/no-go attack totalizes partial
  maps into masked permutations and reduces the minimal noisy architecture
  decision to sparse anomalous-edge testing.  The second gives a baseline-
  blind memory conflict whose diagnostic split reduces exactly to controlled
  sequential testing.  Those two flagship routes remain closed.

## Editorial rule

Every substantial statement in the book is written as one of:

1. a principal established result with a chapter-local complete proof;
2. an established source result explicitly marked as not reproved in the book;
3. a book synthesis;
4. a research direction.

Every principal formal result additionally states how its assumptions should be read, what its conclusion excludes, and where its complete proof is located.
