$bibtex = 'bibtex8 %O %B';
$pdf_mode = 5;
