# Operationally exposed memory conflict as a flagship theorem: go/no-go attack

**Status:** no-go for operational exposure alone under a resettable finite
diagnostic contract; the proposed flagship-learning-theorem program is closed
in its current form

**Scope:** this is a research-positioning audit, not a new theorem in the
book's 35-result proof-coverage inventory

## 1. Decision

The strongest remaining route does produce a clean learning problem, but it
does not produce a new learning-theoretic mechanism.

There is a two-world experiment in which

1. every policy executable by the baseline memory has exactly the same
   retained transcript law in the two worlds;
2. the worlds require different architecture choices after a declared memory
   charge is included;
3. temporarily retaining the erased history bit exposes the conflict;
4. a likelihood-ratio certificate authorizes the correct repair with
   logarithmic confidence cost; and
5. the repaired architecture has a positive native operational gain in the
   conflict world and no gain in the null world.

Those five clauses close the logical chain that the informal proposal asked
for.  They also reveal why it is not a flagship theory.  Once the temporary
memory refinement is admitted as a diagnostic action, architecture selection
is a controlled sequential hypothesis test.  The lower bound is exactly the
usual change-of-measure bound, with the architecture label serving as the
truth partition.  If the refinement is not admitted, the characteristic
information is zero and certification is impossible.  If it is admitted at a
price, the same test is an experiment-design problem with action costs.

Therefore:

- do not promote operationally exposed memory conflict, by itself, to a new
  architecture-choice theory;
- retain it as a sharp illustration of the typed evidence/deployment
  interface;
- treat active hypothesis testing, state abstraction, predictive/causal state
  representation, revealing POMDPs, and active automata discrimination as the
  prior-art baselines;
- do not reopen flagship positioning without a formally specified learning
  object whose minimax rate contains a term that cannot be absorbed into the
  experiment laws, state space, action costs, or ordinary representation
  class complexity.

This conclusion is stronger than “the first proof attempt failed.”  Under the
resettable finite diagnostic contract below, the proposed mechanism reduces
exactly to machinery already present in Chapter 20.

## 2. The minimal experiment

Fix a noise level \(0\leq\eta<1/2\).  In every independent episode:

1. a history bit \(H\sim\operatorname{Bernoulli}(1/2)\) appears;
2. a binary target \(B\) is generated;
3. the deployed memory emits a state \(M=\phi(H)\);
4. an action \(A\in\{0,1\}\), measurable with respect to \(M\) and the
   learner's independent randomization, is chosen; and
5. the only terminal feedback is
   \[
     R=\mathbf 1\{A=B\}.
   \]

The two population worlds are

\[
\begin{array}{c|c|c}
\text{world} & \text{target law} & \text{meaning}\\ \hline
\theta_0 & B\perp H,\quad B\sim\operatorname{Bernoulli}(1/2)
         & \text{no useful memory split}\\
\theta_1 & B=H\oplus E,\quad E\sim\operatorname{Bernoulli}(\eta)
         & \text{history-dependent action}
\end{array}
\]

where \(E\) is independent of \(H\).  Compare two architectures:

\[
  \phi_0(H)=\star,
  \qquad
  \phi_1(H)=H.
\]

The evidence contract matters.  Under baseline-only acquisition, the retained
transcript contains \((A,R)\), not the destroyed bit \(H\).  A diagnostic
memory refinement is a temporary deployment of \(\phi_1\), so that an action
may depend on \(H\) and the resulting reward is logged.  Allowing an external
auditor to retain \(H\) while claiming that the architecture erased it would
silently change this contract and invalidate the blindness claim.

## 3. Baseline blindness is exact

### Proposition 1 (all baseline policies are blind)

For every possibly randomized policy executable through \(\phi_0\), the law
of \((A,R)\) is the same under \(\theta_0\) and \(\theta_1\).  The same remains
true for every adaptive sequence of baseline-only episodes.  Consequently no
baseline-only rule can be worldwise correct with error below \(1/2\) in both
worlds.

### Proof

Because \(\phi_0\) is constant, \(A\) is conditionally independent of the
current \(H\).  In \(\theta_0\), \(B\) is a fair coin.  In \(\theta_1\), the
XOR of the fair bit \(H\) and independent noise is also a fair coin.  Hence in
both worlds, conditional on either action,

\[
  \Pr(R=1\mid A=a)=\Pr(B=a)=\frac12.
\]

Thus the joint law of \((A,R)\) is identical.  Induction over episodes gives
equality of every adaptive retained-transcript law, because the next policy
is a function of past transcripts having the same distribution.  Any terminal
architecture declaration therefore has the same distribution in the two
worlds.  Since the correct declarations below are opposite, their two error
probabilities sum to one.  At least one is at least \(1/2\).  ∎

This is not a small-information regime.  It is the zero-information endpoint
of the two-world change-of-measure argument.

## 4. The repair changes value in exactly one world

Let

\[
  V_\theta(\phi)
  =\sup_{\pi\text{ executable through }\phi}\mathbb E_\theta R.
\]

Then

\[
\begin{array}{c|cc}
 & \phi_0 & \phi_1\\ \hline
\theta_0 & 1/2 & 1/2\\
\theta_1 & 1/2 & 1-\eta.
\end{array}
\]

Indeed, the constant memory cannot correlate \(A\) with \(B\), whereas in
\(\theta_1\) the refined memory uses \(A=H\).  In the null world \(H\) carries
no target information and refinement gives no benefit.

Charge \(c\) for retaining the bit and define the declared architecture score

\[
  J_\theta(\phi)=V_\theta(\phi)-c\,\mathbf 1\{\phi=\phi_1\}.
\]

For

\[
  0<c<\frac12-\eta,
\]

the unique score-maximizing architecture is \(\phi_0\) in \(\theta_0\) and
\(\phi_1\) in \(\theta_1\).  Thus the architecture query is nonvacuous: a
rule that always adds memory is wrong under the declared resource objective,
while a rule that never adds it incurs operational regret
\(1/2-\eta-c>0\) in the conflict world.

The memory charge is essential to the “no unnecessary repair” claim.  Without
it, \(\phi_1\) weakly dominates \(\phi_0\) and architecture selection is not
identified in the null world.

## 5. Exposure turns the problem into Bernoulli testing

Temporarily deploy \(\phi_1\) and choose \(A=H\).  Then

\[
 R\sim
 \begin{cases}
   \operatorname{Bernoulli}(1/2),&\theta_0,\\
   \operatorname{Bernoulli}(1-\eta),&\theta_1.
 \end{cases}
\]

The operational exposure certificate is therefore a likelihood-ratio test
between two simple Bernoulli laws.  Let \(\tau\) be the number of diagnostic
episodes and let \(\widehat q\) select the architecture.  If both worldwise
errors are at most \(\delta<1/2\), sequential change of measure gives

\[
\begin{aligned}
 \mathbb E_{\theta_0}\tau\;
 \operatorname{kl}\!\left(\frac12,1-\eta\right)
 &\geq \operatorname{kl}(1-\delta,\delta),\\
 \mathbb E_{\theta_1}\tau\;
 \operatorname{kl}\!\left(1-\eta,\frac12\right)
 &\geq \operatorname{kl}(1-\delta,\delta).
\end{aligned}
\]

A fixed-sample threshold test at the midpoint of the two Bernoulli means has
both errors at most

\[
  \exp\!\left[-\frac{n(1/2-\eta)^2}{2}\right].
\]

Hence the necessary and sufficient confidence scale is

\[
  n=\Theta\!\left(
       \frac{\log(1/\delta)}{(1/2-\eta)^2}
     \right)
\]

as the two worlds approach one another.  The exact equal-prior fixed-sample
error is

\[
 p_n^\star
 =\frac12\sum_{k=0}^n
 \min\!\left\{
   {n\choose k}2^{-n},
   {n\choose k}(1-\eta)^k\eta^{n-k}
 \right\}
 =\frac{1-\operatorname{TV}(P_0^n,P_1^n)}2.
\]

Nothing in this rate is specific to the vocabulary of elimination geometry.
The split determines which experiment has positive KL; after that, the
certificate is a simple test.

## 6. General resettable-diagnostic reduction

The minimal example is not an accident.  Consider any finite, resettable
episodic architecture audit with

- a finite world set \(\Theta\);
- a declared architecture label \(q(\theta)\);
- a finite set \(\mathcal E\) of diagnostic programs, where a program may
  temporarily instantiate a candidate representation or memory and a policy;
  and
- a transcript law \(P_{\theta,e}\) for one execution of program \(e\).

An adaptive architecture selector chooses \(e_t\) from past transcripts,
stops, and reports \(q(\theta)\).  This is definitionally a controlled
sequential hypothesis test.  For any opposite-label world \(\lambda\), every
\(\delta\)-correct rule satisfies

\[
  \sum_{e\in\mathcal E}
  \mathbb E_\theta N_e(\tau)
  \operatorname{KL}(P_{\theta,e}\|P_{\lambda,e})
  \geq \operatorname{kl}(1-\delta,\delta).
\]

Normalizing expected experiment counts produces exactly the Chapter 20
characteristic information

\[
  \mathcal I^{q,*}(\theta)
  =\max_{w\in\Delta(\mathcal E)}
    \min_{\lambda:q(\lambda)\ne q(\theta)}
    \sum_e w_e
    \operatorname{KL}(P_{\theta,e}\|P_{\lambda,e}).
\]

Operational exposure changes the entries of this max--min problem by changing
the admissible experiment menu.  It does not create an additional statistical
term.

If experiment \(e\) costs \(c_e>0\), let

\[
 \mathcal I_{\rm cost}^{q,*}(\theta)
 =\max_{w\in\Delta(\mathcal E)}
   \min_{\lambda:q(\lambda)\ne q(\theta)}
   \sum_e w_e
   \frac{\operatorname{KL}(P_{\theta,e}\|P_{\lambda,e})}{c_e},
\]

where \(w\) is a distribution of expected cost shares.  The same argument
gives

\[
  \mathbb E_\theta[\text{diagnostic cost}]
  \geq
  \frac{\operatorname{kl}(1-\delta,\delta)}
       {\mathcal I_{\rm cost}^{q,*}(\theta)}.
\]

This is experiment design per unit cost, not a new “architecture exposure
tax.”

## 7. The exposure trichotomy

Every resettable finite version of the proposal falls into one of three
cases.

| Diagnostic contract | Mathematical consequence | Research consequence |
|---|---|---|
| only baseline-executable programs are legal, and opposite architecture labels remain transcript-equivalent | characteristic information is zero; no worldwise certificate exists | impossibility, not repair theory |
| temporary candidate memories or representations may be trialed | they are experiment actions with positive KL | active hypothesis testing / controlled sensing |
| trials are allowed but consume memory, interventions, safety budget, or time | divide information by declared experiment cost or augment the controlled state | costly experiment design / POMDP exploration |

The phrase “the conflict becomes visible only after structural repair” can
obscure this trichotomy.  One must state whether the repair is a reversible
diagnostic action, an irreversible terminal commitment, or an unavailable
counterfactual.  Without that typed distinction the claimed certificate can
borrow information from an architecture that the evidence contract forbids.

## 8. Antecedent attack

The route intersects several established theories at each step.

### Active sequential hypothesis testing

Chernoff's sequential design of experiments already treats adaptive selection
of sensing actions whose observation laws depend on the unknown hypothesis.
Naghshvar and Javidi develop active sequential hypothesis testing in the same
information-acquisition language.  The max--min KL lower bound used above is
also the mechanism already stated in Chapter 20 for a typed truth partition.

### State abstraction and history compression

State abstraction asks which distinctions can be merged without changing
prediction or control.  History-based reinforcement learning explicitly
optimizes a map from histories to states together with the induced decision
model.  Causal-state representations use the coarsest predictive partition of
action--observation history and connect it to bisimulation.  Therefore “two
histories should be split because their futures differ” is not a new state
object.

### Partial observability and revealing information

The difference between impossible learning under partial observability and
tractable learning after additional training-time revelation is already an
explicit subject of hindsight-observable and revealing POMDP theory.  More
complex nonresetting versions of the present seed enter that literature rather
than escaping it.

### Automata discrimination

When the environment is finite-state and deterministic or finitely
stochastic, selecting a future input sequence that distinguishes histories is
the territory of distinguishing, homing, and adaptive distinguishing
sequences and active automata learning.  A finite split witness is valuable as
an audit artifact, but not by itself a new learning-theoretic primitive.

### Primary sources checked for this attack

- H. Chernoff, “Sequential Design of Experiments,” *Annals of Mathematical
  Statistics* 30(3), 1959, DOI 10.1214/aoms/1177706205.
- M. Naghshvar and T. Javidi, “Active Sequential Hypothesis Testing,”
  *Annals of Statistics* 41(6), 2013, DOI 10.1214/13-AOS1144.
- M. Daswani, P. Sunehag, and M. Hutter, “Q-learning for history-based
  reinforcement learning,” PMLR 29, 2013,
  https://proceedings.mlr.press/v29/Daswani13.html.
- A. Zhang et al., “Learning Causal State Representations of Partially
  Observable Environments,” arXiv:1906.10437,
  https://arxiv.org/abs/1906.10437.
- J. Lee, A. Agarwal, C. Dann, and T. Zhang, “Learning in POMDPs is
  Sample-Efficient with Hindsight Observability,” PMLR 202, 2023,
  https://proceedings.mlr.press/v202/lee23a.html.
- F. Chen et al., “Lower Bounds for Learning in Revealing POMDPs,”
  arXiv:2302.01333, https://arxiv.org/abs/2302.01333.
- F. Vaandrager et al., “A New Approach for Active Automata Learning Based on
  Apartness,” arXiv:2107.05419, https://arxiv.org/abs/2107.05419.

This is a targeted antecedent screen, not an independent exhaustive priority
review.

## 9. Which desired clauses survive?

| Proposed flagship clause | Minimal experiment | Audit verdict |
|---|---:|---|
| baseline on-policy blindness | exact for every baseline policy | valid, classical zero-KL impossibility |
| different optimal architecture labels | exact after a declared memory charge | valid, but label definition rather than new theory |
| intervention exposes the collision | one temporary split makes reward Bernoulli with different means | valid, controlled sensing |
| certificate authorizes repair | likelihood-ratio test | valid, classical |
| exploration lower bound | matching-order KL/Hoeffding frontier | valid, already Chapter 20 machinery |
| no unnecessary repair | follows only because the memory charge breaks the null tie | valid under the stated objective |
| operational improvement | \(1/2-\eta-c\) in the conflict world | valid for the seed |
| new architecture-choice rate | absent | no-go |
| empirically validated architecture-repair theory | absent | no independent real repair case is supplied |

The seed is stronger than the present MNIST example as a logical toy model:
its blindness, certificate, repair decision, and value gain are all exact.
It is weaker as evidence about AI practice because the environment and repair
are constructed, finite, resettable, and known up to one bit of world state.

## 10. What would be required to reopen the route?

Merely adding more histories, a deeper recurrent network, a larger POMDP, or
an adaptive probe does not suffice.  Those changes enlarge a known controlled
experiment.  Reopening requires all of the following.

1. **A declared nonresettable contract.**  Specify which memory changes are
   temporary diagnostics, which are irreversible deployments, which affect
   the data-generating state, and what information each logger retains.
2. **A nonabsorbable lower-bound term.**  Construct a packing whose minimax
   price cannot be represented by KL over augmented experiment actions, a
   revealing-POMDP state, automata query complexity, or ordinary
   representation-class complexity.
3. **A matching algorithm.**  The upper bound must jointly decide what to
   expose, when to split memory, and how to control after the split, without
   assuming the candidate distinction in its evidence channel.
4. **A repair-specific comparator.**  Show that the structural split beats
   compute-, parameter-, and data-matched generic recurrence, mixture,
   retrieval, and exploration baselines.
5. **Independent closure.**  On fresh units, verify positive baseline
   obstruction, mechanism-specific exposure, disappearance or reduction of
   that obstruction after repair, and operational gain.

The decisive mathematical checkpoint is clause 2.  Until an explicit hard
family passes it, “operational exposure” should be treated as a design
variable inside established active learning or partial-observability theory.

## 11. Final go/no-go decision

**No-go.**  The current flagship-learning-theorem search should stop.

The three attacked routes now have exact reductions:

1. signed-cycle recovery reduces to noisy parity/synchronization;
2. finite partial-domain transport reduces to masked permutation/CSP plus
   sparse anomalous-coordinate testing; and
3. operationally exposed memory conflict reduces to zero-KL impossibility or
   controlled sequential testing, depending on the diagnostic menu.

This does not reduce the book to a failed theory proposal.  It clarifies the
defensible contribution: a typed, native-loss, audit-oriented synthesis that
forces deployment, evidence, recursion, operational visibility, repair, and
validation to be stated in one contract.  It does mean that the synthesis
must not be marketed as a new general approximation, representation, or
architecture-choice theory.

The next quality-improving step is not a fourth toy theorem.  It is an
independently executed architecture-repair case that closes the book's own
certificate--saturation--repair--validation chain, or a genuinely new hard
family proposed only after its closest controlled-sensing and POMDP
reductions have been ruled out in advance.

## 12. Reproducibility

The standard-library script under
`reproducibility/operational_memory_conflict/` checks the exact single-episode
baseline transcript identities, the two architecture value tables, the
exposed Bernoulli laws, the exact fixed-sample Bayes error, and the numerical
change-of-measure and Hoeffding bounds for a rational audit instance.  It is a
mathematical identity check, not empirical validation.
