# Feasibility attack: a flagship learning theorem

## Verdict

The current monograph does not contain a theorem that can be promoted into a
flagship learning result by strengthening constants or joining existing
lemmas.  The easiest complete theorem is a standard model-selection theorem.
The graph-holonomy, partial-domain, and operationally exposed memory routes
have now each failed their nonreduction gates.  The flagship-theorem search is
therefore closed in its current form; the monograph should retain its typed,
native-loss, audit-oriented synthesis positioning.

The theorem should not be inserted into the book until all five clauses below
are proved.  In particular, an upper oracle inequality alone is insufficient.

### 2026-08-12 go/no-go update

The proposed partial-domain continuation has now been attacked directly.  A
finite partial-bijection system can be totalized exactly into permutations on
enlarged fibers plus validity masks.  Its global-section problem is therefore
a finite masked constraint problem.  Moreover, the smallest experiment in
which one anomalous domain destroys the global section has a genuine
\(\Theta_q(\log |E|)\) architecture-selection threshold, but the matching
upper and lower bounds are exactly those of sparse anomalous-coordinate
detection or repetition-code membership testing.

Accordingly, **partiality alone fails the nonreduction clause**.  The complete
reduction, chi-square lower bound, upper test, and exact enumeration audit are
recorded in `PARTIAL_DOMAIN_FLAGSHIP_GO_NO_GO.md` and
`reproducibility/partial_domain_go_no_go/`.  No new formal result is promoted
into the monograph.  Reopening this route requires an operational observation
or intervention constraint whose statistical price is not preserved by the
masked-CSP encoding.

### 2026-08-13 final go/no-go update

The operational continuation has now also been attacked directly.  A
two-world memory-conflict experiment satisfies baseline blindness, opposite
resource-adjusted architecture labels, repair-specific operational gain, and
a matching-order exposure certificate.  But it yields an exact trichotomy:
baseline-only diagnostics have zero characteristic information; a temporary
memory split is a controlled-sensing action; and a priced split is costly
experiment design.  The lower bound is the Chapter 20 change-of-measure bound
with architecture choice as the truth partition.

Accordingly, **operational exposure alone also fails the nonreduction
clause**.  The complete construction, proofs, antecedent comparison, and
exact finite-law audit are recorded in
`OPERATIONALLY_EXPOSED_MEMORY_CONFLICT_GO_NO_GO.md` and
`reproducibility/operational_memory_conflict/`.  No new formal result is added
to the monograph's proof-coverage inventory.

## Candidate 0: shared versus task-specific Gaussian means

Let tasks (t=1,ldots,T) supply

\[
Y_{ti}=\theta_t+\varepsilon_{ti},\qquad
\varepsilon_{ti}\sim N(0,\sigma^2),\qquad i=1,\ldots,n.
\]

Under average squared prediction loss, the fully shared architecture has exact
population obstruction

\[
H(\theta)=\frac1T\sum_{t=1}^T(\theta_t-\bar\theta)^2.
\]

The shared estimator has risk

\[
H(\theta)+\frac{\sigma^2}{nT},
\]

whereas the task-specific repair has risk (sigma^2/n).  Thus the oracle
architecture changes at

\[
H(\theta)=\frac{\sigma^2}{n}\left(1-\frac1T\right).
\]

Moreover,

\[
\widehat H
=\frac1T\sum_{t=1}^T(\bar Y_t-\bar Y)^2
-\frac{\sigma^2(T-1)}{nT}
\]

is unbiased, and its scaled version is a noncentral chi-square statistic.
Exact confidence bounds therefore yield a certificate-guided shared/split
selector.  Sample splitting or direct Gaussian quadratic-form analysis gives
an oracle inequality with a remainder of the same order as the uncertainty in
(H), and two-point testing gives the corresponding local lower bound.

This candidate is mathematically feasible but **fails the originality gate**.
It is analysis of variance, pretesting/shrinkage, and selection between two
standard estimators written in the book's obstruction language.  Adding the
words certificate, saturation, or repair does not change that fact.

## Candidate 1: selecting a state representation or memory split

A finite POMDP candidate would estimate whether histories merged by a baseline
state representation require different continuation kernels or actions, split
the offending state, and prove policy-regret improvement.  This is closer to
an AI architecture decision, but the neighboring literature already contains:

- regret-optimal selection among state representations;
- approximate state-abstraction performance bounds;
- learning and exploiting unknown state-action equivalence;
- representation selection in low-rank MDPs.

Consequently, a finite-library selector or a bisimulation test followed by a
state split is not enough.  A viable theorem would need a new separation, such
as an on-policy impossibility for every baseline representation together with
an intervention-specific exploration certificate and a matching regret lower
bound.  That is a substantial new project and is not implied by the present
recursive-quotient results.

## Candidate 2: certificate-guided graph-atlas adaptation

This is the best current target because it can combine native loss,
architecture obstruction, statistical certification, and a structural repair
without reducing immediately to width selection.

### Statistical model

Let (G=(V,E)) index (T=|V|) related tasks.  At vertex (v), observations
come from a regular exponential family whose local oracle (a_v^\star) has
Legendre potential (Phi).  The native excess risk is the oriented Bregman
defect

\[
D_\Phi(a\|a_v^\star).
\]

A baseline architecture uses one globally coherent representative.  A repair
uses a graph atlas (\mathcal P), with local experts on its charts and legal
transition maps on overlaps.  Its population obstruction is

\[
O(\mathcal P)
=\inf_{A\in\operatorname{Atlas}(\mathcal P)}
\frac1T\sum_{v\in V}D_\Phi\{A(v)\|a_v^\star\}.
\]

Calibration data estimate local oracle signatures and transition maps.  The
candidate atlas family is therefore random, not fixed in advance.

### Flagship theorem target

Construct an algorithm returning an atlas (widehat{\mathcal P}), fitted
experts (widehat A), and a three-way certificate.  For a declared family of
graphs, exponential-family fibers, and admissible transition systems, prove
the following on one event of probability at least (1-\delta).

1. **Honest obstruction bracket.** Simultaneously for every admissible atlas,
   \[
   \underline O(\mathcal P)\le O(\mathcal P)\le\overline O(\mathcal P),
   \]
   even though the local signatures, transitions, and candidate atlas family
   are learned from data.

2. **Certificate-guided oracle inequality.** For native population risk,
   \[
   R(\widehat A)
   \le C\inf_{\mathcal P}
   \left[
      O(\mathcal P)
      +\frac{\operatorname{comp}(\mathcal P,G)+\log(1/\delta)}{N}
   \right]
   +r_N,
   \]
   where (operatorname{comp}) charges charts, experts, overlaps, and
   transition estimation, and (r_N) is lower order.

3. **No-unnecessary-repair property.** If the one-chart class is saturated
   with a positive margin against every larger structural alternative after
   complexity is charged, then the algorithm selects one chart with
   probability tending to one.

4. **Repair consistency.** If every one-chart deployment has obstruction at
   least (Delta_N), while a (K_\star)-chart atlas has zero or smaller
   obstruction, then the algorithm selects a repair and improves native risk
   whenever
   \[
   \Delta_N
   \gg
   \frac{\operatorname{comp}(K_\star,G)}{N}.
   \]

5. **Matching lower bound.** Over the same model class, every learner pays
   \[
   \inf_{\mathcal P}
   \left[
     O(\mathcal P)
     +c\frac{\operatorname{comp}(\mathcal P,G)}{N}
   \right]
   \]
   up to constants or logarithms.  The lower bound must include uncertainty
   in the transition/atlas structure, not merely estimation of chartwise
   parameters after the true atlas is revealed.

### Why the theorem might still collapse to classical model selection

If charts are simply a partition of (V), transitions are identities, and
experts are chartwise constants, then the theorem becomes penalized graph
segmentation or clustered multitask regression.  Standard oracle-inequality
machinery will prove the upper bound, but the result will not be a new learning
theory.

The nonclassical content must therefore come from at least one of the
following, and preferably two:

- output objects are defined only up to a nontrivial group action or partial
  transport;
- one-chart obstruction is caused by holonomy or a common-witness conflict,
  not ordinary roughness;
- the candidate atlas is generated from estimated transition domains, so its
  random complexity must be controlled jointly with native risk;
- the minimax lower bound shows an additional price for learning structural
  compatibility, beyond chartwise regression;
- a task-exposure theorem converts native improvement into a declared
  operational endpoint.

Without such content, Candidate 2 is also a repackaging of approximation and
model selection.

## Proof program and kill points

## A nonempty seed theorem: noisy cycle holonomy selects one chart or two

The following finite experiment shows that the target is not vacuous.  It is
not yet broad enough to be the monograph's flagship theorem, but it gives an
exact certificate--architecture phase transition that is not ordinary width
selection.

Let (G=C_T) be a cycle with edge transports (s_e\in\{-1,+1\}).  A global
one-chart representative is a vertex labeling (b_v\in\{-1,+1\}) satisfying

\[
b_v=s_e b_u
\]

on every oriented edge (e=(u,v)).  Such a representative exists if and only
if the holonomy

\[
h(s)=\prod_{e\in E}s_e
\]

equals (+1).  Give a labeling its native inconsistency defect

\[
D_s(b)=\frac1T\sum_{e=(u,v)}
\mathbf 1\{b_v\ne s_e b_u\}.
\]

Then the exact one-chart obstruction is

\[
O_1(s)=
\begin{cases}
0,&h(s)=+1,\\
1/T,&h(s)=-1.
\end{cases}
\]

A two-chart atlas may cut one edge and therefore has (O_2(s)=0) for every
(s).  Charge (1/(2T)) for opening the second chart.  The oracle architecture
is then one chart for even holonomy and two charts for odd holonomy.

For every edge observe (m) independent noisy transports

\[
X_{ej}=s_e Z_{ej},\qquad
\Pr(Z_{ej}=-1)=q<1/2.
\]

Let (P_+^{(m)}) and (P_-^{(m)}) denote the (m)-sample laws on one edge,
and set

\[
d_m=\operatorname{TV}\{P_+^{(m)},P_-^{(m)}\}.
\]

### Exact minimax architecture-selection theorem on the cycle

Under the uniform prior within each holonomy class, the total variation
distance between the complete experiments under even and odd holonomy is

\[
\operatorname{TV}(P_{\rm even},P_{\rm odd})=d_m^T.
\]

Consequently the minimax error probability for choosing the oracle chart
count is

\[
p_{T,m}^\star=\frac{1-d_m^T}{2},
\]

and, by the symmetry of the two parity classes, the minimax excess
resource-adjusted native objective is

\[
\frac{p_{T,m}^\star}{2T}.
\]

For fixed (q<1/2), if (C_q=-\log(2\sqrt{q(1-q)})) is the one-observation
Chernoff information, binomial testing bounds imply

\[
m=\Theta\!\left(\frac{\log T+\log(1/\delta)}{C_q}\right)
\]

observations per edge are necessary and sufficient for architecture-selection
error at most (delta), up to the usual lower-order logarithmic factor from
the binomial prefactor.

### Proof skeleton

1. Multiplying the edge consistency equations around the cycle proves that a
   global section exists exactly when (h(s)=+1).  Under odd holonomy every
   labeling violates an odd and hence at least one edge; propagating labels
   along a spanning path gives a labeling violating exactly one edge.

2. Write the even and odd mixtures as
   \[
   P_{\rm even/odd}
   =2^{-T}\left[
      \bigotimes_{e}(P_+^{(m)}+P_-^{(m)})
      \ \pm\
      \bigotimes_{e}(P_+^{(m)}-P_-^{(m)})
   \right].
   \]
   The (L^1) norm of a tensor product of finite signed measures is the
   product of their (L^1) norms.  This gives exactly
   (\operatorname{TV}(P_{\rm even},P_{\rm odd})=d_m^T).

3. Le Cam's two-hypothesis identity yields
   (p_{T,m}^\star=(1-d_m^T)/2).  The experiment is invariant under sign
   flips that preserve or exchange the parity classes, so the Bayes rule under
   the two uniform class priors is also minimax.  Either wrong architecture
   decision incurs excess objective (1/(2T)), giving the displayed value.

4. The optimal one-edge test is majority vote.  Its error is a binomial tail
   with exponent (C_q).  Since (d_m=1-2p_m^\star), constant global parity
   accuracy requires (T p_m^\star=O(1)), which is equivalent to
   (mC_q\gtrsim\log T).  Matching binomial upper and lower tail bounds close
   the rate.

### What this seed theorem does and does not establish

It establishes an exact statistical price for learning a global compatibility
class and using that certificate to change an output architecture.  The
obstruction is topological/holonomic, while the repair changes chart count;
neither operation is a wider predictor in the same one-chart class.

It remains too narrow for flagship status because it is also a noisy parity
test on one cycle.  The next theorem must extend the exact experiment to a
graph with growing cycle rank, partial transports or nontrivial fibers, and a
native prediction loss, while retaining a matching upper and lower frontier.
The key novelty question is whether that extension produces a structural
complexity term not reducible to known synchronization, signed-graph balance,
or graph segmentation rates.

## Growing cycle rank: exact cactus extension and closure of the \(\mathbb Z_2\) route

The first extension can be completed exactly, but it also shows why ordinary
signed holonomy is not a flagship learning theory.

Let \(G\) be a connected cactus graph with edge-disjoint simple cycles
\(C_1,\ldots,C_r\), of lengths \(L_1,\ldots,L_r\).  Put \(M=|E|\).  Every edge
has a sign \(s_e\in\{-1,+1\}\), and cycle \(k\) has syndrome

\[
h_k(s)=\prod_{e\in C_k}s_e.
\]

The one-chart native defect is the fraction of violated transition equations,

\[
D_s(b)=\frac1M\sum_{e=(u,v)}
\mathbf 1\{b_v\ne s_e b_u\}.
\]

Because cactus cycles are edge-disjoint, its exact obstruction is the signed
frustration index divided by \(M\):

\[
O_0(s)=\frac1M\sum_{k=1}^r\mathbf 1\{h_k(s)=-1\}.
\]

Indeed, every negative cycle requires a violated edge, and choosing one edge
from every negative cycle makes the remaining signing balanced.  Allow a seam
on a cycle at resource cost \(1/(2M)\); a seam removes that cycle's
consistency constraint.  The oracle seam vector is therefore

\[
a_k^\star(s)=\mathbf 1\{h_k(s)=-1\},\qquad k=1,\ldots,r.
\]

Observe \(m\) independent BSC measurements on every edge as in the one-cycle
experiment.  Let

\[
d_m=\operatorname{TV}\{P_+^{(m)},P_-^{(m)}\}.
\]

### Theorem: exact minimax seam learning on a cactus

For each syndrome vector \(h\in\{-1,+1\}^r\), put the uniform prior on edge
signings with that syndrome.  Under Hamming loss on the seam vector:

1. the conditional experiment factorizes over the cycles, apart from
   nuisance tree-edge mixtures that are common to every syndrome;
2. for cycle \(k\), the total variation distance between its positive- and
   negative-syndrome experiments is \(d_m^{L_k}\);
3. the coordinatewise likelihood-ratio rule is minimax, with coordinate error
   \[
   p_k^\star=\frac{1-d_m^{L_k}}2;
   \]
4. the exact minimax expected excess resource-adjusted native objective is
   \[
   \mathcal R_{G,m}^\star
   =\frac1{2M}\sum_{k=1}^r p_k^\star
   =\frac1{4M}\sum_{k=1}^r\{1-d_m^{L_k}\}.
   \]

Under the uniform prior on all syndrome vectors, the probability of recovering
the complete oracle architecture is

\[
\prod_{k=1}^r(1-p_k^\star),
\]

and group invariance makes the corresponding Bayes rule minimax for exact
architecture recovery.

### Rate consequence

Let \(p_m=(1-d_m)/2\) be the optimal error for one edge sign.  In the
high-information regime,

\[
p_k^\star
=\frac{1-(1-2p_m)^{L_k}}2
\asymp L_kp_m
\quad\text{when }L_kp_m=o(1).
\]

Thus exact seam recovery with error at most \(\delta\) is possible if and, up
to constants and binomial prefactors, only if

\[
p_m\sum_{k=1}^rL_k\lesssim\delta.
\]

For fixed BSC noise \(q<1/2\), this gives

\[
m=\Theta\!\left(
\frac{\log(\sum_kL_k)+\log(1/\delta)}{C_q}
\right),
\qquad
C_q=-\log\{2\sqrt{q(1-q)}\},
\]

up to the lower-order logarithm in the sharp binomial tail.

### Proof

Choose a spanning tree by deleting one edge from every cactus cycle.  Tree
propagation satisfies all retained equations.  Re-inserting a deleted edge
violates its equation exactly when the corresponding cycle syndrome is
negative, proving the obstruction formula.  Since the cycles are
edge-disjoint and the observations are independent, conditioning on the
syndrome vector factorizes the experiment over cycles and a common tree-edge
nuisance factor.  The signed-measure tensorization calculation from the
one-cycle theorem gives \(d_m^{L_k}\) for cycle \(k\).  Le Cam's identity gives
\(p_k^\star\).  Product-group invariance makes the coordinatewise Bayes rule
minimax, and summing the equal \(1/(2M)\) costs proves the exact risk formula.
The exact-recovery probability follows from independence.  Finally,
\(d_m=1-2p_m\), a first-order expansion controls \(p_k^\star\), and matching
upper and lower binomial-tail bounds yield the rate.

### Why this closes rather than validates the proposed flagship route

This theorem is correct and sharper than the informal single-cycle seed, but
its statistical content is a product of noisy parity tests.  For a general
connected graph, write edge signs over \(\mathbb F_2\).  Balanced signings form
the cut/coboundary space, the cycle holonomies form its syndrome, and the
minimum one-chart defect is the classical frustration index.  Noisy
architecture recovery is therefore decoding or testing a linear syndrome;
estimating vertex labels is \(\mathbb Z_2\) synchronization.  Existing signed
balance, coding, censored-block, and group-synchronization theories already
own these engines.

Accordingly:

- the one-cycle theorem may remain as a transparent example;
- the cactus theorem is a useful exact exercise or short proposition;
- neither should be advertised as the flagship learning theorem;
- extending only the graph family or cycle rank should stop here.

At this stage of the attack, the flagship project could have survived only if
the observation and architecture objects left this classical reduction.  Two
routes were therefore tested next:

1. **Partial-domain transport:** edge maps have data-dependent domains, so a
   branch can disappear and cycle composition is not a group syndrome.  The
   learner must jointly infer survival, compatibility, and the atlas repair.
2. **Operationally exposed memory conflict:** two histories are locally
   observationally indistinguishable on-policy but require different future
   actions under a declared intervention.  The certificate must authorize a
   memory split and the lower bound must charge the exploration needed to
   expose the conflict.

The first route was closer to the monograph's existing OAI machinery; the
second had stronger AI meaning but required a new sequential experiment.  The
subsequent audits close both: partial domains totalize to a masked constraint
problem, while the memory experiment reduces to controlled sequential
testing.  The stages below record the original kill criteria rather than a
current recommendation to proceed.

### Stage A: deterministic oracle geometry

Prove an exact identity or two-sided bound for (O(\mathcal P)) in terms of
chartwise Bregman variation plus transition inconsistency.  This stage fails
if the transition term depends on arbitrary representatives rather than the
intrinsic quotient object.

### Stage B: simultaneous statistical transport

Derive uniform concentration for all local signatures and all candidate edge
transports, then propagate it to every admissible atlas.  A naive union bound
over all graph partitions is likely exponential and may make the certificate
vacuous.  A publishable result needs a localized complexity, compression, or
dynamic-programming argument.

### Stage C: upper oracle inequality

Penalized empirical native risk should deliver the upper bound once Stages A
and B are available.  This is technically feasible but, by itself, classical.

### Stage D: matching lower bound

Construct a packing in which nearby local observation laws induce different
globally compatible atlases.  The hard instances must have comparable local
estimation difficulty but different holonomy or domain-survival structure.
If no such packing exists, the claimed structural price is not statistically
distinct from ordinary parameter estimation and the flagship project should
be stopped.

### Stage E: architecture decision

Use independent data to verify that the selected repair improves the declared
endpoint against compute- and parameter-matched generic alternatives.  This is
not part of the minimax proof but is required before the theorem is used to
claim practical architecture choice.

## Go/no-go decision

**No-go.  Close the present flagship learning-theorem program.**

The signed-cycle seed is noisy parity/synchronization.  Finite partial-domain
transport is masked permutation/CSP plus sparse detection.  Operationally
exposed memory conflict is zero-information impossibility or controlled
sequential testing, depending on the diagnostic menu.  None supplies a
learning-theoretic term that survives reduction to its closest classical
problem.

The monograph should therefore be positioned as a typed, native-loss,
audit-oriented synthesis.  Reopening an original-theory claim requires a new
hard family proposed together with a proof that its minimax price is not
ordinary representation selection, controlled sensing, POMDP exploration,
automata discrimination, or finite-library model selection.  Until then, the
scientifically useful next step is an independently closed
certificate--saturation--repair--validation case rather than another toy
upper bound.

## Closest antecedents that must be beaten

- Maillard, Nguyen, Ortner, and Ryabko, *Optimal Regret Bounds for Selecting
  the State Representation in Reinforcement Learning* (ICML 2013).
- Abel, Hershkowitz, and Littman, *Near Optimal Behavior via Approximate State
  Abstraction* (ICML 2016).
- Asadi, Talebi, Bourel, and Maillard, *Model-Based Reinforcement Learning
  Exploiting State-Action Equivalence* (ACML 2019).
- Zhang et al., *Provably Efficient Representation Selection in Low-rank Markov
  Decision Processes* (UAI 2023).
- Agarwal, Duchi, Bartlett, and Levrard, *Oracle Inequalities for
  Computationally Budgeted Model Selection* (COLT 2011).
- Dalalyan and Salmon, *Optimal Aggregation of Affine Estimators* (COLT 2011).

These works do not automatically subsume Candidate 2, but they rule out
novelty claims based only on representation selection, a complexity-penalized
oracle inequality, or a finite-library architecture comparison.
