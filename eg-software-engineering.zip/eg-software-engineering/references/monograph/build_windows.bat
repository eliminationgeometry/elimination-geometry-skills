@echo off
setlocal
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
where bibtex >nul 2>nul
if not errorlevel 1 goto run_bibtex
where bibtex8 >nul 2>nul
if not errorlevel 1 goto run_bibtex8
echo Error: neither bibtex8 nor bibtex was found; bibliography generation is required. 1>&2
exit /b 1

:run_bibtex8
bibtex8 main || exit /b 1
goto bibliography_done

:run_bibtex
bibtex main || exit /b 1

:bibliography_done
where makeindex >nul 2>nul
if errorlevel 1 (
  echo Error: makeindex was not found; index generation is required. 1>&2
  exit /b 1
)
makeindex main.idx || exit /b 1
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
xelatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
copy /Y main.pdf Elimination_Geometry_Monograph_v1_9.pdf >nul || exit /b 1
endlocal
