#!/usr/bin/env bash
set -euo pipefail
xelatex -interaction=nonstopmode -halt-on-error main.tex
if command -v bibtex >/dev/null 2>&1; then
  bibtex main
elif command -v bibtex8 >/dev/null 2>&1; then
  bibtex8 main
else
  echo "Error: neither bibtex8 nor bibtex was found; bibliography generation is required." >&2
  exit 1
fi
makeindex main.idx
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
cp -f main.pdf Elimination_Geometry_Monograph_v1_9.pdf
