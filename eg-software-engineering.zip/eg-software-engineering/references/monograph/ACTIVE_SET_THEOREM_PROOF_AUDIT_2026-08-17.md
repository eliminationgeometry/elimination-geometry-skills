# Active-set theorem and proof audit

Audit date: 2026-08-17  
Scope: Chapter 19, Theorems 19.10--19.11 and Corollary 19.12; Chapter 24
diabetes theorem alignment.

## Final verdict

After the corrections recorded below, the displayed active-set cell theorem,
one-pass lower bound, native-loss conversion, proximal contraction, upper
envelope, and sufficient-depth corollary are internally valid under their
stated assumptions. The proof is complete for the declared class
`f(x)=[Wx+b]_+`, a full-column-rank dictionary, and symmetric balls in one
declared perturbation subspace.

This verdict is about correctness, not priority. The family remains class `O`.
It is also not a theorem for overcomplete dictionaries, arbitrary deep ReLU
networks, nonsymmetric feasible sets, or the support of the patient
distribution.

## Problems found and repaired

| Issue | Consequence before repair | Correction |
|---|---|---|
| Corollary initializer was arbitrary | A rich initializer could satisfy the upper bound without proving a one-pass-to-recurrent separation | Corollary 19.12 now requires `f` to belong to the same one-pass class excluded by Theorem 19.10 |
| `t_eta` was undefined when `q=0` | The theorem discussed the boundary verbally, but the corollary invoked an undefined symbol | Equation (19.19) is now a three-branch definition covering depth zero, `q=0`, and `0<q<1` |
| Compactness was used as if it bounded an arbitrary initializer | `E_0` need not be finite for an arbitrary function on a compact set | Theorem 19.11 now assumes a bounded initializer; compactness and continuity only supply boundedness of the oracle and KKT slack |
| FISTA iterates were treated as exact KKT centers | A small numerical residual could invalidate a strict-cell radius as a mathematical certificate | FISTA now proposes supports only; active normal equations are resolved and all KKT signs are checked before any radius is computed |
| Diabetes used full ambient balls | The balls continuously varied the binary sex coordinate and were not contained in the declared scaled input box | Theorem 19.10 now permits a declared perturbation subspace; the audit freezes sex, restricts the other nine coordinates to the training-minmax box, and requires equal frozen values at the two centers |

## Proof check

1. **Strict-cell formula.** Active stationarity gives
   `z_S=H_S^{-1}(D_S^T x-lambda 1)`. For `u` in the declared subspace,
   Cauchy--Schwarz uses the projected rows `q_j^T Pi_V`. The same projection
   applies to every inactive-slack derivative. The factor `1/2` leaves both
   margins strictly positive on the closed restricted ball.
2. **One-pass lower bound.** An error below both positivity margins forces the
   selected ReLU output to remain in its affine branch on both balls.
   Evaluating at `x_i +/- r_i v` for unit `v` in the perturbation subspace
   bounds the projected encoder row within `e/r_i` of each projected oracle
   row. The triangle inequality gives the harmonic-radius conflict floor with
   no missing factor of two.
3. **Native-loss floor.** `D^T D` is positive definite under full column rank.
   First-order optimality on the nonnegative orthant removes the linear term
   in the strong-convexity lower bound, yielding `kappa ||e||^2/2`.
4. **Repair contraction.** The orthant projection is nonexpansive and the
   eigenvalues of `I-H/L` lie in `[0,1-kappa/L]`. Iteration therefore gives
   the stated global code contraction.
5. **Native upper envelope.** Exact quadratic expansion gives
   `J(z*+e)-J(z*)=e^T H e/2+s^T e`. Inactive KKT slack and nonnegative repaired
   coordinates give the correct sign. Cauchy--Schwarz and the spectral upper
   bound yield the displayed envelope.
6. **Depth inversion.** The stable positive solution of
   `B_K d+L d^2/2=eta` is used. The three branches of Equation (19.19) are
   exactly the integer solutions of `q^t E_0 <= d_eta`.
7. **Sharpness.** Only the contraction coefficient is shown sharp. At an
   interior KKT point, a small error in a minimum-eigenvalue direction avoids
   projection and contracts by exactly `q`. No necessity claim is made for the
   full depth formula.

## Recomputed scientific certificate

- all 89 numerical centers recertify as exact KKT solutions;
- maximum FISTA-to-exact code correction: `9.24e-16`;
- maximum exact active-stationarity residual: `6.49e-16`;
- 77 centers have positive restricted radii inside the declared box;
- selected confirmatory rows: `17/68` (dataset rows `61/172`), with equal
  frozen sex value;
- restricted Jacobian conflict: `0.3894538108`;
- code-error floor: `0.0119312825`;
- one-pass native-loss floor: `3.5584910e-05`;
- tolerance at 90% of the floor: `3.2026419e-05`;
- conservative sufficient proximal depth: `24`.

The frozen R1 two-step, 288-MAC result is unchanged. It answers an average
endpoint and equal-compute contract. The 24-step value answers a later uniform
restricted-ball contract and is not compute-matched to R1.

## Remaining nonbugs and limitations

- Full column rank excludes the usual overcomplete sparse-coding regime.
- The lower bound applies only to one thresholded-affine layer, not arbitrary
  shallow or deep ReLU networks.
- The restricted box is a declared input grammar. No density or support result
  proves that every point in either ball is an attainable patient.
- The pair and tolerance were selected post-confirmation.
- The depth is sufficient for the fixed proximal mechanism, not necessary or
  minimax over all repair architectures.
- Independent proof review, priority review, and prospective external
  validation remain outstanding.
