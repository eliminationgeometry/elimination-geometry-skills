#!/usr/bin/env python3
"""Refresh the content manifest for the release tree."""

from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SHA256SUMS.txt"
EXCLUDED_PARTS = {"__pycache__", "__MACOSX", "tmp"}
EXCLUDED_NAMES = {"SHA256SUMS.txt", ".DS_Store"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    paths = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file()
        and path.name not in EXCLUDED_NAMES
        and not EXCLUDED_PARTS.intersection(path.relative_to(ROOT).parts)
    )
    MANIFEST.write_text(
        "".join(
            f"{sha256(path)}  ./{path.relative_to(ROOT).as_posix()}\n"
            for path in paths
        ),
        encoding="utf-8",
    )
    print(f"Release manifest written for {len(paths)} files.")


if __name__ == "__main__":
    main()
