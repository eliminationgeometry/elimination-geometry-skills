# Monograph Architecture

## One book-level question

When local optima are available, can one shared deployment contract realize them simultaneously, what native population risk is forced if it cannot, can finite data certify the distinction, and which minimal structural change is justified by that diagnosis?

## The certification ladder

```text
native elimination
  -> native defect
  -> integrability / intrinsic-lift gate
  -> architecture obstruction
  -> resource / operational gate
  -> operational visibility
  -> finite-data certificate
  -> obstruction-aware repair
  -> independent validation
```

## Why the book is not ordered by source manuscript

The source manuscripts were developed around individual theorem interfaces.
Version 1.9 preserves the book's logical certification order: native defect first,
then integrability and lift admissibility, then architecture obstruction,
resources and semantics, statistical certification, and intervention.

## The eight parts

1. **The Structural Realizability Problem**: reuse, local solvability, global realizability, finite-sample certifiability, and the four-component risk decomposition.
2. **Native Defects and Elimination Calculus**: exact defects, P/G/X/V/C, exactification, and CRPS.
3. **Validity of Defects and Representations**: integrability and intrinsic-lift admissibility.
4. **Structural Obstructions under Shared Deployment**: regular transfer, coordination, singular taxes, and repairs.
5. **Resources, Operational Semantics, and Composition**: rate--distortion, contextual visibility, and base change.
6. **Statistical Certification**: honest frontiers, unresolvedness, resolution, and evidence carriers.
7. **Obstruction-Aware Learning and Structural Repair**: common actions, OALI, concrete OAI transports, cycles, and laboratories.
8. **Stress Tests, Boundaries, and Research Program**: quantum rigidity, failure modes, and agenda.

The eight numbered main parts are followed by an unnumbered technical appendix division.

## Chapter-level proof architecture

A theorem-bearing chapter now has the following rhythm:

```text
problem and local notation
  -> assumption guide
  -> formal theorem
  -> interpretation and claim boundary
  -> proof roadmap
  -> consequences, examples, and exercises
  -> appendix to that chapter with the complete proof
```

This organization keeps the theorem embedded in the scientific argument while preventing long technical proofs from interrupting the main exposition.  The global appendices contain common tools only.

Synthesis and prospective chapters use the same principle at a larger scale.
Chapters 13, 17, 22, 26, and 27 now contain only four or five numbered
argument blocks: each block develops a mechanism, carries it through its
boundary or decision consequence, and hands the conclusion to the next
block.  Lists remain only where they function as taxonomies, protocols, or
falsification criteria.

## Four recurring laboratories

- oracle-preserving coarse-graining;
- graph distributional prediction under CRPS;
- sequential decisions with shared policy or memory;
- one-pass prediction with budgeted local refinement.

Chapter 4 presents these as pure mechanism directions: information survival,
semantic validity, conditional coordination, and computation-indexed
deployment.  Chapter 24 selectively recombines them in the MNIST,
posterior-family Monte Carlo, cytometry, and sequential application
interfaces.  This two-level design prevents the theory from collapsing into
only information compression, only shape-constrained smoothing, or only
dynamic programming or amortized inference.

## Controlled glossary

Appendix F supplies a 65-term controlled glossary.  Each entry gives the
book-level working meaning, marks a nearby interpretation that should not be
silently substituted, and points to the chapter where the term enters the
main argument.  The glossary explains concepts; the front-matter notation
table decodes symbols, while the thematic index locates detailed uses.

## Thematic index

The six-page thematic index is organized by concept families rather than by
source manuscript.  Its main hierarchies include defect, elimination,
obstruction, carrier, certificate, repair, resource constraints, operational
visibility, topology, and transport.  Entries point to definitions, principal
results, and application gateways; common aliases use cross-references rather
than duplicate page lists.  Page references are internally linked in the PDF.
