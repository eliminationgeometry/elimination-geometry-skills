# Version 1.9 release notes

## Cross-domain typed applications

- Added four problem-class examples without adding formal-result or novelty
  claims: distribution-free prediction under conditional/shift contracts,
  treatment policies under observational overlap, routed experts and external
  memory under bounded observability, and local generative vector fields under
  density versus transport contracts.
- Each example declares its information carrier, native endpoint, obstruction,
  mechanism-matched repair, and non-implication boundary.  Named methods appear
  only as representatives of the broader problem class.
- The examples explicitly prevent four overclaims: marginal coverage is not
  conditional coverage; effect estimation is not causal identification;
  nonconservative fields are not automatically invalid samplers; and adding
  experts or retrieval is not automatically a same-information optimizer
  repair.

## Theory

- Added the Chapter 19 active-set conflict/saturation/repair-depth family for
  full-column-rank nonnegative sparse inference.
- The first theorem computes strict-KKT cell radii and a two-neighborhood
  Jacobian conflict modulus, then converts it into code-error and native-loss
  floors for every one-pass thresholded-affine encoder.
- The second theorem gives global contraction and a compact-set native-loss
  upper envelope for the declared proximal repair, plus an explicit
  sufficient crossing depth. The contraction factor, not the full depth
  formula, is shown sharp for the fixed mechanism.
- Added the complete chapter-appendix proof and expanded the proof/provenance
  inventory from 36 to 37 rows.
- The final proof audit restricts the initializer in the architecture-change
  corollary to the one-pass class actually ruled out by the lower bound,
  assumes boundedness where the compact-set depth formula needs finite
  initialization error, and defines the sufficient depth explicitly in the
  zero-contraction boundary case.

## Priority boundary

- Added `ACTIVE_SET_DEPTH_SEPARATION_PRIORITY_AUDIT_2026-08-17.md`.
- O’Neill, Gumran, and Klindt (ICML 2025) is recorded as the strongest
  collision: their work already proves a global one-layer sparse-autoencoder
  amortisation gap and studies inference-time optimization.
- LISTA, unfolded-ISTA convergence, proximal optimization, local sparse
  Lipschitz certificates, and parametric-QP active-set sensitivity are also
  explicit antecedents.
- The exact quantitative combination was not located, but independent
  priority is not established. Appendix G therefore codes the family `O`; no
  independent originality claim is made.

## Scientific-case alignment

- Added a deterministic, fit-free theorem-alignment verifier to the sealed
  diabetes package.
- The proof audit replaces unrestricted ambient balls by declared-subspace
  balls.  This freezes categorical coordinates and permits every neighborhood
  to be clipped to a declared feasible input domain.
- The diabetes alignment freezes the binary sex coordinate, restricts the
  other nine features to the training-minmax box, and requires the same sex
  value at both centers.  It selects confirmatory rows 17/68, shared atom 6,
  code-error floor `0.0119312825`, one-pass native-loss floor
  `3.5584910e-05`, and contraction factor `0.7378823041`.
- At a tolerance equal to 90% of that floor, the analytic restricted-ball
  envelope gives 24 proximal steps as a sufficient repair depth.
- FISTA now proposes supports only.  Every theorem-alignment center is rebuilt
  from its active normal equations and must pass exact KKT sign checks before
  a radius is computed.  All 89 centers recertify, with maximum code
  refinement `9.24e-16`.  The subspace/domain correction deliberately changes
  the selected pair and moves the conservative depth from 23 to 24.
- This audit is post-confirmation. The frozen R1 two-step 288-MAC decision
  remains a separate patient-average result; it is not relabeled as a
  prospective test of the new theorem and the 24-step guarantee is not
  relabeled compute-matched R1 evidence.

## Positioning

Version 1.9 contains a central, architecture-specific candidate theorem
family and one closed frozen scientific benchmark case, but it still lacks
independent priority confirmation and a new prospectively frozen or
external-person validation whose gates directly use the theorem’s modulus,
uniform tolerance, and charged repair depth. It should not yet be marketed as
an independently established original-theory monograph.
