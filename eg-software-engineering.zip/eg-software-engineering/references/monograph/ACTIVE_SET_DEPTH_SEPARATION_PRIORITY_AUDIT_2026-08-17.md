# Active-set conflict and repair-depth priority audit

Audit date: 2026-08-17  
Result audited: Chapter 19, “Certified active-set conflict modulus and
one-pass saturation” plus “Repair contraction, native-loss upper envelope,
and crossing budget.”

## Verdict

Status: **O — unresolved priority-audit candidate**.

The exact theorem package was not located verbatim in the sources inspected:
a computable strict-KKT two-neighborhood radius, a shared-coordinate Jacobian
conflict modulus, a quantitative code and native-loss floor for every
one-pass thresholded-affine encoder, and an explicit sufficient proximal
depth that crosses a smaller native-loss tolerance on the same compact set.

That negative search result is not proof of originality. Each major ingredient
has strong antecedents, and a 2025 result is especially close to the central
architecture claim. The manuscript therefore does **not** advertise this
family as independently priority-confirmed original theory.

## Closest antecedents and exact boundary

| Component used in Chapter 19 | Closest source located | What is already established | Narrow residual in the book |
|---|---|---|---|
| One-layer linear–nonlinear sparse encoder cannot solve all otherwise recoverable sparse instances | [O’Neill, Gumran & Klindt, ICML 2025](https://proceedings.mlr.press/v267/o-neill25a.html), Theorem 3.1/A.1 | A global, exact-recovery amortisation gap via a rank contradiction; iterative inference and deeper encoders are identified as escapes and tested empirically | Finite-radius local Jacobian incompatibility; quantitative approximation and native-loss floor rather than only nonzero exact-recovery gap |
| Learned fixed-depth approximation and iterative/unrolled repair | [Gregor & LeCun, ICML 2010](https://icml.cc/Conferences/2010/abstracts.html) | LISTA-style feed-forward approximation to sparse coding and iterative initialization | No conflict certificate or worst-case lower bound for the one-pass class |
| Convergence of unfolded ISTA and support-selection structure | [Chen et al., NeurIPS 2018](https://proceedings.neurips.cc/paper/2018/hash/cf8c9be2a4508a24ae92c9d3d379131d-Abstract.html) | Necessary weight coupling and linear convergence under sparse-recovery assumptions | The book’s repair upper bound is for a fixed nonnegative proximal mechanism and is paired with its own lower-bound certificate |
| Proximal/thresholding optimization rates | [Beck & Teboulle, SIAM J. Imaging Sciences 2009](https://epubs.siam.org/doi/10.1137/080716542) | ISTA/FISTA analysis for composite inverse problems | The contraction calculation in the book is a direct quadratic specialization, not a new proximal theorem |
| Local sparsity-preserving radii and reduced piecewise-linear maps | [Muthukumar & Sulam, SIAM J. Mathematics of Data Science 2023](https://epubs.siam.org/doi/10.1137/22M1478835) | Sparse local Lipschitz radii and data-dependent certificates for Lasso variants and ReLU networks | The book uses two oracle cells whose required Jacobian rows conflict with one shared shallow row |
| Active-set affine sensitivity for parametric convex quadratic programs | [Kheirfam, Matematički Vesnik 2010](https://euclid.matf.bg.ac.rs/index.php/vesnik/article/view/mv10201) and the broader parametric-QP literature | Invariance regions and affine optimizer dependence within an active set | The radius formula here is an elementary sufficient ball in a declared perturbation subspace, specialized to nonnegative sparse inference |

## The strongest collision

O’Neill–Gumran–Klindt is not a peripheral citation. Their theorem already
establishes the high-level statement that a one-layer linear–nonlinear sparse
autoencoder has an inherent amortisation gap in a solvable sparse-recovery
regime, and their experiments already compare richer or inference-time
optimization mechanisms. Consequently, none of the following can be claimed
as the book’s invention:

- “a shallow sparse encoder can be insufficient”;
- “iterative inference can repair an amortisation gap”;
- “greater inference-time computation can change the preferred encoder.”

The only plausible theorem-level increment is the narrower certificate:
given two strict KKT neighborhoods in a *fixed fitted problem*, compute a
positive number that lower-bounds every one-pass thresholded-affine encoder’s
uniform native loss, then compute a sufficient number of declared proximal
steps that crosses any smaller tolerance. Independent experts must still
check whether this exact quantitative combination appears in approximation,
parametric-optimization, sparse-coding, or neural-network lower-bound work.

## Proof-dependency audit

1. **Strict-cell radius.** Direct KKT sensitivity. The factor one half makes
   the active coefficients and inactive slacks strictly positive on a closed
   ball in any declared perturbation subspace. Zero denominator is treated as
   an infinite radius contribution. The unrestricted Euclidean ball is the
   full-subspace special case.
2. **Shared-row lower bound.** If uniform error is below both positivity
   margins, the ReLU coordinate is affine on both balls. Symmetric
   perturbations force its row within `error/radius` of each oracle row; the
   triangle inequality yields the harmonic-radius conflict floor.
3. **Native-loss floor.** Direct strong convexity with
   `kappa = lambda_min(D^T D)`.
4. **Repair upper bound.** Nonexpansiveness of orthant projection and the
   spectral norm of `I - H/L`; the native envelope follows by exact quadratic
   expansion around the KKT point.
5. **Depth formula.** Algebraic inversion of the upper envelope. It is a
   sufficient budget, not a minimax-optimal depth theorem for all repairs.
   The final statement uses a three-branch definition, so depth zero,
   zero contraction, and `0<q<1` are all covered without an undefined symbol.
6. **Sharpness.** Only the contraction coefficient of this fixed proximal
   mechanism is shown sharp on an interior minimum-eigenvalue mode. The full
   crossing-depth formula is not claimed necessary or globally sharp.
7. **Architecture corollary.** Its initializer is required to belong to the
   same one-pass class excluded by the lower bound. The general repair theorem
   may start from any bounded nonnegative initializer, but that fact alone
   cannot establish a one-pass-to-recurrent architecture separation.

## Empirical status

The sealed diabetes R1 experiment remains a prospectively frozen,
fit-free-accepted scientific benchmark case for a **two-step average-endpoint
decision**. The new theorem-alignment audit is post-confirmation. It freezes
the binary coordinate, clips the other nine features to the training-minmax
box, and computes a positive restricted-neighborhood floor with a conservative
24-step sufficient uniform crossing budget. It was not an R1 gate and is not an
external-person replication. FISTA only proposes supports in the audit; the
reported centers are reconstructed by the active normal equations and checked
against the exact KKT signs. All 89 centers recertify. Seventy-seven remain
strict interior centers for the declared box geometry, and rows 17/68 maximize
the resulting floor. The restricted balls are an input-grammar contract, not a
claim that every point belongs to the patient-population support. The book
keeps these claims separate.

## Release rule

Promotion from `O` to an originality claim requires both:

1. an independent, field-spanning priority review that specifically searches
   quantitative shallow-network approximation lower bounds for parametric QP
   solution maps, not only sparse-autoencoder papers; and
2. an independent proof audit checking closed-ball strictness, the vector
   native-loss conversion, the compact-set slack envelope, and every boundary
   case of the depth formula.

Until then the family may serve as a central, useful theorem of the book, but
not as an independently established original theorem.
