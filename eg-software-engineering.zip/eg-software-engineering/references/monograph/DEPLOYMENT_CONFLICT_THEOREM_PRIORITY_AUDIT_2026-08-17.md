# Deployment-conflict theorem family: reduction and priority audit

Date: 2026-08-17

## Candidate claim

Chapter 19 now states a theorem family with three linked claims:

1. exact zero-error deployability is equivalent to nonempty feasible-action
   intersections on almost every observational-overlap fibre;
2. a two-world, two-architecture conflict has finite-sample maximum native
   regret at least
   \(\Delta_0\Delta_1(1-\mathrm{TV})/(\Delta_0+\Delta_1)\);
3. optimizer, information, and architecture repairs change different terms of
   this obstruction.

## Reduction attack

- The exact statement is a measurable common-witness condition. Under the
  manuscript's finite-world, compact-action, lower-semicontinuous-loss
  assumptions, necessity follows by taking a finite union of null sets and
  sufficiency by selecting one action for each of finitely many support
  patterns.
- The quantitative statement reduces exactly to the Le Cam two-point testing
  identity \(e_0+e_1\ge 1-\mathrm{TV}(P_0,P_1)\), followed by minimizing
  \(\max(\Delta_0e_0,\Delta_1e_1)\).
- The information-repair interpretation is adjacent to Blackwell comparison
  of experiments. The architecture-repair interpretation changes the action
  space or feasible-set intersection, not the testing inequality.

No residual mathematical mechanism survived this reduction as an independent
priority-original theorem. The correct provenance tag is **B** (book-level
synthesis/interface), not **O**.

## Why it is nevertheless a main theorem

The family is indispensable to this manuscript's argument because it supplies
the shared decision object that the sparse-estimation quantifier example and
the OALI experiments must both instantiate. It prevents three invalid
inferences:

- pointwise oracle behaviour does not imply a uniformly deployable selector;
- a better optimizer does not alter an information lower bound;
- a benchmark gain does not demonstrate architecture repair unless the
  experiment freezes the information, action class, native loss, compute
  contract, and independent endpoint.

This is an organizational indispensability claim, not a priority claim.

## Scientific falsification contract

An empirical case may be said to instantiate the theorem family only if:

1. the baseline architecture, repaired architecture, observation carrier,
   native loss, and compute budget are frozen before confirmation scoring;
2. a class-level incompatibility certificate is distinct from an operational
   gap of one fitted rule;
3. the targeted repair beats a generic control with the same information and
   compute;
4. a mechanism-breaking negative control behaves as preregistered;
5. native-loss improvement survives on untouched independent units without
   an unacceptable scientific-endpoint cost;
6. an acceptor independent of model fitting verifies hashes and gates without
   retraining.

Passing this contract supports a bounded architecture-choice claim. It does
not turn the underlying Le Cam/Blackwell ingredients into a new theorem and
does not establish universal superiority of iterative or unrolled methods.
