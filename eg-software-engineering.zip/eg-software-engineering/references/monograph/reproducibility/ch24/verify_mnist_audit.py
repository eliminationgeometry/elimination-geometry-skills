#!/usr/bin/env python3
"""Verify the compact MNIST R2 evidence shipped with Chapter 24.

The normal book check recomputes every printed aggregate from the five
archived seed summaries, verifies the prospectively frozen source snapshot,
and checks the generated TeX macros byte for byte.  It does not silently
retrain the VAE; full retraining is an explicit companion operation.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results" / "mnist_amortization"
VENDOR = HERE / "vendor" / "mnist_amortization_r2"
GENERATED_TEX = RESULTS / "generated_results.tex"
SEEDS = (101, 202, 303, 404, 505)
ONE_SIDED_T_95_DF4 = 2.13184678133629
ATOL = 5e-12


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--write-tex",
        action="store_true",
        help="replace generated_results.tex after all numerical checks pass",
    )
    return parser.parse_args()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def require_close(actual: float, expected: float, label: str) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=ATOL):
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")


def one_sided_bounds(values: list[float]) -> tuple[float, float, float, float]:
    mean = statistics.mean(values)
    sd = statistics.stdev(values)
    radius = ONE_SIDED_T_95_DF4 * sd / math.sqrt(len(values))
    return mean, sd, mean - radius, mean + radius


def verify_frozen_snapshot(config: dict) -> int:
    manifest = VENDOR / "protocol" / "FROZEN_MNIST_R2.sha256"
    data_hashes = {
        "data/train-images-idx3-ubyte.gz": config["data"]["train_sha256"],
        "data/t10k-images-idx3-ubyte.gz": config["data"]["test_sha256"],
    }
    verified_sources = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split(maxsplit=1)
        path = VENDOR / relative
        if path.exists():
            require(sha256(path) == expected, f"frozen hash mismatch: {relative}")
            verified_sources += 1
        else:
            require(relative in data_hashes, f"missing frozen artifact: {relative}")
            require(
                data_hashes[relative] == expected,
                f"declared data hash mismatch: {relative}",
            )
    return verified_sources


def read_candidate_means() -> dict[str, float]:
    with (RESULTS / "candidate_summary.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        return {
            row["candidate"]: float(row["mean_test_gap"])
            for row in csv.DictReader(handle)
        }


def render_tex(
    aggregate: dict,
    candidates: dict[str, float],
    seed_summaries: list[dict],
) -> str:
    step_ratios = [
        statistics.mean(
            summary["uniform_mean_gap"][str(step)] / summary["selected_mean_gap"]
            for summary in seed_summaries
        )
        for step in (1, 4, 8, 16)
    ]
    positive = sum(
        round(summary["curvature_positive_fraction"] * summary["n_audit"])
        for summary in seed_summaries
    )
    covered = sum(
        round(
            summary["curvature_positive_fraction"]
            * summary["n_audit"]
            * summary["curvature_bracket_coverage"]
        )
        for summary in seed_summaries
    )
    lines = [
        "% Generated from aggregate_summary.json by verify_mnist_audit.py.",
        "% Do not edit numerical values by hand.",
        f"\\providecommand{{\\MNISTSeeds}}{{{aggregate['n_model_seeds']}}}",
        f"\\providecommand{{\\MNISTTestImages}}{{{aggregate['n_test_images_per_seed']}}}",
        "\\providecommand{\\MNISTDataGaps}{"
        + " / ".join(
            f"{candidates[name]:.3f}"
            for name in (
                "w256_n10000_e24",
                "w256_n30000_e24",
                "w256_n55000_e24",
            )
        )
        + "}",
        "\\providecommand{\\MNISTEpochGaps}{"
        + " / ".join(
            f"{candidates[name]:.3f}"
            for name in (
                "w256_n55000_e4",
                "w256_n55000_e12",
                "w256_n55000_e24",
            )
        )
        + "}",
        "\\providecommand{\\MNISTWidthGaps}{"
        + " / ".join(
            f"{candidates[name]:.3f}"
            for name in (
                "w64_n55000_e24",
                "w256_n55000_e24",
                "w512_n55000_e24",
            )
        )
        + "}",
        f"\\providecommand{{\\MNISTGapMean}}{{{aggregate['selected_gap_seed_mean']:.3f}}}",
        f"\\providecommand{{\\MNISTGapSD}}{{{aggregate['selected_gap_seed_sd']:.3f}}}",
        f"\\providecommand{{\\MNISTGapLower}}{{{aggregate['selected_gap_one_sided_lower_95']:.3f}}}",
        f"\\providecommand{{\\MNISTRefineMean}}{{{aggregate['uniform_8step_ratio_seed_mean']:.3f}}}",
        f"\\providecommand{{\\MNISTRefineSD}}{{{aggregate['uniform_8step_ratio_seed_sd']:.3f}}}",
        f"\\providecommand{{\\MNISTRefineUpper}}{{{aggregate['uniform_8step_ratio_one_sided_upper_95']:.3f}}}",
        f"\\providecommand{{\\MNISTSeedPasses}}{{{aggregate['uniform_8step_seed_passes']}}}",
        "\\providecommand{\\MNISTRefinementCurve}{"
        + " / ".join(f"{value:.3f}" for value in step_ratios)
        + "}",
        f"\\providecommand{{\\MNISTRemovedPercent}}{{{100 * (1 - aggregate['uniform_8step_ratio_seed_mean']):.1f}}}",
        f"\\providecommand{{\\MNISTCurvatureTotal}}{{{sum(s['n_audit'] for s in seed_summaries)}}}",
        f"\\providecommand{{\\MNISTCurvaturePositive}}{{{positive}}}",
        f"\\providecommand{{\\MNISTBracketCovered}}{{{covered}}}",
        f"\\providecommand{{\\MNISTAdaptiveMean}}{{{aggregate['adaptive_vs_uniform_ratio_seed_mean']:.3f}}}",
        f"\\providecommand{{\\MNISTAdaptiveUpper}}{{{aggregate['adaptive_vs_uniform_ratio_one_sided_upper_95']:.3f}}}",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    aggregate = load_json(RESULTS / "aggregate_summary.json")
    config = load_json(VENDOR / "configs" / "mnist_confirmatory_r2.json")
    seed_summaries = [
        load_json(RESULTS / "seeds" / f"seed_{seed}_summary.json")
        for seed in SEEDS
    ]

    require(aggregate["protocol_id"] == config["protocol_id"], "protocol mismatch")
    require(tuple(config["model_seeds"]) == SEEDS, "seed list mismatch")
    require(aggregate["n_model_seeds"] == len(SEEDS), "run count mismatch")
    require(aggregate["quality_gates_all_runs"], "aggregate quality gate failed")

    for seed, summary in zip(SEEDS, seed_summaries):
        require(summary["seed"] == seed, f"wrong seed summary: {seed}")
        require(summary["mode"] == "confirmatory", f"nonconfirmatory run: {seed}")
        require(summary["n_test"] == config["data"]["n_test"], f"test count: {seed}")
        require(summary["candidate_count"] == 7, f"candidate count: {seed}")
        require(all(summary["quality_gates"].values()), f"quality gate: {seed}")
        require(summary["reference_fallback_count"] == 0, f"fallback used: {seed}")
        require(summary["uniform_total_steps"] == 4096, f"uniform budget: {seed}")
        require(summary["adaptive_total_steps"] == 4096, f"adaptive budget: {seed}")

    gaps = [summary["selected_mean_gap"] for summary in seed_summaries]
    ratios = [summary["uniform_primary_ratio"] for summary in seed_summaries]
    adaptive = [
        summary["adaptive_vs_uniform_ratio"] for summary in seed_summaries
    ]
    gap_mean, gap_sd, gap_lower, _ = one_sided_bounds(gaps)
    ratio_mean, ratio_sd, _, ratio_upper = one_sided_bounds(ratios)
    adaptive_mean, _, _, adaptive_upper = one_sided_bounds(adaptive)

    require_close(gap_mean, aggregate["selected_gap_seed_mean"], "gap mean")
    require_close(gap_sd, aggregate["selected_gap_seed_sd"], "gap sd")
    require_close(
        gap_lower, aggregate["selected_gap_one_sided_lower_95"], "gap lower"
    )
    require_close(
        ratio_mean, aggregate["uniform_8step_ratio_seed_mean"], "ratio mean"
    )
    require_close(
        ratio_sd, aggregate["uniform_8step_ratio_seed_sd"], "ratio sd"
    )
    require_close(
        ratio_upper,
        aggregate["uniform_8step_ratio_one_sided_upper_95"],
        "ratio upper",
    )
    require_close(
        adaptive_mean,
        aggregate["adaptive_vs_uniform_ratio_seed_mean"],
        "adaptive mean",
    )
    require_close(
        adaptive_upper,
        aggregate["adaptive_vs_uniform_ratio_one_sided_upper_95"],
        "adaptive upper",
    )

    threshold = config["primary_thresholds"]
    seed_passes = sum(
        ratio < threshold["uniform_8step_ratio_upper_bound"] for ratio in ratios
    )
    require(seed_passes == aggregate["uniform_8step_seed_passes"], "pass count")
    require(gap_lower > threshold["onepass_gap_lower_bound_nats"], "P1 failed")
    require(
        ratio_upper < threshold["uniform_8step_ratio_upper_bound"], "P2 failed"
    )
    require(seed_passes >= threshold["minimum_seed_passes"], "P3 failed")
    require(
        aggregate["decision"] == "PASS_FINITE_GRAMMAR_CLAIM",
        "unexpected primary decision",
    )
    require(
        Counter(summary["selected_candidate"] for summary in seed_summaries)
        == Counter(aggregate["selection_counts"]),
        "selection counts mismatch",
    )

    with (RESULTS / "seed_summary.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        csv_rows = list(csv.DictReader(handle))
    require(len(csv_rows) == len(seed_summaries), "seed CSV row count")
    for row, summary in zip(csv_rows, seed_summaries):
        require(int(row["seed"]) == summary["seed"], "seed CSV order")
        require_close(
            float(row["selected_mean_gap"]),
            summary["selected_mean_gap"],
            f"seed CSV gap {summary['seed']}",
        )
        require_close(
            float(row["uniform_8step_ratio"]),
            summary["uniform_primary_ratio"],
            f"seed CSV ratio {summary['seed']}",
        )

    candidates = read_candidate_means()
    require(len(candidates) == 7, "candidate CSV row count")
    tex = render_tex(aggregate, candidates, seed_summaries)
    if args.write_tex:
        GENERATED_TEX.write_text(tex, encoding="utf-8")
    else:
        require(
            GENERATED_TEX.read_text(encoding="utf-8") == tex,
            "generated_results.tex is stale; rerun with --write-tex",
        )

    verified_sources = verify_frozen_snapshot(config)
    print(
        "MNIST R2 verified:",
        aggregate["decision"],
        f"gap={gap_mean:.3f} (lower={gap_lower:.3f}),",
        f"eight-step ratio={ratio_mean:.3f} (upper={ratio_upper:.3f}),",
        f"{seed_passes}/{len(SEEDS)} seed passes;",
        f"{verified_sources} frozen source files and 2 declared data hashes checked.",
    )


if __name__ == "__main__":
    main()
