#!/usr/bin/env python3
"""Generate and audit the Chapter 24 synthetic cytometry smoke test."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Hashable, Iterable

import numpy as np
import scipy
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist


HERE = Path(__file__).resolve().parent
N_SAMPLES = 10
N_MARKERS = 39
N_POPULATIONS = 24
N_GRAPH_EDGES = 25
RARE_POPULATIONS = frozenset({20, 21, 22, 23})


@dataclass
class Component:
    sample: int
    local: int
    truth: int
    rare: bool
    cells: int
    centroid: np.ndarray
    normalized: np.ndarray | None = None

    @property
    def key(self) -> tuple[int, int]:
        return (self.sample, self.local)


class DisjointSet:
    def __init__(self, items: Iterable[Hashable]):
        self.parent = {item: item for item in items}
        self.rank = {item: 0 for item in items}

    def find(self, item: Hashable) -> Hashable:
        parent = self.parent[item]
        if parent != item:
            self.parent[item] = self.find(parent)
        return self.parent[item]

    def union(self, left: Hashable, right: Hashable) -> bool:
        root_left, root_right = self.find(left), self.find(right)
        if root_left == root_right:
            return False
        if self.rank[root_left] < self.rank[root_right]:
            root_left, root_right = root_right, root_left
        self.parent[root_right] = root_left
        if self.rank[root_left] == self.rank[root_right]:
            self.rank[root_left] += 1
        return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20260806)
    parser.add_argument("--bootstrap-seed", type=int, default=20260807)
    parser.add_argument("--bootstrap-replicates", type=int, default=5000)
    parser.add_argument("--match-threshold", type=float, default=2.40)
    parser.add_argument(
        "--output-dir", type=Path, default=HERE / "results" / "cytometry"
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def generate_components(
    rng: np.random.Generator,
) -> tuple[list[Component], np.ndarray]:
    base = rng.normal(0.0, 1.55, size=(N_POPULATIONS, N_MARKERS))
    base[21] = base[20] + rng.normal(0.0, 0.28, size=N_MARKERS)
    base[23] = base[22] + rng.normal(0.0, 0.32, size=N_MARKERS)

    angles = np.linspace(0.0, 2.0 * np.pi, N_SAMPLES, endpoint=False)
    covariates = np.column_stack([np.cos(angles), np.sin(angles)])
    covariates += rng.normal(0.0, 0.05, size=covariates.shape)

    components: list[Component] = []
    for sample in range(N_SAMPLES):
        if sample == 0:
            present = np.ones(N_POPULATIONS, dtype=bool)
        else:
            missing_probability = np.full(N_POPULATIONS, 0.08)
            missing_probability[list(RARE_POPULATIONS)] = 0.24
            present = rng.random(N_POPULATIONS) >= missing_probability
            if np.count_nonzero(present) < 18:
                present[np.flatnonzero(~present)[: 18 - np.count_nonzero(present)]] = True

        shift = rng.normal(0.0, 0.20, size=N_MARKERS)
        scale = np.exp(rng.normal(0.0, 0.045, size=N_MARKERS))
        sample_components: list[Component] = []
        for truth in np.flatnonzero(present):
            rare = int(truth) in RARE_POPULATIONS
            cells = int(rng.poisson(38 if rare else 240) + (12 if rare else 60))
            local_drift = rng.normal(0.0, 0.13 if rare else 0.10, size=N_MARKERS)
            centroid_noise = rng.normal(0.0, 0.55 / math.sqrt(cells), size=N_MARKERS)
            centroid = scale * base[truth] + shift + local_drift + centroid_noise
            sample_components.append(
                Component(
                    sample=sample,
                    local=-1,
                    truth=int(truth),
                    rare=rare,
                    cells=cells,
                    centroid=centroid,
                )
            )
        order = rng.permutation(len(sample_components))
        for local, index in enumerate(order):
            component = sample_components[int(index)]
            component.local = local
            components.append(component)

    for sample in range(N_SAMPLES):
        group = [component for component in components if component.sample == sample]
        matrix = np.vstack([component.centroid for component in group])
        center = np.median(matrix, axis=0)
        scale = np.std(matrix - center, axis=0, ddof=1)
        scale = np.maximum(scale, 0.35)
        for component, row in zip(group, (matrix - center) / scale):
            component.normalized = row
    return components, covariates


def build_sample_graph(covariates: np.ndarray) -> list[dict[str, Any]]:
    candidates = []
    for left in range(N_SAMPLES):
        for right in range(left + 1, N_SAMPLES):
            candidates.append(
                {
                    "left": left,
                    "right": right,
                    "distance": float(np.linalg.norm(covariates[left] - covariates[right])),
                }
            )
    candidates.sort(key=lambda item: (item["distance"], item["left"], item["right"]))
    dsu = DisjointSet(range(N_SAMPLES))
    graph: list[dict[str, Any]] = []
    selected: set[tuple[int, int]] = set()
    for item in candidates:
        edge = (item["left"], item["right"])
        if dsu.union(*edge):
            graph.append({**item, "tree_edge": True})
            selected.add(edge)
    for item in candidates:
        edge = (item["left"], item["right"])
        if edge in selected:
            continue
        graph.append({**item, "tree_edge": False})
        selected.add(edge)
        if len(graph) == N_GRAPH_EDGES:
            break
    if len(graph) != N_GRAPH_EDGES:
        raise RuntimeError("Failed to construct the predeclared 25-edge sample graph.")
    return graph


def match_edges(
    components: list[Component],
    graph: list[dict[str, Any]],
    threshold: float,
) -> list[dict[str, Any]]:
    by_sample = {
        sample: sorted(
            [component for component in components if component.sample == sample],
            key=lambda component: component.local,
        )
        for sample in range(N_SAMPLES)
    }
    records: list[dict[str, Any]] = []
    for edge_id, edge in enumerate(graph, start=1):
        left_group, right_group = by_sample[edge["left"]], by_sample[edge["right"]]
        left_matrix = np.vstack([component.normalized for component in left_group])
        right_matrix = np.vstack([component.normalized for component in right_group])
        costs = cdist(left_matrix, right_matrix)
        rows, columns = linear_sum_assignment(costs)
        proposed = {(int(row), int(column)): float(costs[row, column]) for row, column in zip(rows, columns)}
        accepted_left: set[int] = set()
        accepted_right: set[int] = set()
        for (row, column), cost in proposed.items():
            if cost > threshold:
                continue
            left_component, right_component = left_group[row], right_group[column]
            accepted_left.add(row)
            accepted_right.add(column)
            records.append(
                {
                    "edge_id": edge_id,
                    "left_sample": edge["left"],
                    "right_sample": edge["right"],
                    "tree_edge": edge["tree_edge"],
                    "left_local": left_component.local,
                    "right_local": right_component.local,
                    "left_truth": left_component.truth,
                    "right_truth": right_component.truth,
                    "distance": cost,
                    "accepted": True,
                    "correct": left_component.truth == right_component.truth,
                }
            )
        for row, left_component in enumerate(left_group):
            if row not in accepted_left:
                records.append(
                    {
                        "edge_id": edge_id,
                        "left_sample": edge["left"],
                        "right_sample": edge["right"],
                        "tree_edge": edge["tree_edge"],
                        "left_local": left_component.local,
                        "right_local": "",
                        "left_truth": left_component.truth,
                        "right_truth": "",
                        "distance": "",
                        "accepted": False,
                        "correct": "",
                    }
                )
        for column, right_component in enumerate(right_group):
            if column not in accepted_right:
                records.append(
                    {
                        "edge_id": edge_id,
                        "left_sample": edge["left"],
                        "right_sample": edge["right"],
                        "tree_edge": edge["tree_edge"],
                        "left_local": "",
                        "right_local": right_component.local,
                        "left_truth": "",
                        "right_truth": right_component.truth,
                        "distance": "",
                        "accepted": False,
                        "correct": "",
                    }
                )
    return records


def reference_labels(
    dsu: DisjointSet, components: list[Component]
) -> dict[Hashable, set[int]]:
    labels: dict[Hashable, set[int]] = {}
    for component in components:
        if component.sample == 0:
            labels.setdefault(dsu.find(component.key), set()).add(component.local)
    return labels


def evaluate_alignment(
    components: list[Component], matches: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], dict[str, int], dict[tuple[int, int], int | None]]:
    keys = [component.key for component in components]
    tree_dsu = DisjointSet(keys)
    all_dsu = DisjointSet(keys)
    for record in matches:
        if not record["accepted"]:
            continue
        left = (int(record["left_sample"]), int(record["left_local"]))
        right = (int(record["right_sample"]), int(record["right_local"]))
        all_dsu.union(left, right)
        if record["tree_edge"]:
            tree_dsu.union(left, right)

    tree_reference = reference_labels(tree_dsu, components)
    auditable = 0
    agreeing = 0
    inconsistent_cycle_edges: set[int] = set()
    for record in matches:
        if not record["accepted"] or record["tree_edge"]:
            continue
        left = (int(record["left_sample"]), int(record["left_local"]))
        right = (int(record["right_sample"]), int(record["right_local"]))
        left_labels = tree_reference.get(tree_dsu.find(left), set())
        right_labels = tree_reference.get(tree_dsu.find(right), set())
        if len(left_labels) == len(right_labels) == 1:
            auditable += 1
            if left_labels == right_labels:
                agreeing += 1
            else:
                inconsistent_cycle_edges.add(int(record["edge_id"]))

    all_reference = reference_labels(all_dsu, components)
    reference_truth = {
        component.local: component.truth
        for component in components
        if component.sample == 0
    }
    prediction: dict[tuple[int, int], int | None] = {}
    for component in components:
        labels = all_reference.get(all_dsu.find(component.key), set())
        prediction[component.key] = (
            reference_truth[next(iter(labels))] if len(labels) == 1 else None
        )

    sample_rows: list[dict[str, Any]] = []
    for sample in range(N_SAMPLES):
        group = [component for component in components if component.sample == sample]
        present_labels = sorted({component.truth for component in group})
        total = sum(component.cells for component in group)
        correct = sum(
            component.cells
            for component in group
            if prediction[component.key] == component.truth
        )
        unresolved = sum(
            component.cells for component in group if prediction[component.key] is None
        )
        f1_values = []
        for label in present_labels:
            tp = sum(
                component.cells
                for component in group
                if component.truth == label and prediction[component.key] == label
            )
            fp = sum(
                component.cells
                for component in group
                if component.truth != label and prediction[component.key] == label
            )
            fn = sum(
                component.cells
                for component in group
                if component.truth == label and prediction[component.key] != label
            )
            f1_values.append(0.0 if 2 * tp + fp + fn == 0 else 2 * tp / (2 * tp + fp + fn))
        rare_total = sum(component.cells for component in group if component.rare)
        rare_correct = sum(
            component.cells
            for component in group
            if component.rare and prediction[component.key] == component.truth
        )
        sample_rows.append(
            {
                "sample": sample,
                "local_components": len(group),
                "cells_represented": total,
                "label_accuracy": correct / total,
                "macro_f1": float(np.mean(f1_values)),
                "rare_population_recall": rare_correct / rare_total if rare_total else float("nan"),
                "unresolved_cell_rate": unresolved / total,
            }
        )
    cycle = {
        "auditable_branch_transports": auditable,
        "agreeing_branch_transports": agreeing,
        "inconsistent_fundamental_cycles": len(inconsistent_cycle_edges),
    }
    return sample_rows, cycle, prediction


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if trials == 0:
        return float("nan"), float("nan")
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    radius = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return center - radius, center + radius


def bootstrap_mean_interval(
    values: np.ndarray, rng: np.random.Generator, replicates: int
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    indices = rng.integers(0, values.size, size=(replicates, values.size))
    means = values[indices].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def summarize(
    components: list[Component],
    graph: list[dict[str, Any]],
    matches: list[dict[str, Any]],
    sample_rows: list[dict[str, Any]],
    cycle: dict[str, int],
    bootstrap_rng: np.random.Generator,
    bootstrap_replicates: int,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    accepted = [record for record in matches if record["accepted"]]
    true_positive = sum(bool(record["correct"]) for record in accepted)
    false_positive = len(accepted) - true_positive
    by_sample_truth = {
        sample: {component.truth for component in components if component.sample == sample}
        for sample in range(N_SAMPLES)
    }
    shared_truth_total = sum(
        len(by_sample_truth[edge["left"]] & by_sample_truth[edge["right"]])
        for edge in graph
    )
    false_negative = shared_truth_total - true_positive

    actual_missing_total = sum(
        len(by_sample_truth[edge["left"]] - by_sample_truth[edge["right"]])
        + len(by_sample_truth[edge["right"]] - by_sample_truth[edge["left"]])
        for edge in graph
    )
    predicted_missing_total = sum(not record["accepted"] for record in matches)
    missing_detected = 0
    for record in matches:
        if record["accepted"]:
            continue
        if record["left_truth"] != "":
            truth = int(record["left_truth"])
            absent = truth not in by_sample_truth[int(record["right_sample"])]
        else:
            truth = int(record["right_truth"])
            absent = truth not in by_sample_truth[int(record["left_sample"])]
        if absent:
            missing_detected += 1

    count_metrics = {
        "edge_match_true_positive": true_positive,
        "edge_match_false_positive": false_positive,
        "edge_match_false_negative": false_negative,
        "missing_branches": actual_missing_total,
        "predicted_missing_branches": predicted_missing_total,
        "missing_branches_detected": missing_detected,
    }

    rows: list[dict[str, Any]] = []
    for field, endpoint in [
        ("macro_f1", "sample-level macro-F1"),
        ("rare_population_recall", "rare-population recall"),
        ("unresolved_cell_rate", "unresolved-cell rate"),
    ]:
        values = np.asarray([row[field] for row in sample_rows], dtype=float)
        low, high = bootstrap_mean_interval(
            values, bootstrap_rng, bootstrap_replicates
        )
        rows.append(
            {
                "endpoint": endpoint,
                "estimate": float(np.nanmean(values)),
                "ci95_low": low,
                "ci95_high": high,
                "interval_method": "sample bootstrap",
                "unit_count": int(np.count_nonzero(np.isfinite(values))),
            }
        )

    for endpoint, successes, trials in [
        ("edge-match precision", true_positive, true_positive + false_positive),
        ("edge-match recall", true_positive, true_positive + false_negative),
        (
            "missing-branch detection precision",
            missing_detected,
            predicted_missing_total,
        ),
        ("missing-branch detection recall", missing_detected, actual_missing_total),
        (
            "cycle-transport agreement",
            cycle["agreeing_branch_transports"],
            cycle["auditable_branch_transports"],
        ),
    ]:
        low, high = wilson_interval(successes, trials)
        rows.append(
            {
                "endpoint": endpoint,
                "estimate": successes / trials if trials else float("nan"),
                "ci95_low": low,
                "ci95_high": high,
                "interval_method": "Wilson binomial",
                "unit_count": trials,
            }
        )
    return rows, count_metrics


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    bootstrap_rng = np.random.default_rng(args.bootstrap_seed)
    components, covariates = generate_components(rng)
    graph = build_sample_graph(covariates)
    matches = match_edges(components, graph, args.match_threshold)
    sample_rows, cycle, prediction = evaluate_alignment(components, matches)
    summary_rows, counts = summarize(
        components,
        graph,
        matches,
        sample_rows,
        cycle,
        bootstrap_rng,
        args.bootstrap_replicates,
    )
    if len(graph) - N_SAMPLES + 1 != 16:
        raise RuntimeError("The sample graph does not have the declared cycle rank 16.")
    if len([component for component in components if component.sample == 0]) != N_POPULATIONS:
        raise RuntimeError("Reference sample must expose all 24 generated populations.")

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    component_rows = []
    for component in sorted(components, key=lambda item: item.key):
        row: dict[str, Any] = {
            "sample": component.sample,
            "local_component": component.local,
            "designed_population": component.truth,
            "rare_population": component.rare,
            "cells_represented": component.cells,
            "resolved_population": (
                "unresolved" if prediction[component.key] is None else prediction[component.key]
            ),
        }
        row.update(
            {
                f"marker_{index + 1:02d}": float(value)
                for index, value in enumerate(component.centroid)
            }
        )
        component_rows.append(row)
    write_csv(output_dir / "generated_components.csv", component_rows)
    write_csv(output_dir / "sample_graph.csv", graph)
    write_csv(output_dir / "edge_matches.csv", matches)
    write_csv(output_dir / "sample_metrics.csv", sample_rows)
    write_csv(output_dir / "cytometry_summary.csv", summary_rows)

    script_hash = sha256(Path(__file__).resolve())
    payload = {
        "scope": (
            "Synthetic component-matching and cycle-audit smoke test. Local components "
            "are generated with known labels; this run does not assess cell clustering or "
            "claim biological improvement."
        ),
        "config": {
            "seed": args.seed,
            "bootstrap_seed": args.bootstrap_seed,
            "bootstrap_replicates": args.bootstrap_replicates,
            "samples": N_SAMPLES,
            "markers": N_MARKERS,
            "designed_populations": N_POPULATIONS,
            "graph_edges": N_GRAPH_EDGES,
            "cycle_rank": len(graph) - N_SAMPLES + 1,
            "match_threshold": args.match_threshold,
        },
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "platform": platform.platform(),
        },
        "code_sha256": script_hash,
        "content_version_id": script_hash[:16],
        "counts": counts,
        "cycle_audit": cycle,
        "summary": summary_rows,
        "data_entry": "generated_components.csv",
    }
    (output_dir / "cytometry_run.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    print(f"Cytometry smoke test written to {output_dir}")
    print(f"Content version: {script_hash[:16]}")


if __name__ == "__main__":
    main()
