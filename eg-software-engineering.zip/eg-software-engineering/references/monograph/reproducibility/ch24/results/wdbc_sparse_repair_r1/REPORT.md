# WDBC frozen confirmation: rejected claim

Protocol: `WDBC-SPARSE-OALI-R1-2026-08-17`

Decision: `REJECT_ARCHITECTURE_REPAIR_CLAIM`.

Eleven gates passed, but the preregistered requirement that the permuted
gradient be worse than doing nothing failed: its residual-gap ratio had a
one-sided 95% lower bound of 0.615, below the required 1.05. The targeted
repair did outperform this control, but the frozen all-gates rule forbids
retrospective reinterpretation. The failure remains part of the evidence
ledger.
