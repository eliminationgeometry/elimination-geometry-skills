# Diabetes patient-level frozen architecture-repair confirmation

Protocol: `DIABETES-SPARSE-OALI-R1-2026-08-17`

Decision: `ACCEPT_DIABETES_ONE_PASS_PLUS_TWO_STEP_PROXIMAL_EQUAL_INFO`.

All twelve gates passed on 89 untouched patients. Targeted and generic repairs
received the same native carrier and used 288 additional MACs. One-sided 95%
upper bounds were 0.149 for residual gap, 0.187 for targeted/generic gap, and
0.067 for targeted/permuted gap. Disease-progression prediction MSE changed by
-24.08 squared response units; its one-sided 95% upper bound was -2.10.

This is a prospectively frozen within-project scientific-dataset validation
with a fit-free hash-checking acceptor. It is not an external-person audit,
clinical-utility study, or universal architecture theorem.

## Version 1.9 theorem-alignment audit

`theorem_alignment.json` is a separate post-confirmation, fit-free analysis.
FISTA proposes each support, but its floating-point iterate is not treated as
an exact oracle. The verifier resolves the active normal equations and checks
all KKT signs before constructing any cell radius. All 89 rows recertified;
the largest FISTA-to-exact code correction was `9.24e-16`, and the largest
active-stationarity residual was `6.49e-16`.
The alignment geometry freezes the binary sex coordinate, restricts the other
nine coordinates to the training-minmax box, and requires equal frozen values.
Seventy-seven strict centers have positive restricted radii. Among eligible
pairs with different supports and a shared active coordinate, the deterministic
rule maximizes the Chapter 19 native-loss floor. It selects confirmatory rows
17/68 (dataset rows 61/172) and atom 6, with:

- restricted strict-cell radii `0.0410701510` and `0.1205862357`;
- restricted Jacobian-row conflict `0.3894538108`;
- code-error floor `0.0119312825`;
- one-pass native-loss floor `3.5584910e-05`;
- proximal contraction factor `0.7378823041`;
- 24 steps as a conservative sufficient restricted-ball depth at 90% of the
  one-pass floor.

These numbers were not R1 gates. The frozen two-step decision uses
patient-average endpoints and a 288-MAC comparison; the 24-step statement is
a later uniform theorem guarantee and is not claimed compute-matched to R1.
The box-restricted balls define an input grammar; the audit does not establish
that every point in those balls belongs to the population support of attainable
patients.
