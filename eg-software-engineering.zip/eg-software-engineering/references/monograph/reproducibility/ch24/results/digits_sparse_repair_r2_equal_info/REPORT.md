# Digits equal-information/equal-compute control upgrade

Protocol: `DIGITS-SPARSE-OALI-R2-EQUAL-INFO-2026-08-17`

Decision: `ACCEPT_ONE_PASS_PLUS_TWO_STEP_PROXIMAL_EQUAL_INFO`.

All frozen gates passed on 360 images. The targeted and learned generic repairs
received the same baseline code, native gradient, Gram matrix, penalty, and
Lipschitz constant and each used 6,144 MACs. The targeted residual-gap ratio
had one-sided 95% upper bound 0.141; the targeted/generic gap ratio had upper
bound 0.233.

R2 reuses the R1 image split. It is a retrospective control upgrade, not a
fresh-sample replication or an external-person audit.
