# MNIST R2 confirmatory report

Protocol: `MNIST-AG-R2-2026-08-09`  
Decision: **PASS_FINITE_GRAMMAR_CLAIM**

All reference-quality gates and P1--P3 passed. Under the frozen MNIST decoder, diagonal-Gaussian objective, and audited finite one-pass encoder grammar, a material held-out amortization gap remained after data, width, and optimization compensation controls, while the predeclared per-datum iterative interface reliably reduced it.

## Primary results

- P1 residual one-pass gap: seed mean 2.4932 nats; one-sided
  95% lower bound 2.3727 versus the frozen 0.5-nat threshold —
  **PASS**.
- P2 targeted repair: mean uniform-eight-step ratio 0.3539;
  one-sided 95% upper bound 0.3798 versus the frozen 0.80 threshold —
  **PASS**.
- P3 replication: 5/5 seeds had a ratio below 0.80 —
  **PASS**.
- All reference and completeness gates: **PASS**.

The hierarchical bootstrap sensitivity intervals were
2.3767--2.6104
nats for the selected one-pass gap and
0.3334--0.3772
for the uniform-eight-step ratio. Primary inference remains seed-level.

## Run-level results

| Seed | Selected candidate | Initial gap | Uniform-8 ratio | Adaptive/uniform | Quality |
|---:|---|---:|---:|---:|---:|
| 101 | `w512_n55000_e24` | 2.3965 | 0.3393 | 0.9699 | 1 |
| 202 | `w512_n55000_e24` | 2.5753 | 0.3575 | 0.9817 | 1 |
| 303 | `w512_n55000_e24` | 2.3411 | 0.3952 | 0.9953 | 1 |
| 404 | `w512_n55000_e24` | 2.5029 | 0.3554 | 0.9796 | 1 |
| 505 | `w256_n55000_e24` | 2.6499 | 0.3220 | 0.9832 | 1 |

## Frozen one-pass library

| Candidate | Width | Images | Epochs | Selected | Mean test gap | Seed SD |
|---|---:|---:|---:|---:|---:|---:|
| `w256_n10000_e24` | 256 | 10000 | 24 | 0/5 | 5.0839 | 0.3387 |
| `w256_n30000_e24` | 256 | 30000 | 24 | 0/5 | 3.0164 | 0.1148 |
| `w256_n55000_e12` | 256 | 55000 | 12 | 0/5 | 3.0535 | 0.0587 |
| `w256_n55000_e24` | 256 | 55000 | 24 | 1/5 | 2.6415 | 0.0746 |
| `w256_n55000_e4` | 256 | 55000 | 4 | 0/5 | 4.2962 | 0.1207 |
| `w512_n55000_e24` | 512 | 55000 | 24 | 4/5 | 2.5268 | 0.1865 |
| `w64_n55000_e24` | 64 | 55000 | 24 | 0/5 | 3.7783 | 0.0489 |

## Secondary mechanism checks

- Mean adaptive/uniform residual-gap ratio:
  0.9819; one-sided 95% upper bound
  0.9906.
- Mean fraction of audited paths with positive sampled segment-grid curvature:
  0.9719.
- Mean finite-grid bracket coverage among positive paths:
  1.0000.

## Claim boundary

This experiment audits a declared finite encoder grammar for five frozen
decoders. It does not prove a population lower bound, optimize over all neural
encoders, or turn finite-grid curvature estimates into rigorous certificates.
Training compute and per-datum deployment refinement are distinct resources.

