# Frozen digits sparse-repair confirmatory report

Protocol: `DIGITS-SPARSE-OALI-R1-2026-08-13`  
Independent acceptor decision: **ACCEPT_ONE_PASS_PLUS_PROXIMAL**

The protocol, configuration, source, environment record, development-only
report, and prepared model bundle were hashed before the confirmatory 20%
split was scored. The independent acceptor retrained nothing and compared the
raw results only with the frozen gates. All 12 gates passed.

## Certificate and saturation

- 360 confirmatory images were retained.
- The thresholded-affine one-pass encoder had mean native gap `0.00831268`;
  the one-sided 95% bootstrap lower bound was `0.00767655`, above the frozen
  `0.004` gate.
- The oracle proximal residual was `1.94e-16`; every evaluated gap was
  positive.
- 359 confirmatory points passed the strict-KKT margin rule. The frozen search
  found two neighborhoods sharing active atom 4 whose oracle Jacobian rows
  differed by `0.868825`, above the frozen `0.05` gate. One fixed active row of
  a thresholded-affine encoder cannot equal both local oracle derivatives.

## Repair, controls, and endpoint validation

- One proximal step left mean gap `0.00239951`, a residual ratio of `0.288656`;
  its one-sided 95% upper bound was `0.299211` versus the `0.45` gate.
- The equal-MAC generic residual MLP left mean gap `0.00573631`. The targeted
  repair/generic ratio was `0.418301`, with upper bound `0.442808` versus the
  `0.75` gate. Each addition used 3,072 multiply-accumulates after baseline;
  the generic control also had 3,136 learned parameters.
- The permuted-gradient negative control had residual ratio `1.31658`, with
  lower bound `1.27675`, so a proximal-shaped computation without the correct
  mechanism made the native gap worse.
- Mean reconstruction SSE changed by `-0.00681807`; its 95% upper bound was
  `-0.00605321`. The repair did not purchase objective gain with worse image
  fidelity.
- Frozen-classifier accuracy changed from `0.9500` to `0.9528`; the paired
  bootstrap lower bound on the change was `0.0`, above the frozen `-0.02`
  noninferiority gate.

## Claim boundary

This is a closed OALI case for one real benchmark, fixed sparse dictionary,
nonnegative L1 objective, thresholded-affine one-pass grammar, and equal-MAC
deployment comparison. It changes the audited architecture decision inside
that envelope. It does not make proximal gradient, active-set geometry,
sparse coding, or algorithm unrolling novel; it does not imply that arbitrary
feed-forward networks are inferior; and it is not external scientific-domain
validation.
