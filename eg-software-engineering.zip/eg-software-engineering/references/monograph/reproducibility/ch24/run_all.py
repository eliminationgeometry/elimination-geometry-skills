#!/usr/bin/env python3
"""Run the Chapter 24 checks and checksum their shipped artifacts."""

from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
MCMC_ROOT = HERE / "vendor" / "mcmc_aux"
MNIST_ROOT = HERE / "vendor" / "mnist_amortization_r2"
DIGITS_R1_ROOT = HERE / "vendor" / "digits_sparse_repair_r1"
DIGITS_R2_ROOT = HERE / "vendor" / "digits_sparse_repair_r2_equal_info"
WDBC_ROOT = HERE / "vendor" / "wdbc_sparse_repair_r1"
DIABETES_ROOT = HERE / "vendor" / "diabetes_sparse_repair_r1"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def refresh_manifest() -> int:
    """Write hashes for every shipped source and result below this directory."""
    files = sorted(
        path
        for path in HERE.rglob("*")
        if path.is_file()
        and path.name != "SHA256SUMS.txt"
        and "__pycache__" not in path.parts
    )
    lines = [f"{sha256(path)}  {path.relative_to(HERE)}" for path in files]
    (HERE / "SHA256SUMS.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return len(files)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest-only",
        action="store_true",
        help="refresh SHA256SUMS.txt without rerunning numerical studies",
    )
    parser.add_argument(
        "--mnist-source-tests",
        action="store_true",
        help="also run the six PyTorch-dependent MNIST source unit tests",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.manifest_only:
        count = refresh_manifest()
        print(f"Artifact manifest written for {count} files.")
        return

    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    subprocess.run(
        [sys.executable, str(HERE / "verify_mnist_audit.py")],
        check=True,
        env=environment,
    )
    subprocess.run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(DIGITS_R1_ROOT / "tests"),
            "-v",
        ],
        check=True,
        env=environment,
    )
    subprocess.run(
        [
            sys.executable,
            str(DIGITS_R1_ROOT / "python" / "accept_frozen_results.py"),
            "--root",
            str(DIGITS_R1_ROOT),
            "--results",
            str(HERE / "results" / "digits_sparse_repair"),
        ],
        check=True,
        env=environment,
    )
    for root in (DIGITS_R2_ROOT, WDBC_ROOT, DIABETES_ROOT):
        subprocess.run(
            [
                sys.executable,
                "-m",
                "unittest",
                "discover",
                "-s",
                str(root / "tests"),
                "-v",
            ],
            check=True,
            env=environment,
        )
    subprocess.run(
        [
            sys.executable,
            str(DIGITS_R2_ROOT / "python" / "accept_frozen_results.py"),
            "--root",
            str(DIGITS_R2_ROOT),
            "--results",
            str(HERE / "results" / "digits_sparse_repair_r2_equal_info"),
        ],
        check=True,
        env=environment,
    )
    wdbc = subprocess.run(
        [
            sys.executable,
            str(WDBC_ROOT / "python" / "accept_frozen_results.py"),
            "--root",
            str(WDBC_ROOT),
            "--results",
            str(HERE / "results" / "wdbc_sparse_repair_r1"),
        ],
        check=False,
        env=environment,
    )
    if wdbc.returncode != 2:
        raise RuntimeError("Frozen WDBC-R1 rejection was not reproduced.")
    subprocess.run(
        [
            sys.executable,
            str(DIABETES_ROOT / "python" / "accept_frozen_results.py"),
            "--root",
            str(DIABETES_ROOT),
            "--results",
            str(HERE / "results" / "diabetes_sparse_repair_r1"),
        ],
        check=True,
        env=environment,
    )
    subprocess.run(
        [
            sys.executable,
            str(
                DIABETES_ROOT
                / "python"
                / "verify_active_set_depth_certificate.py"
            ),
            "--config",
            str(DIABETES_ROOT / "configs" / "diabetes_sparse_repair_r1.json"),
            "--alignment-config",
            str(DIABETES_ROOT / "configs" / "theorem_alignment_v1_9.json"),
            "--bundle",
            str(DIABETES_ROOT / "artifacts" / "frozen_model_bundle.joblib"),
            "--output",
            str(
                HERE
                / "results"
                / "diabetes_sparse_repair_r1"
                / "theorem_alignment.json"
            ),
            "--tex-output",
            str(
                HERE
                / "results"
                / "diabetes_sparse_repair_r1"
                / "theorem_alignment.tex"
            ),
        ],
        check=True,
        env=environment,
    )
    if args.mnist_source_tests:
        subprocess.run(
            [
                sys.executable,
                "-m",
                "unittest",
                "discover",
                "-s",
                str(MNIST_ROOT / "tests"),
                "-v",
            ],
            check=True,
            env=environment,
        )
    subprocess.run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(MCMC_ROOT / "tests"),
            "-v",
        ],
        check=True,
        env=environment,
    )
    monte_carlo_output = HERE / "results" / "monte_carlo_reuse"
    subprocess.run(
        [
            sys.executable,
            str(MCMC_ROOT / "python" / "run_experiments.py"),
            "--reps",
            "300",
            "--seed",
            "20260714",
            "--output",
            str(monte_carlo_output / "summary.json"),
            "--table",
            str(monte_carlo_output / "generated_results.tex"),
        ],
        check=True,
        env=environment,
    )
    subprocess.run([sys.executable, str(HERE / "run_cytometry_smoke.py")], check=True)
    count = refresh_manifest()
    print(f"Verified artifact manifest written for {count} files.")


if __name__ == "__main__":
    main()
