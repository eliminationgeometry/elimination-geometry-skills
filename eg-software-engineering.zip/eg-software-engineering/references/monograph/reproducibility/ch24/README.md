# Chapter 24 reproducibility entry point

This directory supports only the numerical statements printed in Chapter 24.
It adds no theorem and deliberately separates a prospectively frozen but
incomplete MNIST audit, a closed frozen digits sparse-repair architecture
decision, a closed patient-level diabetes decision with a separate
post-confirmation theorem-alignment audit, an analytic posterior-family Monte
Carlo check, a synthetic cytometry software-path check, and a future
domain-data confirmation.

Run the compact MNIST verification and the two regenerating studies from this
directory with the same Python environment:

```bash
python3 run_all.py
```

The older studies' common checked environment is pinned in
`requirements.txt`.  The digits package separately records the executed
Python, NumPy, SciPy, scikit-learn, and joblib versions in its frozen
environment record. `run_all.py` verifies the archived MNIST endpoints,
reruns the independent digits and diabetes acceptors, regenerates the fit-free
active-set depth certificate, runs the vendored unit tests,
regenerates the Monte Carlo and cytometry studies, and writes a SHA-256
manifest for all source and generated artifacts.
Because this workspace is not a Git repository, the book reports content hashes
instead of inventing a commit identifier.

## MNIST amortization audit

The source frozen before the five formal runs is vendored under
`vendor/mnist_amortization_r2/`. The compact book archive under
`results/mnist_amortization/` contains the five seed summaries, all seven
candidate aggregates, the primary decision, and the generated TeX numbers.
Run

```bash
python3 verify_mnist_audit.py
```

to recompute every printed seed-level endpoint, check the frozen source
hashes and declared MNIST data hashes, and compare the generated TeX exactly.
This fast check does not claim to retrain the models. The optional six
PyTorch-dependent source tests run with

```bash
python3 run_all.py --mnist-source-tests
```

and their additional dependency is pinned in `requirements-mnist-full.txt`.
Full retraining requires the two raw gzip files named in the vendored README
and is intentionally a separate operation.

## Closed digits sparse-repair case

The package under `vendor/digits_sparse_repair_r1/` contains the protocol,
configuration, development-only report, prepared model bundle, source,
environment record, and pre-confirmation hash manifest for protocol
`DIGITS-SPARSE-OALI-R1-2026-08-13`. The untouched 20% confirmatory split is
archived under `results/digits_sparse_repair/` as a raw per-image table and
summary. The acceptor retrains nothing and checks all frozen hashes and
thresholds. It returns `ACCEPT_ONE_PASS_PLUS_PROXIMAL` only if the positive
native-gap certificate, strict-KKT Jacobian conflict, targeted repair,
equal-MAC generic control, permuted-gradient negative control, reconstruction
endpoint, and classification noninferiority all pass.

This is a closed OALI benchmark validation for a fixed nonnegative sparse-
coding and compute contract. It does not claim novelty for sparse coding,
proximal gradient, active-set geometry, or unrolling, and it is not a
scientific-domain OAI confirmation.

## Patient-level diabetes decision and theorem alignment

Protocol `DIABETES-SPARSE-OALI-R1-2026-08-17` was frozen before its 89
confirmatory patients were scored. Its fit-free acceptor checks 12 gates and
returns
`ACCEPT_DIABETES_ONE_PASS_PLUS_TWO_STEP_PROXIMAL_EQUAL_INFO`. The targeted
and generic controls receive the same carrier and use 288 additional MACs.
This remains a within-project scientific benchmark validation, not clinical
utility or external-person replication.

Version 1.9 adds
`vendor/diabetes_sparse_repair_r1/python/verify_active_set_depth_certificate.py`.
It fits no model. From the sealed bundle and confirmatory records it exactly
recertifies KKT centers, freezes the binary coordinate, clips the other nine
coordinates to the training-minmax box, computes the restricted Chapter 19
strict-cell radii, deterministically selects the same-sex pair with the largest
certified one-pass native-loss floor, and writes
`results/diabetes_sparse_repair_r1/theorem_alignment.{json,tex}`. This audit
occurred after R1 confirmation. It is not a thirteenth frozen gate and does
not convert the two-step average-endpoint decision into a prospective uniform
24-step theorem validation or a patient-population-support result.

## Posterior-family Monte Carlo reuse

The exact source snapshot is vendored under `vendor/mcmc_aux/`. It contains
NumPy-only core calculations, the experiment runner, unit tests, the protocol
frozen before the full run, and a proved/imported/withheld claim audit.
`run_all.py` writes the source-of-truth output to
`results/monte_carlo_reuse/summary.json` and the compact generated table to the
same directory.

The first pilot uses exactly enumerable two-state Gibbs kernels, so the
stationary biases, perturbation bounds, and localization slopes are analytic;
the chain simulation is only an implementation check. The second pilot uses
41 conjugate Gaussian local posteriors, 21 particle-bank anchors, exact normal
density ratios, 300 replications, and seed `20260714`. Fresh draws and ratio
evaluations are reported separately. The study checks the ESS/overlap and
reuse mechanism; it does not establish wall-clock gain or nonlinear
state-space performance.

## Synthetic cytometry smoke test

`run_cytometry_smoke.py` generates ten synthetic samples with 39 marker
coordinates and 24 designed populations, constructs a connected 25-edge sample
graph (cycle rank 16), performs thresholded Hungarian partial matching, audits
non-tree cycle transports, and resolves components through the retained partial
transport graph. Seed `20260806` fixes the generated component table.

The actual synthetic data entry point is
`results/cytometry/generated_components.csv`. It contains the generated local
component centroids, represented cell counts, designed labels, and recovered
labels. Confidence intervals for macro-F1, rare-population recall, and the
unresolved-cell rate resample the ten sample units; edge and cycle intervals are
Wilson binomial intervals. This is not a cell-clustering benchmark: the local
components are generated with known labels.

## Real-data boundary and access

The MNIST study is a completed execution of a frozen real-benchmark protocol,
not a completed OALI validation.  It reports a fixed Monte Carlo
sample-average objective; its scaling curves do not establish saturation, and
the design lacks independent Monte Carlo evaluation, compute-matched generic
repairs, and negative controls.  It is not a scientific-domain OAI
confirmation and does not justify a general architecture choice. No Samusik
result is reported by the book. The predeclared
future entry point is
the Bioconductor `HDCytoData` object `Samusik_all_SE()` (or
`Samusik_all_flowSet()`), with the original files at FlowRepository accession
`FR-FCM-ZZPH`. The data contain ten mouse bone-marrow samples, 39 markers, and
24 manually gated populations. A future confirmation must freeze the package
and data versions, split by biological sample, and publish the complete output
table before the book may state a biological gain.
