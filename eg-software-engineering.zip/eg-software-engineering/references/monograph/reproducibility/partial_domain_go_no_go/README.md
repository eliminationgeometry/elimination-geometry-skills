# Partial-domain flagship go/no-go audit

This standard-library audit checks the finite statements used in
`PARTIAL_DOMAIN_FLAGSHIP_GO_NO_GO.md`.

It verifies:

1. on small cycles, singleton partial identities admit a global section if
   and only if all domain bits are equal;
2. a one-edge anomaly has exact one-chart obstruction `1 / L`;
3. the three-state total-permutation completion preserves every valid section;
4. for a small rational-noise experiment, direct enumeration of the complete
   sample space equals the stated chi-square mixture identity.

Run:

```bash
python3 run_audit.py
```

The script writes no data and uses exact rational arithmetic for the
chi-square check.  `summary.json` records the frozen expected output.
