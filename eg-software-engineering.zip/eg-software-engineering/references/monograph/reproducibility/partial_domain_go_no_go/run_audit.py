#!/usr/bin/env python3
"""Exact small-instance checks for the partial-domain flagship no-go audit."""

from fractions import Fraction
from itertools import product
import json


def partial_edge_satisfied(left, right, domain_bit):
    return left == domain_bit and right == domain_bit


def one_chart_obstruction(domain_bits):
    length = len(domain_bits)
    best = length + 1
    for labels in product((0, 1), repeat=length):
        violations = 0
        for edge, bit in enumerate(domain_bits):
            left = labels[edge]
            right = labels[(edge + 1) % length]
            violations += not partial_edge_satisfied(left, right, bit)
        best = min(best, violations)
    return Fraction(best, length)


def partial_sections(domain_bits):
    length = len(domain_bits)
    result = []
    for labels in product((0, 1), repeat=length):
        if all(
            partial_edge_satisfied(labels[e], labels[(e + 1) % length], bit)
            for e, bit in enumerate(domain_bits)
        ):
            result.append(labels)
    return result


DUMMY = 2


def completed_permutation(domain_bit):
    # T^0 fixes 0 and swaps 1 with dummy; T^1 fixes 1 and swaps 0 with dummy.
    if domain_bit == 0:
        return {0: 0, 1: DUMMY, DUMMY: 1}
    return {0: DUMMY, 1: 1, DUMMY: 0}


def masked_total_sections(domain_bits):
    length = len(domain_bits)
    result = []
    for labels in product((0, 1), repeat=length):
        valid = True
        for edge, bit in enumerate(domain_bits):
            perm = completed_permutation(bit)
            if perm[labels[edge]] != labels[(edge + 1) % length]:
                valid = False
                break
        if valid:
            result.append(labels)
    return result


def bernoulli_mass(sample, parameter):
    mass = Fraction(1, 1)
    for value in sample:
        mass *= parameter if value else 1 - parameter
    return mass


def complete_mass(outcome, length, repeats, q, anomaly_edge=None):
    mass = Fraction(1, 1)
    for edge in range(length):
        block = outcome[edge * repeats : (edge + 1) * repeats]
        parameter = 1 - q if edge == anomaly_edge else q
        mass *= bernoulli_mass(block, parameter)
    return mass


def verify_chi_square_identity(length=4, repeats=2, q=Fraction(1, 4)):
    direct = Fraction(0, 1)
    for outcome in product((0, 1), repeat=length * repeats):
        p0 = complete_mass(outcome, length, repeats, q)
        mixture = sum(
            (complete_mass(outcome, length, repeats, q, anomaly_edge=e)
             for e in range(length)),
            Fraction(0, 1),
        ) / length
        direct += (mixture - p0) ** 2 / p0

    single_chi_square = (1 - 2 * q) ** 2 / (q * (1 - q))
    formula = ((1 + single_chi_square) ** repeats - 1) / length
    assert direct == formula
    return {
        "length": length,
        "repeats": repeats,
        "q": str(q),
        "direct_chi_square": str(direct),
        "formula_chi_square": str(formula),
    }


def main():
    deterministic_checks = []
    for length in range(3, 8):
        null_bits = (0,) * length
        assert partial_sections(null_bits) == [(0,) * length]
        assert masked_total_sections(null_bits) == partial_sections(null_bits)
        assert one_chart_obstruction(null_bits) == 0

        for anomaly_edge in range(length):
            bits = [0] * length
            bits[anomaly_edge] = 1
            bits = tuple(bits)
            assert partial_sections(bits) == []
            assert masked_total_sections(bits) == partial_sections(bits)
            assert one_chart_obstruction(bits) == Fraction(1, length)

        # Exhaustive equivalence of partial and masked-total sections.
        for bits in product((0, 1), repeat=length):
            assert masked_total_sections(bits) == partial_sections(bits)

        deterministic_checks.append({
            "cycle_length": length,
            "all_domain_patterns_checked": 2 ** length,
            "null_obstruction": "0",
            "one_anomaly_obstruction": f"1/{length}",
        })

    result = {
        "status": "PASS",
        "deterministic_checks": deterministic_checks,
        "chi_square_check": verify_chi_square_identity(),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
