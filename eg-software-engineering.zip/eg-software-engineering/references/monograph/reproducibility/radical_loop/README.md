# Radical-loop deterministic code-path audit

This package supplies the executable check referenced in Chapter 23.  It is
deliberately separate from the three Chapter 24 laboratories.

The declared square-root contract is:

- a population world is a nonvanishing loop
  `z(theta) = r exp(i {ell theta + beta + gamma sin(theta + shift)})`;
- the deployed input contains the current target value `u = z(theta)`;
- the repaired output is a point root together with a retained chart label;
- the analytic one-chart object is a worldwise oracle witness used only to
  check the even-degree zero identity and odd-degree radius-squared identity;
  it reads generator parameters and is not a deployable common baseline;
- native loss is `|a**2 - u|**2`;

The repaired architecture is fixed before any loop is generated.  It consists
of the two standard square-root charts on the target-value plane, cut along
opposite real half-axes.  The same router and local formulas are used in every
compatible world.  The audit also evaluates the full-root-set witness and an
unsafe label-collapsing ablation.

Run the complete deterministic audit from this directory:

```bash
python3 run_audit.py
python3 -m unittest discover -s tests -v
```

Only the Python standard library is required.  The default run uses one seeded
pool of 240 audit loops, 1,024 contexts per loop, and seed `20260806`.  It
writes machine-readable identity residuals under `results/` and refreshes
`SHA256SUMS.txt`.

The finite-grid degree certificate is exact only for the declared synthetic
family: exact complex target values are observed and the public uniform phase
derivative bound `L_max = 3.35` makes every adjacent phase increment smaller
than pi.  The audit is
therefore a deterministic code-path audit, not a fitted-model experiment or
held-out population validation.  It checks the degree routine, fixed atlas,
full root set, two analytic one-chart identities, and collapsed-output
identity.  It makes no noisy-data, neural-optimization, or application claim.

A randomly moved seam is not used as a negative control.  In this exact radical
family, moving a valid branch cut is a gauge choice and remains an equally
correct atlas repair.  The mechanism-destroying control instead removes the
retained chart/root distinction by averaging the two roots, which returns zero
and pays the full catastrophe tax.
