"""Regression tests for the radical-loop common-witness audit."""

from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from run_audit import (  # noqa: E402
    LoopWorld,
    TAU,
    fixed_atlas_root,
    full_root_set,
    identify_degree,
    native_defect,
    oracle_one_chart_witness,
)


class RadicalLoopAuditTest(unittest.TestCase):
    def test_fixed_atlas_is_exact_around_the_circle(self) -> None:
        labels: set[int] = set()
        for index in range(720):
            target = 1.1 * complex(
                math.cos(TAU * index / 720), math.sin(TAU * index / 720)
            )
            label, root = fixed_atlas_root(target)
            labels.add(label)
            self.assertLess(native_defect(root, target), 1.0e-28)
        self.assertEqual(labels, {0, 1})

    def test_full_root_set_is_exact(self) -> None:
        target = 0.8 * complex(-0.4, -0.916515138991168)
        roots = full_root_set(target)
        self.assertAlmostEqual(abs(roots[0] + roots[1]), 0.0, places=14)
        for root in roots:
            self.assertLess(native_defect(root, target), 1.0e-28)

    def test_spacing_certificate_identifies_degree(self) -> None:
        for degree in range(-3, 4):
            world = LoopWorld(degree, 1.0, 0.7, 0.3, 1.2)
            certificate = identify_degree(world, 128)
            self.assertEqual(certificate.status, "singleton")
            self.assertEqual(certificate.identified_degree, degree)

    def test_worldwise_oracle_witness_identities(self) -> None:
        even = LoopWorld(2, 1.2, 0.4, 0.25, 0.8)
        odd = LoopWorld(1, 1.2, 0.4, 0.25, 0.8)
        for index in range(128):
            theta = TAU * index / 128
            self.assertLess(
                native_defect(
                    oracle_one_chart_witness(even, theta), even.target(theta)
                ),
                1.0e-28,
            )
            self.assertAlmostEqual(
                native_defect(
                    oracle_one_chart_witness(odd, theta), odd.target(theta)
                ),
                odd.radius**2,
                places=13,
            )

    def test_collapsed_output_identity(self) -> None:
        world = LoopWorld(-3, 0.9, -0.2, 0.1, 2.0)
        for index in range(128):
            theta = TAU * index / 128
            self.assertAlmostEqual(
                native_defect(0.0j, world.target(theta)),
                world.radius**2,
                places=13,
            )


if __name__ == "__main__":
    unittest.main()
