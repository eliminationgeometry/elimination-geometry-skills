#!/usr/bin/env python3
"""Run the deterministic radical-loop common-witness code-path audit."""

from __future__ import annotations

import argparse
import cmath
import csv
import hashlib
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


TAU = 2.0 * math.pi
RADIUS_MIN = 0.75
RADIUS_MAX = 1.25
DEGREES = (-3, -2, -1, 0, 1, 2, 3)
DECLARED_PHASE_LIPSCHITZ_BOUND = 3.35
HERE = Path(__file__).resolve().parent


def wrap_phase(value: float) -> float:
    """Wrap a phase to [-pi, pi)."""

    return (value + math.pi) % TAU - math.pi


@dataclass(frozen=True)
class LoopWorld:
    """One complete population loop and its known synthetic regularity bound."""

    degree: int
    radius: float
    offset: float
    warp: float
    warp_shift: float

    def phase(self, theta: float) -> float:
        return (
            self.degree * theta
            + self.offset
            + self.warp * math.sin(theta + self.warp_shift)
        )

    def target(self, theta: float) -> complex:
        return self.radius * cmath.exp(1j * self.phase(theta))

@dataclass(frozen=True)
class DegreeCertificate:
    status: str
    identified_degree: int | None
    maximum_permitted_increment: float
    winding_residual: float | None


def fixed_atlas_root(target: complex) -> tuple[int, complex]:
    """Apply one fixed two-chart square-root atlas to a nonzero target.

    Chart 0 uses phase in (-pi, pi) and is routed on the right half-plane.
    Chart 1 uses phase in (0, 2 pi) and is routed on the left half-plane.
    The cuts are never selected by their respective routers.
    """

    if abs(target) == 0.0:
        raise ValueError("The radical audit requires positive clearance from zero.")
    phase = cmath.phase(target)
    if target.real >= 0.0:
        label = 0
        lifted_phase = phase
    else:
        label = 1
        lifted_phase = phase if phase > 0.0 else phase + TAU
    root = math.sqrt(abs(target)) * cmath.exp(0.5j * lifted_phase)
    return label, root


def full_root_set(target: complex) -> tuple[complex, complex]:
    """Return the unordered square-root fiber using the fixed atlas formula."""

    _, root = fixed_atlas_root(target)
    return root, -root


def native_defect(action: complex, target: complex) -> float:
    return abs(action * action - target) ** 2


def identify_degree(world: LoopWorld, contexts: int) -> DegreeCertificate:
    """Certify a singleton degree from exact samples and a spacing bound."""

    if contexts < 8:
        raise ValueError("At least eight contexts are required.")
    step = TAU / contexts
    permitted = DECLARED_PHASE_LIPSCHITZ_BOUND * step
    if permitted >= math.pi:
        return DegreeCertificate("unresolved", None, permitted, None)

    targets = [world.target(index * step) for index in range(contexts)]
    increment_sum = 0.0
    for index, current in enumerate(targets):
        following = targets[(index + 1) % contexts]
        increment_sum += cmath.phase(following / current)
    winding = increment_sum / TAU
    identified = int(round(winding))
    residual = abs(winding - identified)
    status = "singleton" if residual < 1.0e-10 else "unresolved"
    return DegreeCertificate(
        status,
        identified if status == "singleton" else None,
        permitted,
        residual,
    )


def oracle_one_chart_witness(world: LoopWorld, theta: float) -> complex:
    """Worldwise analytic witness, not a deployable common baseline.

    The generator's degree and phase are used intentionally: this object
    checks the even-degree identity and the sharp odd-degree r^2 identity.
    It is never presented as an architecture that can infer those quantities.
    """

    if world.degree % 2:
        return 0.0j
    return math.sqrt(world.radius) * cmath.exp(0.5j * world.phase(theta))


def draw_world(rng: random.Random) -> LoopWorld:
    return LoopWorld(
        degree=rng.choice(DEGREES),
        radius=rng.uniform(RADIUS_MIN, RADIUS_MAX),
        offset=rng.uniform(-math.pi, math.pi),
        warp=rng.uniform(-0.35, 0.35),
        warp_shift=rng.uniform(0.0, TAU),
    )


def evaluate_world(
    unit: int,
    world: LoopWorld,
    contexts: int,
) -> dict[str, object]:
    certificate = identify_degree(world, contexts)
    atlas_max = 0.0
    root_set_max = 0.0
    oracle_one_chart_max = 0.0
    collapsed_max = 0.0
    oracle_one_chart_identity_residual = 0.0
    collapsed_identity_residual = 0.0
    labels: set[int] = set()

    for index in range(contexts):
        theta = TAU * index / contexts
        target = world.target(theta)
        label, atlas_action = fixed_atlas_root(target)
        labels.add(label)
        atlas_max = max(atlas_max, native_defect(atlas_action, target))
        root_set_max = max(
            root_set_max,
            max(native_defect(root, target) for root in full_root_set(target)),
        )
        oracle_defect = native_defect(
            oracle_one_chart_witness(world, theta), target
        )
        expected_oracle_defect = 0.0 if world.degree % 2 == 0 else world.radius**2
        oracle_one_chart_max = max(oracle_one_chart_max, oracle_defect)
        oracle_one_chart_identity_residual = max(
            oracle_one_chart_identity_residual,
            abs(oracle_defect - expected_oracle_defect),
        )
        collapsed_defect = native_defect(0.0j, target)
        collapsed_max = max(collapsed_max, collapsed_defect)
        collapsed_identity_residual = max(
            collapsed_identity_residual,
            abs(collapsed_defect - world.radius**2),
        )

    return {
        "unit": unit,
        "degree": world.degree,
        "radius": world.radius,
        "offset": world.offset,
        "warp": world.warp,
        "warp_shift": world.warp_shift,
        "degree_status": certificate.status,
        "identified_degree": certificate.identified_degree,
        "degree_correct": certificate.identified_degree == world.degree,
        "maximum_permitted_increment": certificate.maximum_permitted_increment,
        "winding_residual": certificate.winding_residual,
        "atlas_labels_used": ",".join(str(value) for value in sorted(labels)),
        "oracle_one_chart_max_defect": oracle_one_chart_max,
        "oracle_one_chart_identity_residual": oracle_one_chart_identity_residual,
        "common_atlas_max_defect": atlas_max,
        "full_root_set_max_defect": root_set_max,
        "collapsed_output_max_defect": collapsed_max,
        "collapsed_output_identity_residual": collapsed_identity_residual,
    }


def summarize(
    rows: Sequence[dict[str, object]],
    seed: int,
    contexts: int,
) -> dict[str, object]:
    odd = [row for row in rows if int(row["degree"]) % 2]
    even = [row for row in rows if not int(row["degree"]) % 2]
    observed_chart_ids = sorted(
        {
            int(label)
            for row in rows
            for label in str(row["atlas_labels_used"]).split(",")
            if label
        }
    )

    return {
        "claim_class": "deterministic code-path audit",
        "contract": {
            "radical_order": 2,
            "deployed_input": "target value u=z(theta)",
            "repaired_output": "point root with retained chart label",
            "native_loss": "|a^2-u|^2",
            "analytic_benchmark": (
                "worldwise oracle one-chart witness; not a common deployable baseline"
            ),
            "clearance_interval": [RADIUS_MIN, RADIUS_MAX],
        },
        "configuration": {
            "seed": seed,
            "audit_loops": len(rows),
            "contexts_per_loop": contexts,
        },
        "certificate": {
            "singleton_and_correct": all(
                bool(row["degree_correct"])
                and row["degree_status"] == "singleton"
                for row in rows
            ),
            "maximum_spacing_bound": max(
                float(row["maximum_permitted_increment"]) for row in rows
            ),
            "maximum_winding_residual": max(
                float(row["winding_residual"]) for row in rows
            ),
        },
        "audit_results": {
            "loops": len(rows),
            "odd_degree_loops": len(odd),
            "even_degree_loops": len(even),
            "common_atlas_max_defect": max(
                float(row["common_atlas_max_defect"]) for row in rows
            ),
            "full_root_set_max_defect": max(
                float(row["full_root_set_max_defect"]) for row in rows
            ),
            "even_oracle_one_chart_max_defect": max(
                (float(row["oracle_one_chart_max_defect"]) for row in even),
                default=0.0,
            ),
            "oracle_one_chart_identity_max_residual": max(
                float(row["oracle_one_chart_identity_residual"]) for row in rows
            ),
            "collapsed_output_identity_max_residual": max(
                float(row["collapsed_output_identity_residual"]) for row in rows
            ),
            "observed_atlas_chart_ids": observed_chart_ids,
        },
        "controls": {
            "even_winding": "the worldwise analytic witness has zero defect",
            "odd_winding": "the worldwise analytic witness pays exactly r^2",
            "collapsed_labels": "averaging the two roots returns zero and pays r^2",
            "random_seam": (
                "withheld: moving a valid cut is gauge-equivalent, not a "
                "mechanism-destroying control"
            ),
        },
        "boundary": (
            "Exact target values and a known phase-derivative bound are used. "
            "Generator parameters enter only the worldwise analytic benchmark "
            "and known identity checks. No model is fitted and no held-out "
            "population inference is claimed. The audit does not validate noisy "
            "degree recovery, learned routing, neural optimization, or "
            "application performance."
        ),
    }


def write_csv(path: Path, rows: Iterable[dict[str, object]]) -> None:
    materialized = list(rows)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(materialized[0]))
        writer.writeheader()
        writer.writerows(materialized)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def refresh_manifest() -> None:
    files = sorted(
        path
        for path in HERE.rglob("*")
        if path.is_file()
        and path.name != "SHA256SUMS.txt"
        and "__pycache__" not in path.parts
    )
    lines = [f"{sha256(path)}  {path.relative_to(HERE)}" for path in files]
    (HERE / "SHA256SUMS.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20260806)
    parser.add_argument("--loops", type=int, default=240)
    parser.add_argument("--contexts", type=int, default=1024)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.loops < 1:
        raise ValueError("The audit requires at least one loop.")
    if args.contexts < 16:
        raise ValueError("The audit requires at least sixteen contexts per loop.")

    rng = random.Random(args.seed)
    rows = [
        evaluate_world(unit, draw_world(rng), args.contexts)
        for unit in range(args.loops)
    ]

    output_dir = HERE / "results"
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "per_loop.csv", rows)
    summary = summarize(
        rows,
        args.seed,
        args.contexts,
    )
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    refresh_manifest()

    print("Radical-loop audit completed.")
    print(json.dumps(summary["audit_results"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
