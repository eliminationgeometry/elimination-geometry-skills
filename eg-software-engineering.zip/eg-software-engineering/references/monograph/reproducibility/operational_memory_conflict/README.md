# Operationally exposed memory-conflict audit

This directory verifies the exact finite seed used in
`OPERATIONALLY_EXPOSED_MEMORY_CONFLICT_GO_NO_GO.md`.

Run:

```bash
python3 run_audit.py
```

The script uses only the Python standard library.  It checks:

- equality of the retained `(A,R)` law in the null and conflict worlds for
  both deterministic policies executable by the constant baseline memory;
- positive information after temporarily retaining the history bit;
- the population value and resource-adjusted architecture tables;
- exact equal-prior Bayes errors for the exposed Bernoulli experiment;
- numerical sequential change-of-measure lower bounds and a midpoint-Hoeffding
  sufficient sample size.

Randomized baseline policies are mixtures of the two deterministic policies,
so the exact law equality covers them as well.  Adaptive multi-episode
blindness follows inductively from the same one-episode identity.

`summary.json` is generated deterministically.  This is an identity check, not
an empirical architecture-repair validation.
