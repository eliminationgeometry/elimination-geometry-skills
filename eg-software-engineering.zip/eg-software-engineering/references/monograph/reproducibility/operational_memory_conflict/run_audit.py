#!/usr/bin/env python3
"""Exact audit for the operationally exposed memory-conflict seed.

Uses rational arithmetic for finite laws and floating point only for KL/log
bounds.  The output is deterministic and is not an empirical experiment.
"""

from __future__ import annotations

import json
import math
from fractions import Fraction
from pathlib import Path


ETA = Fraction(1, 4)
MEMORY_COST = Fraction(1, 8)
DELTA = 0.05
MAX_N = 200


def baseline_law(theta: int, action: int) -> dict[tuple[int, int], Fraction]:
    """Law of retained (A,R) for a deterministic constant-memory action."""
    out: dict[tuple[int, int], Fraction] = {}
    for h in (0, 1):
        ph = Fraction(1, 2)
        if theta == 0:
            targets = ((0, Fraction(1, 2)), (1, Fraction(1, 2)))
        else:
            targets = ((h, 1 - ETA), (1 - h, ETA))
        for b, pb in targets:
            r = int(action == b)
            out[(action, r)] = out.get((action, r), Fraction(0)) + ph * pb
    return out


def exposed_reward_law(theta: int) -> dict[int, Fraction]:
    """Reward law after retaining H and choosing A=H."""
    p_success = Fraction(1, 2) if theta == 0 else 1 - ETA
    return {0: 1 - p_success, 1: p_success}


def architecture_values() -> dict[str, dict[str, Fraction]]:
    return {
        "theta_0": {"phi_0": Fraction(1, 2), "phi_1": Fraction(1, 2)},
        "theta_1": {"phi_0": Fraction(1, 2), "phi_1": 1 - ETA},
    }


def binomial_pmf(n: int, k: int, p: Fraction) -> Fraction:
    return Fraction(math.comb(n, k)) * p**k * (1 - p) ** (n - k)


def exact_bayes_error(n: int) -> Fraction:
    p0 = Fraction(1, 2)
    p1 = 1 - ETA
    overlap = sum(
        min(binomial_pmf(n, k, p0), binomial_pmf(n, k, p1))
        for k in range(n + 1)
    )
    return overlap / 2


def bernoulli_kl(p: float, q: float) -> float:
    return p * math.log(p / q) + (1 - p) * math.log((1 - p) / (1 - q))


def binary_kl(p: float, q: float) -> float:
    return bernoulli_kl(p, q)


def as_fraction_string(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def main() -> None:
    # Exact blindness for both deterministic baseline policies; randomized
    # policies are their mixtures and therefore inherit equality.
    blindness = {}
    for action in (0, 1):
        law0 = baseline_law(0, action)
        law1 = baseline_law(1, action)
        assert law0 == law1
        blindness[str(action)] = {
            f"A={a},R={r}": as_fraction_string(prob)
            for (a, r), prob in sorted(law0.items())
        }

    exposed0 = exposed_reward_law(0)
    exposed1 = exposed_reward_law(1)
    assert exposed0 != exposed1
    assert exposed0[1] == Fraction(1, 2)
    assert exposed1[1] == 1 - ETA

    values = architecture_values()
    scores = {
        theta: {
            "phi_0": vals["phi_0"],
            "phi_1": vals["phi_1"] - MEMORY_COST,
        }
        for theta, vals in values.items()
    }
    assert scores["theta_0"]["phi_0"] > scores["theta_0"]["phi_1"]
    assert scores["theta_1"]["phi_1"] > scores["theta_1"]["phi_0"]

    first_n = None
    risks = []
    for n in range(1, MAX_N + 1):
        risk = exact_bayes_error(n)
        if n <= 12 or (first_n is None and float(risk) <= DELTA):
            risks.append({"n": n, "bayes_error": float(risk)})
        if first_n is None and float(risk) <= DELTA:
            first_n = n
    assert first_n is not None

    p0 = 0.5
    p1 = float(1 - ETA)
    lower0 = binary_kl(1 - DELTA, DELTA) / bernoulli_kl(p0, p1)
    lower1 = binary_kl(1 - DELTA, DELTA) / bernoulli_kl(p1, p0)
    gap = p1 - p0
    hoeffding_n = math.ceil(2 * math.log(1 / DELTA) / (gap * gap))

    summary = {
        "audit_type": "exact identity and finite-law check; not empirical validation",
        "parameters": {
            "eta": as_fraction_string(ETA),
            "memory_cost": as_fraction_string(MEMORY_COST),
            "delta": DELTA,
        },
        "baseline_retained_laws": blindness,
        "baseline_kl": 0.0,
        "exposed_success_probabilities": {
            "theta_0": as_fraction_string(exposed0[1]),
            "theta_1": as_fraction_string(exposed1[1]),
        },
        "architecture_values": {
            theta: {arch: as_fraction_string(v) for arch, v in vals.items()}
            for theta, vals in values.items()
        },
        "resource_adjusted_scores": {
            theta: {arch: as_fraction_string(v) for arch, v in vals.items()}
            for theta, vals in scores.items()
        },
        "selected_architectures": {"theta_0": "phi_0", "theta_1": "phi_1"},
        "conflict_world_repair_gain_after_cost": as_fraction_string(
            scores["theta_1"]["phi_1"] - scores["theta_1"]["phi_0"]
        ),
        "fixed_sample_equal_prior": {
            "first_n_with_bayes_error_at_most_delta": first_n,
            "reported_risks": risks,
        },
        "sequential_change_of_measure_lower_bounds": {
            "E_theta0_tau": lower0,
            "E_theta1_tau": lower1,
        },
        "midpoint_hoeffding_sufficient_n": hoeffding_n,
        "checks": {
            "all_baseline_policies_blind_by_mixture": True,
            "diagnostic_split_has_positive_information": True,
            "architecture_labels_are_opposite": True,
            "repair_has_positive_adjusted_gain_only_in_conflict_world": True,
        },
    }

    output_path = Path(__file__).with_name("summary.json")
    output_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
