# Marton Markovity companion verification package

This directory is the self-contained verification companion to Section 18.3
of *Elimination Geometry: From Local Optima to Global Realizability*, Version
1.6. It contains the exact rational instance, the saved interval certificates,
the independent checks, and the complete English companion note.

## Certified claim

For the exact three-input dense broadcast channel in `instance_exact.json`,
the package certifies

```text
G(non-Markov witness) - sup G(Markov candidate)
>= 2.71122439424797415393834e-11 > 0.
```

The result is a counterexample to the Gohari--Liu--Nair Markovity Conjecture,
subject to the published cardinality and deterministic-map reductions. It does
not refute Marton's achievable region or the separate Additivity Conjecture.

## Contents

- `FORMAL_CERTIFICATE.md`: human-readable statement, reductions, interval
  argument, component bounds, and trust boundary.
- `instance_exact.json`: exact rational channel, dual vector, and non-Markov
  witness.
- `orbit_*_certificate.json` and `superposition_certificate.json`: saved
  certificates for all six genuinely two-sided rectangular orbits and the two
  one-sided superposition bounds.
- `certificate_bundle.json`: combined exact bounds, source hashes, transcript
  hashes, and the final certified separation.
- `verify_bundle.py`: fast exact-rational verification of the saved bundle.
- `sanity_checks.py`: independent 120-digit witness evaluation, structural
  coverage check, and randomized interval-relaxation checks.
- `formal_interval_certificate.py`: slower replay verifier and certificate
  generator from the exact instance.
- `paper/`: the complete English companion manuscript in TeX and PDF form.
- `MANIFEST.sha256`: release-file integrity hashes; it intentionally excludes
  itself.

No cache directories, rendered page images, or LaTeX build intermediates are
part of this release snapshot.

## Environment

The shipped certificate was checked with Python 3.11.5, `gmpy2` 2.1.2 linked
against MPFR 4.0.2, and `mpmath` 1.3.0. The exact Python package versions are
recorded in `requirements.txt`.

## Fast verification

From this directory, run

```bash
python3 verify_bundle.py --output /tmp/marton_verified_bundle.json
python3 sanity_checks.py
shasum -a 256 -c MANIFEST.sha256
```

The first command validates all saved component certificates and reconstructs
the exact positive separation. The second independently checks the witness,
the 172 partial-support patterns, and 120 randomized affine relaxations. The
third checks that the release snapshot has not changed.

## Full interval replay

The proof trees can be regenerated from `instance_exact.json` rather than
trusted from the saved JSON certificates:

```bash
python3 formal_interval_certificate.py \
  --max-boxes 1000000 --progress-every 100000 \
  --output full_replay.json
```

The original six-orbit replay required about 22 CPU-minutes in total. An
individual orbit may be replayed separately, for example:

```bash
python3 formal_interval_certificate.py \
  --mapping 0,2,1,1 --max-boxes 1000000 \
  --output replay_0211.json
```

Replay outputs are intentionally not included in `MANIFEST.sha256`.

## Trust boundary

The external mathematical and numerical trust boundary is limited to:

1. the published cardinality and deterministic-map reduction;
2. the rectangular-map and one-sided data-processing reductions documented in
   `FORMAL_CERTIFICATE.md`;
3. correctly directed MPFR logarithms through `gmpy2`; and
4. the exact-rational tangent/secant and recursive box-cover implementation.

No floating-point optimizer, numerical Hessian, stationarity tolerance, or
uniqueness claim is used to certify the strict separation.
