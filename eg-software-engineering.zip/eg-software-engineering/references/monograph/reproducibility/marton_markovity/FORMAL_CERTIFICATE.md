# A Directed-Interval Counterexample Certificate for Marton Markovity

## 1. Certified claim

Let `log` denote the natural logarithm and set \(\lambda=1\).  For the exact
rational three-input broadcast channel and dual vector specified below, define

\[
G(p)=-\alpha H(Y)-(1-\alpha)H(Z)+I(U;Y)+I(V;Z)-I(U;V)
      +\mathbb E[a_X].
\]

The computer-assisted proof certifies the following strict bounds:

\[
\begin{aligned}
G(p_{\mathrm{ABCA}})
&\ge -1.07520631015658740221301,\\
\sup_{p:\,U-X-V}G(p)
&\le -1.07520631018369964615549.
\end{aligned}
\]

Consequently,

\[
G(p_{\mathrm{ABCA}})-\sup_{p:\,U-X-V}G(p)
\ge 2.71122439424797415393834\times10^{-11}>0.
\]

Thus no optimizer for this instance can satisfy \(U-X-V\).  Subject only to
the standard cardinality/deterministic-mapping theorem used in the statement
of the conjecture, this is a computer-assisted counterexample to the
Markovity Conjecture of Gohari--Liu--Nair.

The certified separation is smaller than the approximately \(1.07\times
10^{-5}\) numerical gap between the stationary ABCA witness and the best
numerically located rectangular solution.  This is expected: the proof tree
stops as soon as every upper bound falls strictly below the witness lower
bound, rather than spending additional computation to approximate the
rectangular optimum sharply.

## 2. Exact instance

All displayed finite decimals in this section are exact rationals.  In each
channel row, the third entry is defined as the exact complement of the first
two entries, not as an independently rounded decimal.

\[
\alpha=0.5390910636020981,
\qquad
(a_0,a_1,a_2)
=(0,-0.38384735442473183,-0.17505330254261003).
\]

The channel marginals are

\[
T_Y=\begin{pmatrix}
0.36951853194252404&0.3405540519828177&0.28992741607465826\\
0.7644062078066599&0.1243586697987073&0.1112351223946328\\
0.13431916897739554&0.4759630993912907&0.38971773163131376
\end{pmatrix},
\]

\[
T_Z=\begin{pmatrix}
0.4505557317847065&0.21189067443299553&0.33755359378229797\\
0.4099310202669974&0.009896427870306724&0.580172551862695876\\
0.2853422866067611&0.5630135058030781&0.1516442075901608
\end{pmatrix}.
\]

One legitimate dense broadcast channel is their conditional product,

\[
T(y,z\mid x)=T_Y(y\mid x)T_Z(z\mid x).
\]

Every entry is strictly positive.  The exact machine-readable fractions are
in `instance_exact.json` and are repeated in every component certificate.

## 3. Non-Markov witness

Take \(|U|=|V|=2\) and the deterministic map

\[
f(u,v)=\begin{pmatrix}0&1\\2&0\end{pmatrix}.
\]

In row-major order, use the exact rational probability vector

\[
\begin{aligned}
p_{00}&=0.000587496203024460836846347107816474063425697817587551938108378,\\
p_{01}&=0.0770366662163001055869931249615851671884377052275332967227301,\\
p_{10}&=0.0130832457279635243913988414691657482185168189690949868984089,\\
p_{11}&=0.909292591852711909184761686461432610529619777985784164440752622.
\end{aligned}
\]

The fourth number is defined as the exact complement of the first three.
The witness is not Markov: conditional on \(X=0\), both diagonal cells
\((0,0)\) and \((1,1)\) have positive probability, while both off-diagonal
cells have probability zero.  This conditional support cannot be a product
of its two nondegenerate marginals.

Using 192-bit outward-rounded MPFR logarithms, the verifier obtains an
interval for the witness of width

\[
1.66313140867940407712785\times10^{-57}.
\]

Its rigorous lower endpoint is the first bound in Section 1.

## 4. Why the finite list covers every Markov candidate

The cardinality theorem used in the 2025 conjecture manuscript permits

\[
|U|+|V|\le |X|+1=4
\]

and permits \(X\) to be a deterministic function of \((U,V)\).  Thus the
only maximal cardinality splits are \((2,2),(3,1),(1,3)\); all smaller splits
are contained in these cases.

For a dense channel, \(U-X-V\) together with deterministic \(X=f(U,V)\)
forces the cells carrying each input symbol to form a Cartesian rectangle.
Equivalently, as stated in Remark 2 of the conjecture manuscript, the
Markovity Conjecture asserts the existence of a maximizing rectangular map.

For a labeled \(2\times2\) grid with three input symbols, direct finite
enumeration gives 39 rectangular maps.  Independent relabeling of the two
values of \(U\) and of \(V\) leaves the optimization invariant and reduces
these to 15 orbits.

Nine orbits are one-sided.  If \(X=f(U)\), then

\[
I(V;Z)\le I(V;U)=I(U;V)
\]

by data processing, so their objective is bounded by the reveal-to-\(U\)
superposition problem.  The symmetric argument handles \(X=f(V)\).  The
constant maps are included.  The same two superposition problems also cover
the cardinality splits \((3,1)\) and \((1,3)\).

It remains to certify six genuinely two-sided orbit representatives:

\[
0012,\quad0102,\quad0121,\quad0122,\quad0211,\quad0212.
\]

As an additional boundary audit, the verifier enumerates all 172 partially
labeled support patterns in which every nonempty symbol support is a
rectangle.  Every one has a completion to one of the 39 full rectangular
maps.  Hence zero-probability cells do not create an omitted combinatorial
type.

## 5. Rigorous upper bounds on a simplex box

For \(\lambda=1\), elementary entropy identities give

\[
G=(1-\alpha)H(Y)+\alpha H(Z)-H(U,Y)-H(V,Z)+H(U,V)+\mathbb E[a_X].
\]

Every probability entering these entropies is affine in the cell masses.
Write

\[
h(t)=-t\log t,\qquad g(t)=t\log t,
\]

with \(h(0)=g(0)=0\).  On a rational box intersected with the probability
hyperplane, the minimum and maximum of every affine marginal are computed by
an exact rational linear program.

For each positive entropy term, concavity gives the global tangent upper
bound, for any rational \(c>0\),

\[
h(t)\le c+(-\log c-1)t.
\]

For each negative entropy term, convexity gives the secant upper bound for
\(g\) on its certified marginal interval \([\ell,u]\).  The resulting sum is
one affine function of the cell masses, whose maximum over the box-simplex
intersection is again evaluated exactly.

The only transcendental operations are logarithms.  Each logarithm is
evaluated by MPFR once with `MPFR_RNDD` and once with `MPFR_RNDU` at 192-bit
precision.  Those dyadic endpoints are converted to exact rationals.  Every
subsequent slope, intercept, box split, affine maximization, and comparison is
performed with `gmpy2.mpq` exact arithmetic.

## 6. Formal treatment of the boundary

Entropy curvature diverges at zero, so the proof does not ask a generic
three-dimensional box relaxation to resolve arbitrarily thin boundary
slabs.  Set

\[
\delta=2^{-25}.
\]

If one active atom has mass \(r\le\delta\), delete it and renormalize the
remaining distribution to \(q\).  The mixture inequalities

\[
(1-r)H(Q)+rH(R)
\le H((1-r)Q+rR)
\le h(r)+(1-r)H(Q)+rH(R)
\]

imply

\[
G(p)-G(q)
\le 2h(r)+r\bigl(2\log 6+\operatorname{range}(a)\bigr).
\]

The channel-row entropy contributions from the positive output entropies are
cancelled by those from the two negative joint entropies; dropping the
remaining nonpositive terms gives the displayed universal bound.  Since
\(h\) is increasing on \([0,\delta]\), the verifier uses

\[
\omega_\delta
=2h(\delta)+\delta\bigl(2\log 6+\operatorname{range}(a)\bigr)
\le 1.15110651614898763008\times10^{-6}.
\]

Every simplex is then covered by its \(\delta\)-interior plus the union of
these boundary slabs.  The same procedure is applied recursively to every
face.  All face endpoints and interior box endpoints are exact rationals, so
the recursion is a finite cover with no numerical gaps.

## 7. Component results

The following are conservative certified upper bounds, not estimates of the
true component optima.

| Component | Full-dimensional boxes | All boxes including faces | Certified upper bound |
|---|---:|---:|---:|
| `0012` | 215,711 | 259,949 | -1.07520631031222814389420 |
| `0102` | 65,488 | 89,445 | -1.07520632019360184882799 |
| `0121` | 5,545 | 7,195 | -1.07520652018658400972301 |
| `0122` | 3,228 | 4,533 | -1.07520684613587786915762 |
| `0211` | 656,940 | 679,714 | -1.07520631018369964615549 |
| `0212` | 346,872 | 369,702 | -1.07520631033991559635893 |
| superposition to \(U\) | 55 | 71 | -1.07520796893181037660640 |
| superposition to \(V\) | 30 | 41 | -1.07520799820420479815018 |

The total is 1,410,650 processed boxes.  The active global upper bound is the
`0211` component.  Exact rational bounds, transcript hashes, source hashes,
and the exact positive difference are stored in `certificate_bundle.json`.

## 8. Reproduction and independent checks

From this directory, the fast bundle verification is

```bash
python3 verify_bundle.py --output /tmp/marton_verified_bundle.json
```

Expected conclusion:

```text
VERIFIED: witness lower -1.07520631015658740221301e+0
> Markov upper -1.07520631018369964615549e+0
by 2.71122439424797415393834e-11
```

The complete proof can be reconstructed from the exact instance rather than
trusted from the saved component JSON files:

```bash
python3 formal_interval_certificate.py \
  --max-boxes 1000000 --progress-every 100000 \
  --output full_replay.json
```

On the machine used to create the certificate, the six orbit runs required
about 22 CPU-minutes in total.  Each orbit may also be replayed separately,
for example:

```bash
python3 formal_interval_certificate.py \
  --mapping 0,2,1,1 --max-boxes 1000000 \
  --output replay_0211.json
```

The independent sanity suite is

```bash
python3 sanity_checks.py
```

It checks the witness by a separate 120-digit implementation of the original
mutual-information formula, the 172-pattern structural completion, and 120
randomized affine-relaxation inequalities.  A fresh replay of all 15 face
subproblems for orbit `0122` reproduced every stored transcript hash and every
largest-pruned rational upper bound exactly.

## 9. Trust boundary and interpretation

The mathematical trust boundary consists of:

1. the published cardinality/deterministic-mapping reduction;
2. the elementary rectangular-map and data-processing reductions above;
3. correct implementation of MPFR directed logarithms;
4. the short exact-rational tangent/secant and box-cover verifier.

No floating-point optimizer, Hessian calculation, numerical stationarity
claim, or unproved uniqueness assertion is used in the certificate.

This result refutes the Markovity Conjecture for the stated exact dense
channel and exact dual vector.  It does **not** refute the Additivity
Conjecture, and it does not by itself show that Marton's inner bound is
strictly below broadcast-channel capacity.

## References

1. A. Gohari, Y. Liu, and C. Nair, *A Conjecture Regarding the Optimizers of
   Marton's Inner Bound for the Two-Receiver Broadcast Channel*, ISIT 2025
   manuscript, <https://chandra.ie.cuhk.edu.hk/pub/papers/BC/Mar-Con.pdf>.
2. V. Anantharam, A. Gohari, and C. Nair, *On the Evaluation of Marton's Inner
   Bound for Two-Receiver Broadcast Channels*, IEEE Transactions on
   Information Theory 65(2), 2019, <https://doi.org/10.1109/TIT.2018.2880241>.
