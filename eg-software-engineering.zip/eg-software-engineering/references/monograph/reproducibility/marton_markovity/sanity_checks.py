#!/usr/bin/env python3
"""Independent high-precision and randomized checks of the interval kernel."""

from __future__ import annotations

import random
from pathlib import Path

import mpmath as mp

from formal_interval_certificate import (
    DirectedLogs,
    Q,
    boundary_modulus,
    box_upper,
    build_map_model,
    load_instance,
    objective_interval,
    rectangular_orbits,
    restrict_model,
    structural_coverage_check,
    tighten_box,
)


HERE = Path(__file__).resolve().parent


def mpq(value: Q) -> mp.mpf:
    return mp.mpf(str(value.numerator)) / mp.mpf(str(value.denominator))


def entropy(probability) -> mp.mpf:
    return -mp.fsum(value * mp.log(value) for value in probability if value > 0)


def mutual_information(joint) -> mp.mpf:
    rows = [mp.fsum(row) for row in joint]
    cols = [mp.fsum(joint[i][j] for i in range(len(joint))) for j in range(len(joint[0]))]
    return mp.fsum(
        joint[i][j] * mp.log(joint[i][j] / (rows[i] * cols[j]))
        for i in range(len(joint))
        for j in range(len(joint[0]))
        if joint[i][j] > 0
    )


def original_objective(probability, mapping, instance) -> mp.mpf:
    probability = [mpq(item) for item in probability]
    ty = [[mpq(item) for item in row] for row in instance.ty]
    tz = [[mpq(item) for item in row] for row in instance.tz]
    alpha = mpq(instance.alpha)
    ax = [mpq(item) for item in instance.ax]
    p_x = [mp.mpf(0)] * 3
    p_uy = [[mp.mpf(0)] * 3 for _ in range(2)]
    p_vz = [[mp.mpf(0)] * 3 for _ in range(2)]
    p_uv = [[mp.mpf(0)] * 2 for _ in range(2)]
    for cell, mass in enumerate(probability):
        u, v = divmod(cell, 2)
        x = mapping[cell]
        p_x[x] += mass
        p_uv[u][v] = mass
        for y in range(3):
            p_uy[u][y] += mass * ty[x][y]
        for z in range(3):
            p_vz[v][z] += mass * tz[x][z]
    p_y = [mp.fsum(p_x[x] * ty[x][y] for x in range(3)) for y in range(3)]
    p_z = [mp.fsum(p_x[x] * tz[x][z] for x in range(3)) for z in range(3)]
    return (
        -alpha * entropy(p_y)
        -(1 - alpha) * entropy(p_z)
        + mutual_information(p_uy)
        + mutual_information(p_vz)
        - mutual_information(p_uv)
        + mp.fsum(p_x[x] * ax[x] for x in range(3))
    )


def main() -> None:
    mp.mp.dps = 120
    instance = load_instance(HERE / "instance_exact.json")
    logs = DirectedLogs(instance.precision_bits)
    model = build_map_model(instance.witness_mapping, instance)
    lower, upper = objective_interval(model, instance.witness_prob, logs)
    independent = original_objective(
        instance.witness_prob, instance.witness_mapping, instance
    )
    assert mpq(lower) <= independent <= mpq(upper)

    assert structural_coverage_check()["passed"]
    representatives, metadata = rectangular_orbits()
    assert len(representatives) == 15
    assert metadata["genuine_two_sided_orbits"] == 6
    delta = Q(1, 2 ** instance.cutoff_power)
    assert boundary_modulus(instance, logs, delta) > 0

    rng = random.Random(20260801)
    tested = 0
    genuine = [
        mapping for mapping in representatives
        if not (
            (mapping[0] == mapping[1] and mapping[2] == mapping[3])
            or (mapping[0] == mapping[2] and mapping[1] == mapping[3])
        )
    ]
    for mapping in genuine:
        map_model = build_map_model(mapping, instance)
        restricted = restrict_model(map_model, (0, 1, 2, 3))
        for _ in range(20):
            raw = [rng.randrange(1, 1000) for _ in range(4)]
            total = sum(raw)
            point = tuple(Q(item, total) for item in raw)
            radius = Q(1, 256)
            low = tuple(max(Q(0), item - radius) for item in point)
            high = tuple(min(Q(1), item + radius) for item in point)
            box = tighten_box(low, high)
            assert box is not None
            assert all(box[0][i] <= point[i] <= box[1][i] for i in range(4))
            _, point_upper = objective_interval(map_model, point, logs)
            relaxation_upper = box_upper(restricted, box[0], box[1], logs)
            assert point_upper <= relaxation_upper
            tested += 1

    print("PASS: independent 120-digit witness evaluation is enclosed")
    print("PASS: 172 partial Markov support patterns have rectangular completions")
    print(f"PASS: {tested} randomized affine-relaxation checks")
    print("witness:", mp.nstr(independent, 60))
    print("interval width:", mp.nstr(mpq(upper - lower), 8))


if __name__ == "__main__":
    main()
