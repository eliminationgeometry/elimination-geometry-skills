#!/usr/bin/env python3
"""Directed-rounding certificate for a counterexample to Marton Markovity.

This program has a deliberately small trusted numerical core:

* every input is parsed as an exact rational ``gmpy2.mpq``;
* every transcendental operation is one MPFR logarithm evaluated once with
  RoundDown and once with RoundUp;
* all subsequent tangent/secant construction, affine maximization, simplex
  splitting, and comparisons are exact rational arithmetic.

The certificate proves that the displayed non-Markov ABCA witness has value
strictly larger than every Markov candidate.  The latter reduce, using the
cardinality theorem |U|+|V| <= |X|+1, to the 2x2 rectangular structures and
the two 3x1/1x3 superposition structures.

All logarithms are natural.  This is a verifier as well as a generator: a
rerun from the exact JSON instance reconstructs the complete deterministic
branch-and-bound proof and its transcript digest.
"""

from __future__ import annotations

import argparse
import hashlib
import heapq
import itertools
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import gmpy2


Q = gmpy2.mpq
R = gmpy2.mpfr


def q(value=0) -> Q:
    """Parse a value as an exact rational, with decimals interpreted exactly."""
    if isinstance(value, Q):
        return value
    if isinstance(value, int):
        return Q(value)
    return Q(str(value))


def qsum(values: Iterable[Q]) -> Q:
    total = Q(0)
    for value in values:
        total += value
    return total


def dot(left: Sequence[Q], right: Sequence[Q]) -> Q:
    return qsum(a * b for a, b in zip(left, right))


def q_as_fraction(value: Q) -> str:
    return f"{gmpy2.numer(value)}/{gmpy2.denom(value)}"


def display(value: Q, digits: int = 20) -> str:
    """Human-readable approximation only; proof comparisons use exact mpq."""
    with gmpy2.local_context(gmpy2.context(precision=max(128, 4 * digits))):
        return format(R(value), f".{digits}e")


class DirectedLogs:
    """Correctly rounded MPFR logarithms with exact-rational endpoints."""

    def __init__(self, precision_bits: int):
        self.precision_bits = int(precision_bits)
        self.down = gmpy2.context(
            precision=self.precision_bits, round=gmpy2.RoundDown
        )
        self.up = gmpy2.context(
            precision=self.precision_bits, round=gmpy2.RoundUp
        )
        self._cache: dict[Q, tuple[Q, Q]] = {}

    def bounds(self, value: Q) -> tuple[Q, Q]:
        """Return rational lo,hi with lo <= log(value) <= hi."""
        if value <= 0:
            raise ValueError("logarithm argument must be positive")
        cached = self._cache.get(value)
        if cached is not None:
            return cached
        # log is increasing.  Rounding the input and operation in the same
        # outward direction therefore encloses log of the exact rational.
        with gmpy2.local_context(self.down):
            lower = gmpy2.log(R(value))
        with gmpy2.local_context(self.up):
            upper = gmpy2.log(R(value))
        result = (Q(lower), Q(upper))
        self._cache[value] = result
        return result

    def g_bounds(self, value: Q) -> tuple[Q, Q]:
        """Enclose g(t)=t log(t), with g(0)=0, at an exact rational t."""
        if value < 0:
            raise ValueError("negative probability")
        if value == 0:
            return Q(0), Q(0)
        lo, hi = self.bounds(value)
        return value * lo, value * hi

    def h_bounds(self, value: Q) -> tuple[Q, Q]:
        """Enclose h(t)=-t log(t), with h(0)=0."""
        lo, hi = self.g_bounds(value)
        return -hi, -lo


@dataclass(frozen=True)
class ExactInstance:
    alpha: Q
    ax: tuple[Q, ...]
    ty: tuple[tuple[Q, ...], ...]
    tz: tuple[tuple[Q, ...], ...]
    witness_mapping: tuple[int, ...]
    witness_prob: tuple[Q, ...]
    precision_bits: int
    cutoff_power: int


def complemented_rows(first_two: Sequence[Sequence[str]]) -> tuple[tuple[Q, ...], ...]:
    rows = []
    for row in first_two:
        a, b = (q(item) for item in row)
        c = Q(1) - a - b
        if min(a, b, c) <= 0:
            raise ValueError(f"channel row is not strictly positive: {row}")
        rows.append((a, b, c))
    return tuple(rows)


def load_instance(path: Path) -> ExactInstance:
    raw = json.loads(path.read_text())
    first_three = tuple(q(item) for item in raw["witness_first_three_probabilities"])
    last = Q(1) - qsum(first_three)
    witness = first_three + (last,)
    if min(witness) <= 0 or qsum(witness) != 1:
        raise ValueError("invalid rational witness")
    instance = ExactInstance(
        alpha=q(raw["alpha"]),
        ax=tuple(q(item) for item in raw["a_x"]),
        ty=complemented_rows(raw["t_y_first_two"]),
        tz=complemented_rows(raw["t_z_first_two"]),
        witness_mapping=tuple(int(item) for item in raw["witness_mapping_row_major"]),
        witness_prob=witness,
        precision_bits=int(raw["interval_precision_bits"]),
        cutoff_power=int(raw["boundary_cutoff_power"]),
    )
    if not (Q(0) < instance.alpha < Q(1)):
        raise ValueError("alpha must lie in (0,1)")
    if len(instance.ax) != 3 or len(instance.ty) != 3 or len(instance.tz) != 3:
        raise ValueError("this certificate expects three input symbols")
    return instance


@dataclass(frozen=True)
class Term:
    weight: Q
    coeff: tuple[Q, ...]
    name: str


@dataclass(frozen=True)
class Model:
    name: str
    coordinate_count: int
    h_terms: tuple[Term, ...]
    g_terms: tuple[Term, ...]
    linear_lower: tuple[Q, ...]
    linear_upper: tuple[Q, ...]
    metadata: tuple


def entropy_of_exact_distribution(
    prob: Sequence[Q], logs: DirectedLogs
) -> tuple[Q, Q]:
    lower = Q(0)
    upper = Q(0)
    for value in prob:
        lo, hi = logs.h_bounds(value)
        lower += lo
        upper += hi
    return lower, upper


def build_map_model(mapping: Sequence[int], instance: ExactInstance) -> Model:
    mapping = tuple(int(x) for x in mapping)
    if len(mapping) != 4:
        raise ValueError("a 2x2 mapping needs four entries")
    py = [tuple(instance.ty[mapping[i]][y] for i in range(4)) for y in range(3)]
    pz = [tuple(instance.tz[mapping[i]][z] for i in range(4)) for z in range(3)]
    puy = []
    for u in range(2):
        for y in range(3):
            puy.append(tuple(
                instance.ty[mapping[i]][y] if i // 2 == u else Q(0)
                for i in range(4)
            ))
    pvz = []
    for v in range(2):
        for z in range(3):
            pvz.append(tuple(
                instance.tz[mapping[i]][z] if i % 2 == v else Q(0)
                for i in range(4)
            ))
    identity = [tuple(Q(int(i == j)) for i in range(4)) for j in range(4)]
    h_terms = (
        tuple(Term(Q(1) - instance.alpha, coeff, f"Y{j}") for j, coeff in enumerate(py))
        + tuple(Term(instance.alpha, coeff, f"Z{j}") for j, coeff in enumerate(pz))
        + tuple(Term(Q(1), coeff, f"UV{j}") for j, coeff in enumerate(identity))
    )
    g_terms = (
        tuple(Term(Q(1), coeff, f"UY{j}") for j, coeff in enumerate(puy))
        + tuple(Term(Q(1), coeff, f"VZ{j}") for j, coeff in enumerate(pvz))
    )
    linear = tuple(instance.ax[x] for x in mapping)
    return Model(
        name="map_" + "".join(str(x) for x in mapping),
        coordinate_count=4,
        h_terms=h_terms,
        g_terms=g_terms,
        linear_lower=linear,
        linear_upper=linear,
        metadata=("map", mapping),
    )


def build_superposition_model(
    reveal_to: str, instance: ExactInstance, logs: DirectedLogs
) -> Model:
    """Build the |U|,|V|=(3,1) or (1,3) objective over p_X."""
    if reveal_to not in ("u", "v"):
        raise ValueError(reveal_to)
    if reveal_to == "u":
        # (1-a)[H(Y)-H(Z)] + E[a_X-H(T_Y(.|X))].
        h_rows = instance.ty
        h_terms = tuple(
            Term(Q(1) - instance.alpha,
                 tuple(instance.ty[x][y] for x in range(3)), f"Y{y}")
            for y in range(3)
        )
        g_terms = tuple(
            Term(Q(1) - instance.alpha,
                 tuple(instance.tz[x][z] for x in range(3)), f"Z{z}")
            for z in range(3)
        )
    else:
        # a[H(Z)-H(Y)] + E[a_X-H(T_Z(.|X))].
        h_rows = instance.tz
        h_terms = tuple(
            Term(instance.alpha,
                 tuple(instance.tz[x][z] for x in range(3)), f"Z{z}")
            for z in range(3)
        )
        g_terms = tuple(
            Term(instance.alpha,
                 tuple(instance.ty[x][y] for x in range(3)), f"Y{y}")
            for y in range(3)
        )
    linear_lower = []
    linear_upper = []
    for x, row in enumerate(h_rows):
        h_lo, h_hi = entropy_of_exact_distribution(row, logs)
        linear_lower.append(instance.ax[x] - h_hi)
        linear_upper.append(instance.ax[x] - h_lo)
    return Model(
        name=f"superposition_reveal_{reveal_to}",
        coordinate_count=3,
        h_terms=h_terms,
        g_terms=g_terms,
        linear_lower=tuple(linear_lower),
        linear_upper=tuple(linear_upper),
        metadata=("superposition", reveal_to),
    )


def objective_interval(
    model: Model, probability: Sequence[Q], logs: DirectedLogs
) -> tuple[Q, Q]:
    probability = tuple(probability)
    if len(probability) != model.coordinate_count or qsum(probability) != 1:
        raise ValueError("probability vector has wrong dimension or sum")
    lower = dot(model.linear_lower, probability)
    upper = dot(model.linear_upper, probability)
    for term in model.h_terms:
        value = dot(term.coeff, probability)
        lo, hi = logs.h_bounds(value)
        lower += term.weight * lo
        upper += term.weight * hi
    for term in model.g_terms:
        value = dot(term.coeff, probability)
        lo, hi = logs.g_bounds(value)
        lower += term.weight * lo
        upper += term.weight * hi
    return lower, upper


def feasible_box(low: Sequence[Q], high: Sequence[Q]) -> bool:
    return qsum(low) <= 1 <= qsum(high) and all(a <= b for a, b in zip(low, high))


def tighten_box(
    low: Sequence[Q], high: Sequence[Q]
) -> tuple[tuple[Q, ...], tuple[Q, ...]] | None:
    low = list(low)
    high = list(high)
    if not feasible_box(low, high):
        return None
    # Bounds consistency for sum_i p_i=1.  Iteration reaches the elementary
    # interval hull; all arithmetic is exact rational.
    while True:
        changed = False
        total_low = qsum(low)
        total_high = qsum(high)
        for i in range(len(low)):
            new_high = min(high[i], Q(1) - (total_low - low[i]))
            new_low = max(low[i], Q(1) - (total_high - high[i]))
            if new_high < new_low:
                return None
            if new_high != high[i] or new_low != low[i]:
                high[i] = new_high
                low[i] = new_low
                changed = True
        if not changed:
            break
    if not feasible_box(low, high):
        return None
    return tuple(low), tuple(high)


def linear_extreme(
    coeff: Sequence[Q], low: Sequence[Q], high: Sequence[Q], maximize: bool
) -> Q:
    """Exact LP over a box intersected with the probability hyperplane."""
    point = list(low)
    capacity = Q(1) - qsum(point)
    order = sorted(range(len(coeff)), key=lambda i: coeff[i], reverse=maximize)
    for i in order:
        if capacity == 0:
            break
        increase = min(high[i] - point[i], capacity)
        point[i] += increase
        capacity -= increase
    if capacity != 0:
        raise ArithmeticError("infeasible box passed to linear program")
    return dot(coeff, point)


def restrict_coeff(coeff: Sequence[Q], active: Sequence[int]) -> tuple[Q, ...]:
    return tuple(coeff[i] for i in active)


def nonzero(coeff: Sequence[Q]) -> bool:
    return any(item != 0 for item in coeff)


@dataclass(frozen=True)
class RestrictedModel:
    h_terms: tuple[Term, ...]
    g_terms: tuple[Term, ...]
    linear_upper: tuple[Q, ...]


def restrict_model(model: Model, active: Sequence[int]) -> RestrictedModel:
    h_terms = []
    for term in model.h_terms:
        coeff = restrict_coeff(term.coeff, active)
        if nonzero(coeff):
            h_terms.append(Term(term.weight, coeff, term.name))
    g_terms = []
    for term in model.g_terms:
        coeff = restrict_coeff(term.coeff, active)
        if nonzero(coeff):
            g_terms.append(Term(term.weight, coeff, term.name))
    return RestrictedModel(
        h_terms=tuple(h_terms),
        g_terms=tuple(g_terms),
        linear_upper=restrict_coeff(model.linear_upper, active),
    )


def scalar_g_line_upper(
    low: Q, high: Q, logs: DirectedLogs
) -> tuple[Q, Q]:
    """Return b,s such that t log t <= b+s*t on [low,high]."""
    if low < 0 or high < low:
        raise ValueError("invalid scalar interval")
    if high == 0:
        return Q(0), Q(0)
    if low == high:
        _, g_upper = logs.g_bounds(low)
        return g_upper, Q(0)
    if low == 0:
        _, log_high = logs.bounds(high)
        return Q(0), log_high
    gl_lower, gl_upper = logs.g_bounds(low)
    gh_lower, gh_upper = logs.g_bounds(high)
    width = high - low
    slope_lower = (gh_lower - gl_upper) / width
    slope_upper = (gh_upper - gl_lower) / width
    intercept_upper = gl_upper - slope_lower * low
    return intercept_upper, slope_upper


def box_upper(
    restricted: RestrictedModel,
    low: Sequence[Q],
    high: Sequence[Q],
    logs: DirectedLogs,
) -> Q:
    """Rigorous affine upper bound for one simplex box."""
    intercept = Q(0)
    linear = list(restricted.linear_upper)

    for term in restricted.h_terms:
        t_low = linear_extreme(term.coeff, low, high, maximize=False)
        t_high = linear_extreme(term.coeff, low, high, maximize=True)
        if t_high == 0:
            continue
        center = (t_low + t_high) / 2
        if center == 0:
            center = t_high / 2
        log_lower, _ = logs.bounds(center)
        # h(t) <= center + (-log(center)-1)t.  Replacing the slope by
        # its upper endpoint preserves the inequality because t>=0.
        slope_upper = -log_lower - 1
        intercept += term.weight * center
        for i, coefficient in enumerate(term.coeff):
            linear[i] += term.weight * slope_upper * coefficient

    for term in restricted.g_terms:
        t_low = linear_extreme(term.coeff, low, high, maximize=False)
        t_high = linear_extreme(term.coeff, low, high, maximize=True)
        line_intercept, slope_upper = scalar_g_line_upper(t_low, t_high, logs)
        intercept += term.weight * line_intercept
        for i, coefficient in enumerate(term.coeff):
            linear[i] += term.weight * slope_upper * coefficient

    return intercept + linear_extreme(linear, low, high, maximize=True)


def update_digest(
    digest: "hashlib._Hash",
    tag: str,
    active: Sequence[int],
    low: Sequence[Q],
    high: Sequence[Q],
    upper: Q,
) -> None:
    pieces = [tag, ",".join(map(str, active))]
    pieces.extend(q_as_fraction(item) for item in low)
    pieces.extend(q_as_fraction(item) for item in high)
    pieces.append(q_as_fraction(upper))
    digest.update(("|".join(pieces) + "\n").encode())


def certify_interior(
    model: Model,
    active: Sequence[int],
    target: Q,
    delta: Q,
    logs: DirectedLogs,
    max_boxes: int,
    progress_every: int = 0,
) -> dict:
    """Prove G<target on p_i>=delta by exact-rational box splitting."""
    active = tuple(active)
    k = len(active)
    if k == 1:
        probability = [Q(0)] * model.coordinate_count
        probability[active[0]] = Q(1)
        _, upper = objective_interval(model, probability, logs)
        return {
            "certified": upper < target,
            "dimension": 0,
            "root_upper": upper,
            "largest_pruned_upper": upper,
            "processed_boxes": 0,
            "remaining_boxes": int(upper >= target),
            "max_depth": 0,
            "transcript_sha256": hashlib.sha256(
                (model.name + str(active) + q_as_fraction(upper)).encode()
            ).hexdigest(),
        }

    upper_coordinate = Q(1) - (k - 1) * delta
    root = tighten_box([delta] * k, [upper_coordinate] * k)
    if root is None:
        raise ArithmeticError("empty interior region")
    restricted = restrict_model(model, active)
    root_upper = box_upper(restricted, root[0], root[1], logs)
    digest = hashlib.sha256()
    if root_upper < target:
        update_digest(digest, "root", active, root[0], root[1], root_upper)
        return {
            "certified": True,
            "dimension": k - 1,
            "root_upper": root_upper,
            "largest_pruned_upper": root_upper,
            "processed_boxes": 0,
            "remaining_boxes": 0,
            "max_depth": 0,
            "transcript_sha256": digest.hexdigest(),
        }

    heap: list[tuple[Q, int, int, tuple[Q, ...], tuple[Q, ...]]] = [
        (-root_upper, 0, 0, root[0], root[1])
    ]
    serial = 1
    processed = 0
    pruned = 0
    largest_pruned: Q | None = None
    max_depth = 0
    started = time.monotonic()
    while heap and processed < max_boxes:
        neg_upper, _, depth, low, high = heapq.heappop(heap)
        parent_upper = -neg_upper
        widths = tuple(b - a for a, b in zip(low, high))
        axis = max(range(k), key=lambda i: (widths[i], -i))
        if widths[axis] == 0:
            # A non-prunable singleton is a genuine failure, not an empty
            # queue.  Put it back so the final status cannot accidentally be
            # reported as certified.
            heapq.heappush(heap, (neg_upper, serial, depth, low, high))
            serial += 1
            break
        midpoint = (low[axis] + high[axis]) / 2
        for left in (True, False):
            child_low = list(low)
            child_high = list(high)
            if left:
                child_high[axis] = midpoint
            else:
                child_low[axis] = midpoint
            child = tighten_box(child_low, child_high)
            if child is None:
                continue
            child_upper = box_upper(restricted, child[0], child[1], logs)
            if child_upper < target:
                update_digest(digest, "leaf", active, child[0], child[1], child_upper)
                pruned += 1
                if largest_pruned is None or child_upper > largest_pruned:
                    largest_pruned = child_upper
            else:
                heapq.heappush(
                    heap,
                    (-child_upper, serial, depth + 1, child[0], child[1]),
                )
                serial += 1
                max_depth = max(max_depth, depth + 1)
        processed += 1
        if progress_every and processed % progress_every == 0:
            elapsed = time.monotonic() - started
            leading = -heap[0][0] if heap else largest_pruned
            print(
                f"progress {model.name} active={active} boxes={processed} "
                f"queue={len(heap)} upper={display(leading)} "
                f"elapsed={elapsed:.1f}s",
                flush=True,
            )

    largest_remaining = -heap[0][0] if heap else None
    return {
        "certified": not heap,
        "dimension": k - 1,
        "root_upper": root_upper,
        "largest_pruned_upper": largest_pruned,
        "largest_remaining_upper": largest_remaining,
        "processed_boxes": processed,
        "pruned_leaf_boxes": pruned,
        "remaining_boxes": len(heap),
        "max_depth": max_depth,
        "hit_max_boxes": bool(heap and processed >= max_boxes),
        "transcript_sha256": digest.hexdigest(),
    }


def result_jsonable(record: dict) -> dict:
    output = {}
    for key, value in record.items():
        if isinstance(value, Q):
            output[key + "_exact"] = q_as_fraction(value)
            output[key + "_display"] = display(value)
        elif isinstance(value, dict):
            output[key] = result_jsonable(value)
        elif isinstance(value, (tuple, list)):
            output[key] = [
                result_jsonable(item) if isinstance(item, dict)
                else (q_as_fraction(item) if isinstance(item, Q) else item)
                for item in value
            ]
        else:
            output[key] = value
    return output


def boundary_modulus(instance: ExactInstance, logs: DirectedLogs, delta: Q) -> Q:
    """Universal upper modulus for deleting one UV atom of mass <=delta.

    For p=(1-r)q+r e_i, entropy mixing and concavity give

      G(p)-G(q) <= 2 h(r) + r(2 log 6 + range(a)).

    The channel-row entropy terms cancel between the positive output
    entropies and the two negative joint entropies.  Since delta<1/e, h is
    increasing on [0,delta].  The same (looser) modulus also covers each
    superposition objective.
    """
    if not (Q(0) < delta < Q(1, 3)):
        raise ValueError("boundary cutoff must be small and positive")
    _, h_upper = logs.h_bounds(delta)
    _, log6_upper = logs.bounds(Q(6))
    potential_range = max(instance.ax) - min(instance.ax)
    return 2 * h_upper + delta * (2 * log6_upper + potential_range)


def certify_model(
    model: Model,
    witness_lower: Q,
    delta: Q,
    omega: Q,
    logs: DirectedLogs,
    max_boxes: int,
    progress_every: int,
) -> dict:
    """Recursively certify boundary faces and the delta-interior."""
    memo: dict[tuple[int, ...], dict] = {}
    full_size = model.coordinate_count

    def recurse(active: tuple[int, ...]) -> dict:
        if active in memo:
            return memo[active]
        removals = full_size - len(active)
        target = witness_lower - removals * omega
        child_records = []
        boundary_ok = True
        if len(active) > 1:
            for removed in active:
                child = tuple(i for i in active if i != removed)
                child_record = recurse(child)
                child_records.append({
                    "removed_coordinate": removed,
                    "active": child,
                    "certified": child_record["certified"],
                })
                boundary_ok = boundary_ok and child_record["certified"]
        interior = certify_interior(
            model=model,
            active=active,
            target=target,
            delta=delta,
            logs=logs,
            max_boxes=max_boxes,
            progress_every=progress_every,
        )
        certified = boundary_ok and interior["certified"]
        record = {
            "active": active,
            "target": target,
            "certified": certified,
            "boundary_children": child_records,
            "interior": interior,
        }
        memo[active] = record
        return record

    full = tuple(range(full_size))
    top = recurse(full)
    return {
        "name": model.name,
        "metadata": model.metadata,
        "certified": top["certified"],
        "full_active": full,
        "subproblem_count": len(memo),
        "subproblems": [memo[key] for key in sorted(memo, key=lambda x: (len(x), x))],
    }


def rectangle_subset(cells: set[int]) -> bool:
    if not cells:
        return True
    rows = {cell // 2 for cell in cells}
    cols = {cell % 2 for cell in cells}
    return cells == {2 * row + col for row in rows for col in cols}


def rectangular_mapping(mapping: Sequence[int]) -> bool:
    return all(
        rectangle_subset({i for i, value in enumerate(mapping) if value == x})
        for x in range(3)
    )


def one_sided_mapping(mapping: Sequence[int]) -> bool:
    """Whether X is a function of U alone or V alone on the full 2x2 grid."""
    mapping = tuple(mapping)
    depends_only_on_u = mapping[0] == mapping[1] and mapping[2] == mapping[3]
    depends_only_on_v = mapping[0] == mapping[2] and mapping[1] == mapping[3]
    return depends_only_on_u or depends_only_on_v


def rectangular_orbits() -> tuple[list[tuple[int, ...]], dict]:
    all_maps = [
        tuple(mapping)
        for mapping in itertools.product(range(3), repeat=4)
        if rectangular_mapping(mapping)
    ]
    orbits: dict[tuple[int, ...], list[tuple[int, ...]]] = {}
    for mapping in all_maps:
        matrix = (mapping[:2], mapping[2:])
        variants = (
            mapping,
            matrix[1] + matrix[0],
            (matrix[0][1], matrix[0][0], matrix[1][1], matrix[1][0]),
            (matrix[1][1], matrix[1][0], matrix[0][1], matrix[0][0]),
        )
        key = min(variants)
        orbits.setdefault(key, []).append(mapping)
    metadata = {
        "rectangular_labeled_maps": len(all_maps),
        "row_column_relabeling_orbits": len(orbits),
        "one_sided_orbits_covered_by_superposition": sum(
            one_sided_mapping(key) for key in orbits
        ),
        "genuine_two_sided_orbits": sum(
            not one_sided_mapping(key) for key in orbits
        ),
        "orbit_sizes": {"".join(map(str, key)): len(value) for key, value in orbits.items()},
    }
    return sorted(orbits), metadata


def structural_coverage_check() -> dict:
    """Finite proof that every partial Markov support has a rectangular completion."""
    full_maps = [
        tuple(mapping)
        for mapping in itertools.product(range(3), repeat=4)
        if rectangular_mapping(mapping)
    ]
    valid_partial = []
    failures = []
    for labels in itertools.product((-1, 0, 1, 2), repeat=4):
        # -1 denotes a zero-probability cell.  Under U-X-V and deterministic
        # X=f(U,V), each nonempty conditional support is a Cartesian rectangle.
        if not all(
            rectangle_subset({i for i, value in enumerate(labels) if value == x})
            for x in range(3)
        ):
            continue
        valid_partial.append(labels)
        if not any(
            all(label == -1 or label == mapping[i] for i, label in enumerate(labels))
            for mapping in full_maps
        ):
            failures.append(labels)
    return {
        "full_rectangular_maps": len(full_maps),
        "partial_rectangular_support_patterns": len(valid_partial),
        "patterns_without_rectangular_completion": len(failures),
        "passed": not failures,
    }


def exact_instance_payload(instance: ExactInstance) -> dict:
    return {
        "alpha": q_as_fraction(instance.alpha),
        "a_x": [q_as_fraction(x) for x in instance.ax],
        "t_y": [[q_as_fraction(x) for x in row] for row in instance.ty],
        "t_z": [[q_as_fraction(x) for x in row] for row in instance.tz],
        "witness_mapping": list(instance.witness_mapping),
        "witness_probability": [q_as_fraction(x) for x in instance.witness_prob],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--instance",
        type=Path,
        default=Path(__file__).with_name("instance_exact.json"),
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--mapping", help="one rectangular map, e.g. 1,1,0,2")
    parser.add_argument(
        "--superposition-only", action="store_true",
        help="run only the two 3x1/1x3 superposition structures",
    )
    parser.add_argument(
        "--include-superposition", action="store_true",
        help="with --mapping, also run the two superposition structures",
    )
    parser.add_argument("--max-boxes", type=int, default=2_000_000)
    parser.add_argument("--progress-every", type=int, default=0)
    parser.add_argument("--cutoff-power", type=int)
    args = parser.parse_args()

    started = time.monotonic()
    instance = load_instance(args.instance)
    cutoff_power = args.cutoff_power or instance.cutoff_power
    delta = Q(1, 2 ** cutoff_power)
    logs = DirectedLogs(instance.precision_bits)
    structural = structural_coverage_check()
    if not structural["passed"]:
        raise AssertionError("rectangular completion check failed")

    witness_model = build_map_model(instance.witness_mapping, instance)
    witness_lower, witness_upper = objective_interval(
        witness_model, instance.witness_prob, logs
    )
    omega = boundary_modulus(instance, logs, delta)
    representatives, orbit_metadata = rectangular_orbits()
    if args.mapping and args.superposition_only:
        raise ValueError("--mapping and --superposition-only are mutually exclusive")
    if args.mapping:
        selected = tuple(int(x) for x in args.mapping.split(","))
        if len(selected) != 4 or not rectangular_mapping(selected):
            raise ValueError("--mapping must be a rectangular four-cell map")
        representatives = [selected]
    elif args.superposition_only:
        representatives = []
    else:
        # If X=f(U), data processing gives I(V;Z)<=I(U;V), so this
        # structure is upper-bounded by the reveal-to-U superposition
        # objective.  The symmetric statement handles X=f(V).  Constants
        # are included.  Thus only six genuinely two-sided orbits require
        # the 2x2 interval calculation.
        representatives = [
            mapping for mapping in representatives
            if not one_sided_mapping(mapping)
        ]

    records = []
    for mapping in representatives:
        print(f"certifying map {mapping}", flush=True)
        record = certify_model(
            build_map_model(mapping, instance), witness_lower, delta, omega,
            logs, args.max_boxes, args.progress_every,
        )
        records.append(record)
        print(f"  certified={record['certified']}", flush=True)

    superposition_records = []
    if args.superposition_only or not args.mapping or args.include_superposition:
        for reveal_to in ("u", "v"):
            print(f"certifying superposition reveal_to={reveal_to}", flush=True)
            record = certify_model(
                build_superposition_model(reveal_to, instance, logs),
                witness_lower, delta, omega, logs, args.max_boxes,
                args.progress_every,
            )
            superposition_records.append(record)
            print(f"  certified={record['certified']}", flush=True)

    all_certified = (
        all(item["certified"] for item in records)
        and all(item["certified"] for item in superposition_records)
        and structural["passed"]
    )
    payload = {
        "certificate_version": 1,
        "claim": "strict_non_markov_witness_beats_every_markov_candidate",
        "verified": all_certified,
        "trusted_transcendental_backend": {
            "gmpy2_version": gmpy2.version(),
            "mpfr_version": gmpy2.mpfr_version(),
            "precision_bits": instance.precision_bits,
            "rounding_modes": ["MPFR_RNDD", "MPFR_RNDU"],
        },
        "exact_instance": exact_instance_payload(instance),
        "witness_lower": witness_lower,
        "witness_upper": witness_upper,
        "witness_interval_width": witness_upper - witness_lower,
        "boundary_cutoff": delta,
        "one_atom_boundary_modulus": omega,
        "structural_coverage": structural,
        "rectangular_orbits": orbit_metadata,
        "rectangular_records": records,
        "superposition_records": superposition_records,
        "elapsed_seconds": time.monotonic() - started,
    }
    rendered = json.dumps(result_jsonable(payload), indent=2, sort_keys=True)
    if args.output:
        args.output.write_text(rendered + "\n")
    print(rendered)
    if not all_certified:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
