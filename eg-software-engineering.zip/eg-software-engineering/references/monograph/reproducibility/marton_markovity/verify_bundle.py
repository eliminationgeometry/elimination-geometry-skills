#!/usr/bin/env python3
"""Check and summarize the component interval certificates.

This is a fast bundle checker.  It validates exact-rational consistency,
coverage, recursive boundary bounds, and the final strict separation.  The
slower ``formal_interval_certificate.py`` independently reconstructs every
branch-and-bound tree from the exact instance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path


HERE = Path(__file__).resolve().parent
ORBIT_TAGS = ("0012", "0102", "0121", "0122", "0211", "0212")
ORBIT_FILES = {
    tag: HERE / f"orbit_{tag}_certificate.json" for tag in ORBIT_TAGS
}
SUPERPOSITION_FILE = HERE / "superposition_certificate.json"
INSTANCE_FILE = HERE / "instance_exact.json"
REPLAY_VERIFIER = HERE / "formal_interval_certificate.py"


def frac(text: str) -> Fraction:
    return Fraction(text)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            digest.update(block)
    return digest.hexdigest()


def decimal(value: Fraction, digits: int = 24) -> str:
    with localcontext() as context:
        context.prec = digits
        return format(Decimal(value.numerator) / Decimal(value.denominator), "e")


def exact_key(payload: dict, key: str) -> Fraction:
    return frac(payload[key + "_exact"])


def validate_subproblems(record: dict, witness_lower: Fraction, omega: Fraction) -> None:
    full_size = len(record["full_active"])
    table = {tuple(item["active"]): item for item in record["subproblems"]}
    expected_active_sets = {
        subset
        for mask in range(1, 1 << full_size)
        for subset in [tuple(i for i in range(full_size) if mask & (1 << i))]
    }
    assert set(table) == expected_active_sets
    assert record["subproblem_count"] == len(expected_active_sets)
    for active, subproblem in table.items():
        assert subproblem["certified"] is True
        expected_target = witness_lower - (full_size - len(active)) * omega
        assert exact_key(subproblem, "target") == expected_target
        interior = subproblem["interior"]
        assert interior["certified"] is True
        assert interior["remaining_boxes"] == 0
        assert exact_key(interior, "largest_pruned_upper") < expected_target
        if len(active) == 1:
            assert subproblem["boundary_children"] == []
        else:
            children = {
                tuple(item["active"]): item for item in subproblem["boundary_children"]
            }
            expected_children = {
                tuple(item for item in active if item != removed)
                for removed in active
            }
            assert set(children) == expected_children
            assert all(item["certified"] is True for item in children.values())


def recursive_global_upper(record: dict, omega: Fraction) -> Fraction:
    table = {tuple(item["active"]): item for item in record["subproblems"]}
    memo: dict[tuple[int, ...], Fraction] = {}

    def solve(active: tuple[int, ...]) -> Fraction:
        if active in memo:
            return memo[active]
        interior = exact_key(table[active]["interior"], "largest_pruned_upper")
        candidates = [interior]
        if len(active) > 1:
            candidates.extend(
                solve(tuple(item for item in active if item != removed)) + omega
                for removed in active
            )
        memo[active] = max(candidates)
        return memo[active]

    return solve(tuple(record["full_active"]))


def processed_box_count(record: dict) -> int:
    return sum(item["interior"]["processed_boxes"] for item in record["subproblems"])


def component_summary(record: dict, omega: Fraction, witness_lower: Fraction) -> dict:
    upper = recursive_global_upper(record, omega)
    full_active = tuple(record["full_active"])
    full_record = next(
        item for item in record["subproblems"] if tuple(item["active"]) == full_active
    )
    return {
        "name": record["name"],
        "metadata": record["metadata"],
        "certified_upper_exact": f"{upper.numerator}/{upper.denominator}",
        "certified_upper_display": decimal(upper),
        "witness_lower_minus_upper_exact": (
            f"{(witness_lower - upper).numerator}/{(witness_lower - upper).denominator}"
        ),
        "witness_lower_minus_upper_display": decimal(witness_lower - upper),
        "full_dimensional_processed_boxes": full_record["interior"]["processed_boxes"],
        "all_face_processed_boxes": processed_box_count(record),
        "full_dimensional_max_depth": full_record["interior"]["max_depth"],
        "full_dimensional_transcript_sha256": full_record["interior"][
            "transcript_sha256"
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=HERE / "certificate_bundle.json"
    )
    args = parser.parse_args()

    paths = list(ORBIT_FILES.values()) + [SUPERPOSITION_FILE]
    for path in [INSTANCE_FILE, REPLAY_VERIFIER, *paths]:
        if not path.is_file():
            raise FileNotFoundError(path)
    payloads = {path: json.loads(path.read_text()) for path in paths}
    first = payloads[ORBIT_FILES[ORBIT_TAGS[0]]]
    common_keys = (
        "exact_instance",
        "witness_lower_exact",
        "witness_upper_exact",
        "boundary_cutoff_exact",
        "one_atom_boundary_modulus_exact",
        "trusted_transcendental_backend",
    )
    for path, payload in payloads.items():
        assert payload["verified"] is True, path
        assert payload["claim"] == first["claim"]
        for key in common_keys:
            assert payload[key] == first[key], (path, key)
        coverage = payload["structural_coverage"]
        assert coverage == {
            "full_rectangular_maps": 39,
            "partial_rectangular_support_patterns": 172,
            "passed": True,
            "patterns_without_rectangular_completion": 0,
        }
        orbits = payload["rectangular_orbits"]
        assert orbits["row_column_relabeling_orbits"] == 15
        assert orbits["one_sided_orbits_covered_by_superposition"] == 9
        assert orbits["genuine_two_sided_orbits"] == 6

    witness_lower = frac(first["witness_lower_exact"])
    witness_upper = frac(first["witness_upper_exact"])
    omega = frac(first["one_atom_boundary_modulus_exact"])
    assert witness_lower <= witness_upper

    records = []
    for tag, path in ORBIT_FILES.items():
        payload = payloads[path]
        assert payload["superposition_records"] == []
        assert len(payload["rectangular_records"]) == 1
        record = payload["rectangular_records"][0]
        assert record["name"] == f"map_{tag}"
        assert tuple(record["metadata"][1]) == tuple(map(int, tag))
        validate_subproblems(record, witness_lower, omega)
        records.append(record)

    super_payload = payloads[SUPERPOSITION_FILE]
    assert super_payload["rectangular_records"] == []
    assert {record["name"] for record in super_payload["superposition_records"]} == {
        "superposition_reveal_u",
        "superposition_reveal_v",
    }
    for record in super_payload["superposition_records"]:
        validate_subproblems(record, witness_lower, omega)
        records.append(record)

    summaries = [component_summary(record, omega, witness_lower) for record in records]
    component_uppers = {
        item["name"]: frac(item["certified_upper_exact"]) for item in summaries
    }
    maximizer_name = max(component_uppers, key=component_uppers.get)
    markov_upper = component_uppers[maximizer_name]
    separation = witness_lower - markov_upper
    assert separation > 0

    component_hashes = {path.name: sha256(path) for path in paths}
    bundle_digest = hashlib.sha256()
    for name, digest in sorted(component_hashes.items()):
        bundle_digest.update(f"{name}:{digest}\n".encode())

    output = {
        "bundle_version": 1,
        "verified": True,
        "claim": first["claim"],
        "proof_scope": {
            "lambda": "1",
            "input_alphabet_size": 3,
            "rectangular_labeled_maps": 39,
            "row_column_orbits": 15,
            "genuine_two_sided_interval_orbits": 6,
            "one_sided_orbits_covered_by_data_processing": 9,
            "superposition_structures": 2,
        },
        "logical_inputs": [
            "The cardinality reduction |U|+|V|<=|X|+1 and deterministic X=f(U,V).",
            "For dense channels, Markovity U-X-V implies a rectangular mapping.",
            "If X=f(U), then I(V;Z)<=I(U;V); symmetrically for X=f(V).",
            "The interval inequalities and recursive simplex cover implemented by the replay verifier.",
        ],
        "trusted_numerics": first["trusted_transcendental_backend"],
        "instance_file": INSTANCE_FILE.name,
        "instance_sha256": sha256(INSTANCE_FILE),
        "replay_verifier_file": REPLAY_VERIFIER.name,
        "replay_verifier_sha256": sha256(REPLAY_VERIFIER),
        "component_sha256": component_hashes,
        "component_hash_bundle_sha256": bundle_digest.hexdigest(),
        "witness_lower_exact": first["witness_lower_exact"],
        "witness_lower_display": decimal(witness_lower),
        "witness_upper_exact": first["witness_upper_exact"],
        "witness_upper_display": decimal(witness_upper),
        "witness_interval_width_display": decimal(witness_upper - witness_lower),
        "markov_global_upper_exact": f"{markov_upper.numerator}/{markov_upper.denominator}",
        "markov_global_upper_display": decimal(markov_upper),
        "active_global_upper_component": maximizer_name,
        "certified_separation_exact": f"{separation.numerator}/{separation.denominator}",
        "certified_separation_display": decimal(separation),
        "total_processed_boxes": sum(item["all_face_processed_boxes"] for item in summaries),
        "components": summaries,
    }
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(
        "VERIFIED: witness lower", decimal(witness_lower),
        "> Markov upper", decimal(markov_upper),
        "by", decimal(separation),
    )
    print("bundle:", args.output)


if __name__ == "__main__":
    main()
