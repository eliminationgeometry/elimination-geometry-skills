# Manuscript Status: Version 1.9

## Complete at book level

- mission centered on structural realizability under shared deployment;
- three-level distinction among local solvability, global realizability, and finite-sample certifiability;
- 27 chapters in 8 parts;
- 37 formal-result families with complete chapter-local proof coverage; this is not a
  count of independent original contributions;
- 42 complete proof environments;
- 37 assumption guides and 37 proof roadmaps;
- 86 exercises;
- 20 chapter-local proof appendices and 7 global technical appendices;
- consistent OALI/OAI terminology;
- controlled glossary and thematic index;
- all 121 numbered section openings audited for a coherent transition into
  their first formal or expository object, with eight targeted repairs;
- all 37 formal-result families audited for provenance and contribution in one
  complete Appendix G ledger, with eight Part-end historical and conceptual
  comparisons;
- four running laboratory families, including an explicitly incomplete MNIST
  one-pass/local-refinement audit, an equal-information/equal-compute digits
  control upgrade, a preserved WDBC frozen rejection, and a patient-level
  diabetes confirmation accepted on all 12 predeclared gates;
- clean XeLaTeX release build with no unresolved citations,
  references, or overfull boxes after final verification; this environment used the documented
  Times-compatible fallback because newtx was unavailable;
- all 11 numbered figures visually audited at release resolution, with the
  affected labels, arrows, braces, spacing, and print-scale legibility repaired;
- a deterministic Chapter 23 radical-loop code-path audit and Chapter 24
  real-benchmark/analytic/synthetic reproducibility materials, with their
  evidential scopes stated separately.
- a flagship-learning-theorem feasibility attack showing that finite
  partial-domain transport alone reduces to masked permutation/CSP structure;
  its exact sparse-detection seed and verification code are retained as a
  stopping-rule audit, not added to the 37-result proof-coverage count.
- a second flagship feasibility attack showing that operationally exposed
  memory conflict is either zero-information impossibility or controlled
  sequential testing under a resettable diagnostic contract; its exact
  two-world audit is likewise excluded from the 37-result count.
- a completed result-level Gibbs audit that reclassifies the Hamiltonian
  rigidity statement as a Jenčová--Petz sufficiency/factorization
  specialization rather than an originality candidate.
- a complete proof of the active-set Jacobian conflict/native-loss
  saturation/repair-depth family, a dated priority audit coding it `O`, and a
  fit-free post-confirmation theorem-alignment calculation on the sealed
  diabetes artifacts.  The final proof audit uses declared perturbation
  subspaces, closes the `q=0` depth branch, restricts the architecture-change
  initializer to the ruled-out one-pass class, and exactly recertifies every
  numerical KKT center before constructing a radius.

## Preserved mathematical corrections

All theorem-interface corrections introduced in Version 1.2 remain in force, including validity-before-obstruction ordering, corrected transport normalization, common-witness quantifiers, certificate-resolution boundaries, and proof/source mappings.

The current internal AI review pass additionally makes the Chapter 7 accepted-descent and stationarity hypotheses executable, declares the Chapter 8 compact-support Hilbert geometry and Bernstein-function gates, corrects the Chapter 9 square orientation and fiberwise touching quantifiers, and separates the Chapter 21 necessary lower bounds from its conditional common-witness authorization gate.  It is not independent external referee verification.

The follow-up pass makes the Chapter 5 and 6 local geometric interfaces
executable, defines the Chapter 16 path and Chapter 23 sampling parameters,
removes the duplicate Chapter 19 roadmap, corrects descriptive metadata, and
hardens both release scripts against missing bibliography or index tools.

The response to the internal AI Review R1 additionally restores classical and
companion attribution at the point of use; strengthens the Chapter 7
exactification converse and approximate-oracle interface; removes the
extended-real subtraction hazards in Chapters 10 and 16; repairs the typed
tower, persistent-atlas, common-event, and held-out-comparison contracts; and
normalizes the affected notation and index entries.

The subsequent section-opening pass preserves the many direct openings that
already identify their object, while adding explicit handoffs before the
table in Section 4.6, the condition/theorem interface in Section 7.2, the
algorithm in Section 7.4, the definition in Section 11.2, and imported-result
boxes in Sections 8.3, 13.3, 18.2, and 25.2.

The provenance pass separates complete proof status from priority.  It uses
five explicit audit classes in a single 37-row Appendix G ledger, together
with Part-end comparisons with the closest historical and conceptual
lineages.  The Gibbs result-level audit is now closed as a Jenčová--Petz
sufficiency/factorization specialization.  The new active-set depth row
remains an unresolved priority candidate and is not presented as
independently established originality.

## Still required before publisher submission

1. An independent referee pass if publisher policy or publication claims require verification beyond the internal AI R1 review and response.
2. Author/referee adjudication of the conservative provenance labels and final bibliography permissions.
3. Publisher trim size, typography, permissions, and figure decisions.
4. Author-approved affiliations, acknowledgments, funding, and permissions.
5. External-person or external-institution replication of the frozen
   architecture-repair chain; the diabetes case is patient-level and
   scientific-domain, but its acceptor remains within the project.
6. Independent proof and priority review of the active-set depth family before
   any originality claim. Signed cycles, finite partial domains, and
   operational exposure alone remain failed routes.
7. A new prospectively frozen or external-person acceptance case whose gates
   directly use the conflict modulus, native-loss floor, uniform tolerance,
   and charged repair-depth budget. The current diabetes alignment is
   post-confirmation and cannot fill this role.

## Current quantitative status

- current Version 1.9 portable release PDF pages: 293;
- previous clean Version 1.7 publisher-font PDF pages: 270;
- parts: 8
- chapters: 27
- fully proved formal-result families: 37 (proof-coverage count)
- complete proof environments: 42
- exercises: 86
- figures: 11
- tables: 17
- bibliography entries: 248 (196 cited)

This is a serious research-circulation draft, not an independently certified or publisher-final edition.
