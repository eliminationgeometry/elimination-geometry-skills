# Literature Priority Notes — Version 1.6

The editorial rule is: **foundational or closest antecedent first; recent papers for adjacency; companion-manuscript claims only for results actually proved there.** The book should not imply priority merely by introducing a unified vocabulary.

## Result-level audit outcome

Appendix G now audits all 35 fully proved formal results under five distinct classes:
classical/imported (`C`), direct specialization or derived lemma (`S`),
source-program claimed increment without an exhaustive priority claim (`P`),
unresolved priority candidate (`O`), and book-level
synthesis/interface (`B`).  Appendix G is the single result-by-result
antecedent/increment ledger, and every Part ends with a historical and
conceptual comparison.

The count is a proof-coverage inventory, not a novelty count.  The
target-calling construction is an elementary augmentation argument; the
radical value is a quantitative winding corollary; and the evidence-slack
criterion is a short KL/max--min specialization.  The result-level audit of
universal Gibbs base-change rigidity is closed negatively for standalone
novelty: Jenčová--Petz's sufficient-coarse-graining factorization and quantum
exponential-family criterion imply it directly.  It is now coded `S`; no row
is coded `O`.  The `P` rows retain only narrow formulation claims. Complete
book proofs
establish correctness under the stated assumptions; they do not by themselves
establish novelty.

## Priority anchors used in the revised manuscript

- **Amortized inference / shared inference:** Cremer, Li & Duvenaud (2018) for the amortization gap; Margossian & Blei (2024) for conditions under which amortized VI can or cannot close that gap; Marino et al. (2018) for iterative refinement. These contextualize Chapters 1 and 22.
- **Risk for data-dependent classes:** Dupuis et al. (2024) is used at the random-set generalization interface, not as a structural-obstruction result.
- **Conic lift / extension complexity:** Yannakakis (1991) and Gouveia--Parrilo--Thomas (2013), with later conic factorization work, are cited before the book's admissibility gate in Chapter 10.
- **Rectangularity:** Iyengar (2005) and Nilim--El Ghaoui (2005) remain the classical robust-DP anchors; Goyal--Grand-Clément (2023) represents controlled departures. Recent multitask/transfer/memory papers are presented as adjacent modern applications, not as sources of the coordination theorem.
- **Topology / atlas:** classical degree/discriminant references precede modern topological-ML papers in Chapter 14; Schwarz (1961) is cited at the atlas/sectional-category interface in Chapter 15.
- **Rate--distortion:** Shannon (1959) and Cover--Thomas anchor Chapter 16. The book explicitly distinguishes objective-generated native distortion from a generic externally chosen fidelity criterion.
- **Operational semantics:** Milner (1977) and Plotkin (1977) anchor the full-abstraction analogy in Chapter 17.
- **Partial identification and statistical topology:** Manski; Kaido--Molinari--Stoye; and Fasy et al. anchor the relevant Chapter 19 interfaces.
- **Confidence sets and identified images:** Dufour (1997) is the direct
  antecedent for projecting one covered joint set through every declared map;
  Vogel (2008) is the closest random-optimization neighbor of the honest
  bracket.  The book treats *confidence world* as local terminology for an
  enriched covered population object, not a newly invented kind of confidence
  set.  Coverage alone is not a contraction or consistency theorem, and the
  empty-world/model-conflict state has an empty-confidence-set antecedent in
  Dufour.
- **Resolution / pure exploration:** Kaufmann et al., Garivier--Kaufmann, and subsequent partition-identification work anchor the max--min information argument in Chapter 20.
- **Synchronization / phase unwrapping:** Singer and related synchronization papers, together with classical phase-unwrapping work, anchor the algorithmic analogies in Chapter 23.
- **Quantum information:** Lindblad data processing and Petz recovery remain
  foundational; Jenčová--Petz's factorization and quantum-exponential-family
  sufficiency theorems are now cited as the direct result-level antecedents of
  the Chapter 25 Hamiltonian specialization.

## Chapters without external priority citations

Several chapters intentionally contain no external citation near their main definitions (for example Chapters 2, 6, 7, 11, and 12). In those chapters the book is defining its own typed interface or proving an internal result. Adding a generic citation would blur, rather than improve, priority. Adjacent literature is cited later at the point of actual conceptual overlap.
