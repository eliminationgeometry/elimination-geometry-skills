# Formal Result and Proof Map

The row order below is also the 1--37 audit order in Appendix G.  That
consolidated ledger distinguishes proof provenance from novelty: `C` =
classical/imported, `S` = direct specialization/derived,
`P` = possible narrow program-specific increment, `O` = unresolved
priority-audit candidate, and `B` = book synthesis/interface.  These codes do
not turn the inventory into 37 independent contributions.  The audit-code sequence
is:

`B S C C S P C S S C P P P P S P P P C C S P P C C C S S B B C S C S S B O`.

| Chapter | Class | Formal result | Complete proof file | Main source line |
|---:|:---:|---|---|---|
| 3 | B | Exact four-component risk identity | `chapter_appendices/ch03_proofs.tex` | EGML / book synthesis |
| 3 | S | Four-component certified learning bound | `chapter_appendices/ch03_proofs.tex` | EGML |
| 5 | C | Conjugate defect identity | `chapter_appendices/ch05_proofs.tex` | EG I |
| 6 | C | Tower associativity | `chapter_appendices/ch06_proofs.tex` | Foundations / COT |
| 7 | S | Jet exactification | `chapter_appendices/ch07_proofs.tex` | EG I |
| 7 | P | Converse exactification normal form | `chapter_appendices/ch07_proofs.tex` | EG II |
| 8 | C | CDF validity repair | `chapter_appendices/ch08_proofs.tex` | EG I |
| 9 | S | Flat elimination criterion | `chapter_appendices/ch09_proofs.tex` | EG II |
| 10 | S | Finite-complexity target-calling no-go | `chapter_appendices/ch10_proofs.tex` | Lift Complexity |
| 10 | C | Conic lift--factorization gate | `chapter_appendices/ch10_proofs.tex` | Lift Complexity / classical conic factorization |
| 10 | P | Visible quotient and lift-to-carrier transfer | `chapter_appendices/ch10_proofs.tex` | Lift Complexity / Resource-Constrained Architectures |
| 12 | P | Oracle-variation transport bound | `chapter_appendices/ch12_proofs.tex` | EOT |
| 13 | P | Rectangular Bellman and coordination-residual decomposition | `chapter_appendices/ch13_proofs.tex` | COT |
| 14 | P | Exact radical catastrophe tax | `chapter_appendices/ch14_proofs.tex` | Singular EG |
| 15 | S | Atlas saturation | `chapter_appendices/ch15_proofs.tex` | Singular EG / EGML |
| 16 | P | Architecture rate--distortion decomposition | `chapter_appendices/ch16_proofs.tex` | Resource-Constrained Architectures |
| 17 | P | Task-envelope isometry | `chapter_appendices/ch17_proofs.tex` | Operational Semantics |
| 17 | P | Contextual completion and full abstraction | `chapter_appendices/ch17_proofs.tex` | Operational Semantics |
| 18 | C | Soft conditional chain theorem | `chapter_appendices/ch18_proofs.tex` | EG III |
| 19 | C | Honesty and maximal decisiveness | `chapter_appendices/ch19_proofs.tex` | Statistical EG |
| 19 | S | Honest elimination bracket | `chapter_appendices/ch19_proofs.tex` | Statistical EG |
| 19 | P | Atlas interleaving and stable inverse | `chapter_appendices/ch19_proofs.tex` | Statistical EG |
| 19 | P | Common-deployment quantifier theorem | `chapter_appendices/ch19_proofs.tex` | Resource-Constrained Architectures / Statistical EG |
| 20 | C | Posterior credibility is not worldwise validity | `chapter_appendices/ch20_proofs.tex` | Certificate Statistics |
| 20 | C | Truth-map form of three-way honesty | `chapter_appendices/ch20_proofs.tex` | Certificate Statistics / Chapter 19 reduction |
| 20 | C | Worldwise resolution lower bound | `chapter_appendices/ch20_proofs.tex` | Certificate Statistics / sequential identification |
| 20 | S | Exact certificate preservation by slack | `chapter_appendices/ch20_proofs.tex` | Certificate Statistics |
| 20 | S | Recursive quotient and minimal exact state | `chapter_appendices/ch20_proofs.tex` | Certificate Statistics |
| 21 | B | Typed no-compensation | `chapter_appendices/ch21_proofs.tex` | EGML II / book synthesis |
| 21 | B | Typed architecture realization interface | `chapter_appendices/ch21_proofs.tex` | Resource-Constrained Architectures / book synthesis |
| 21 | C | Finite-library held-out improvement | `chapter_appendices/ch21_proofs.tex` | EGML / OALI workflow |
| 22 | S | Population improvement template | `chapter_appendices/ch22_proofs.tex` | OALI workflow / OAI prototype theory |
| 23 | C | Noisy partial-transport recovery | `chapter_appendices/ch23_proofs.tex` | OAI v0.5 |
| 23 | S | Cycle-space characterization | `chapter_appendices/ch23_proofs.tex` | OAI v0.5 |
| 25 | S | Universal Gibbs base-change rigidity | `chapter_appendices/ch25_proofs.tex` | Quantum EG / Jenčová--Petz sufficiency specialization |
| 19 | B | Deployment conflict under observational overlap and repair trichotomy | `chapter_appendices/ch19_proofs.tex` | Le Cam/Blackwell ingredients / book interface synthesis |
| 19 | O | Declared-subspace active-set Jacobian conflict, one-pass native-loss saturation, and sufficient proximal repair depth | `chapter_appendices/ch19_proofs.tex` | Parametric-QP active sets, sparse-encoder amortisation gaps, LISTA, and proximal-gradient ingredients; exact quantitative combination has unresolved priority |

## Reading convention

Every row has four layers in the chapter text: an assumption guide, the formal result, an interpretation/boundary box, and a proof roadmap. The file in the third column contains the complete book proof and any supporting lemma introduced for that proof. Imported classical theorems are cited rather than silently reproved.
