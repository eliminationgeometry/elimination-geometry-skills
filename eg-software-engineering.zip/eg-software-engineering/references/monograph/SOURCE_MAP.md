# Source-to-Book Crosswalk

| Source line | Main book destination |
|---|---|
| Elimination Geometry I | Chapters 2 and 5-8; native defect, P/G/X/V/C, exactification, graph-CDF/CRPS, and model-specific examples |
| Elimination Geometry II | Chapters 7-9 and boundary material in Chapter 26; exactification converse, probability-validity gates, integrability, and representation limits |
| Elimination Geometry III | Chapter 18; soft conditional chains, pushforward, base change, conditioning, and zero temperature |
| Foundations of Elimination Geometry | Chapters 2, 6, and 18; defect fibrations, obstruction towers, and interchange coherence |
| Elimination Obstruction Transfer | Chapters 11-12; second elimination, regular obstruction transfer, flow duality, and population thickening |
| Compositional Obstruction Transfer | Chapters 6, 13, and 18; rectangularity, coordination tax, architecture base change, and temperature limits |
| Singular Elimination Geometry | Chapters 14-15 and Appendix C; radical tax, degree/discriminant mechanisms, and atlas/quotient repair |
| Lift Complexity | Chapter 10; target-calling no-go, slack factorization, quotient reduction, and lift-complexity boundaries |
| Resource-Constrained Architectures | Chapters 10, 16, 19, and 21; target-visible extraction, carrier-decoder rate-distortion, common deployment, and typed realization |
| Exact Data Selection | Chapter 16; exact low-dimensional and budget-two selection frontiers, auxiliary-law elimination, and merge-split recovery |
| Operational Semantics | Chapter 17; task envelopes, context closure, full abstraction, and ordering curvature |
| Marton Markovity counterexample | Chapter 18; credit--semantic-tax identity, rectangular-switch frontier, and a certified positive Markov-architecture obstruction; exact verification package shipped under `reproducibility/marton_markovity/` |
| Statistical Elimination Geometry | Chapter 19; confidence worlds, honest frontier brackets, sparse model-selection procedures with pointwise oracle guarantees, conditional/shift-aware prediction, observational treatment-policy deployment, observational-overlap deployment conflict, and active-set depth separation |
| Certificate Statistics | Chapters 20-21; resolution complexity, evidence carriers, recursive state, and typed no-compensation |
| EGML | Chapters 1, 3, 11, and 21-24; four-component risk decomposition, ML positioning, OALI, and application protocols |
| EGML II | Chapters 20-22; typed carriers, non-compensation, adaptive learning interfaces, and routed-expert/external-memory instantiation |
| Classical integrability and learned-score literature | Chapter 9; local generative vector fields under density versus transport contracts, with Poincaré/Hodge ancestry and no new score-model theorem claim |
| OAI prototype theory and companion construction | Chapters 22-24; transport recovery, cycle audit, atlas construction, and synthetic validation; the radical loop has a shipped executable audit, while the multi-cycle illustration does not |
| Quantum Elimination Geometry | Chapter 25; Gibbs base-change rigidity, sectors, recoverability, and measurement limits |
| Chapter 24 reproducibility packages | Chapter 24; incomplete MNIST audit, digits R2 control upgrade, frozen WDBC rejection, accepted patient-level diabetes repair, and posterior-family/cytometry checks |

This crosswalk records intellectual provenance. The exposition, notation, examples, dependency order, and chapter numbering have been rewritten at book level.

## Proof provenance in Version 1.9

The 37 formal-result families inventoried in the book have chapter-local complete
proofs.  This is a proof-coverage count, not a novelty count. `PROOF_MAP.md`
records the source line and proof file for each result. Source manuscripts
remain authoritative for advanced results discussed but not formally
restated; the PDF marks those summaries with a `Source status` box.
