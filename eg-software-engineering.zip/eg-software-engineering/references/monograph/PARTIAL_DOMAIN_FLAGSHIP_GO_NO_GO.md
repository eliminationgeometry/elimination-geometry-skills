# Partial-domain transport as a flagship learning theorem: go/no-go attack

**Audit date:** 2026-08-12  
**Status:** no-go for partiality alone; the formerly open operational route is
now closed in a separate audit

## 1. Executive verdict

Finite partial-domain transport does create real local-to-global obstructions.
It can also create an additional sample price for deciding whether one chart
must be repaired.  Those facts are not enough to make it a new learning
theory.

The proposed flagship route fails its present originality gate for two
separate reasons.

1. Every finite system of partial bijections admits an exact encoding by
   total permutations on enlarged fibers together with validity masks.  Its
   global sections are therefore a finite binary constraint-satisfaction
   problem, and its repair problem is a masked synchronization or constraint
   deletion problem.
2. The smallest statistical experiment that genuinely distinguishes domain
   survival from ordinary permutation holonomy has a matching
   \(\Theta_q(\log |E|)\) architecture-selection threshold, but the experiment
   is exactly sparse anomalous-edge detection, equivalently testing a fixed
   repetition-code word against one corrupted coordinate.

Thus the desired phenomenon is nonempty, but its mathematical engine is not
new.  Adding native-loss terminology, a certificate, or an atlas decision
does not change that reduction.

The correct book-level action is:

- retain partial transports as a semantic and audit interface;
- retain the deterministic recovery and cycle-space results as scoped tools;
- do not promote partial-domain transport to the flagship learning theorem;
- require an additional operational observation constraint, intervention
  problem, or computational-statistical separation before reopening the
  route.

## 2. Deterministic reduction: partial maps are masked total permutations

Let \(G=(V,E)\) be a finite graph.  Vertex \(v\) has a finite fiber
\(\mathcal B_v\).  An oriented edge \(e=(u,v)\) carries a partial bijection

\[
T_e:D_e\subseteq\mathcal B_u\longrightarrow
R_e\subseteq\mathcal B_v,
\qquad |D_e|=|R_e|.
\]

A global section is \(s=(s_v)_{v\in V}\) satisfying
\(s_u\in D_e\) and \(T_e(s_u)=s_v\) on every edge.

### Proposition 1: exact masked-permutation totalization

There are finite enlarged fibers \(\widetilde{\mathcal B}_v\supseteq
\mathcal B_v\), all of a common cardinality \(Q\), and total bijections

\[
P_e:\widetilde{\mathcal B}_u\longrightarrow
\widetilde{\mathcal B}_v
\]

such that

\[
(x,y)\in\mathcal B_u\times\mathcal B_v,quad P_e(x)=y
\quad\Longleftrightarrow\quad
x\in D_e,quad T_e(x)=y.
\]

Consequently, original global sections are in bijection with solutions of the
total-permutation constraints

\[
P_e(s_u)=s_v,qquad e=(u,v),
\]

subject only to the unary validity masks \(s_v\in\mathcal B_v\).

#### Proof

Choose

\[
Q\ge
\max_{e=(u,v)}
\{\,|\mathcal B_u|+|\mathcal B_v|-|D_e|\,\}
\]

and pad every fiber to size \(Q\).  For a fixed edge, keep \(T_e\) on
\(D_e\).  Map every element of \(\mathcal B_u\setminus D_e\) injectively to
dummy elements at \(v\); enough such elements exist because

\[
Q-|\mathcal B_v|\ge |\mathcal B_u|-|D_e|.
\]

Map dummy elements at \(u\) onto
\(\mathcal B_v\setminus R_e\); again there are enough because

\[
Q-|\mathcal B_u|\ge |\mathcal B_v|-|R_e|.
\]

Complete the remaining dummy-to-dummy pairs arbitrarily.  This gives a total
bijection and ensures that an original label is sent to an original label
exactly on the graph of \(T_e\).  Therefore a masked solution of the total
system satisfies precisely the original partial constraints, and conversely.
\(\square\)

### Corollary 1: objective and repair preservation

Any loss on original sections is preserved exactly by assigning infinite loss
to dummy labels.  When all original losses are bounded, a finite penalty
larger than the largest possible original objective difference gives the same
argmin.  The construction applies simultaneously to every member of a finite
candidate repair family after taking the largest required \(Q\).

Hence a finite partial-transport architecture selector is an architecture
selector over total permutations plus unary masks.  Calling dummy completions
"the same structure" may be the right scientific semantics, but quotienting
them does not create a new statistical experiment.

## 3. Root propagation reduces global-section existence to a finite code

Fix a root \(r\) and a spanning tree.  For every root branch
\(k\in\mathcal B_r\), propagate \(k\) along the tree until a partial map is
undefined.  If propagation survives, check all chords.  Thus one root symbol
determines at most one global section.

The section-existence predicate is therefore

\[
\mathbf 1\{\mathcal S_r\ne\varnothing\}
=
\max_{k\in\mathcal B_r}
\mathbf 1\{k\text{ survives every tree path and satisfies every chord}\}.
\]

This is a union of at most \(|\mathcal B_r|\) finite constraint codes.  Atlas
repair by deleting seams or duplicating charts is a relaxation of those
constraints.  This observation does not make the computation trivial, but it
places the problem inside finite CSP, partial multi-matching, and structured
testing rather than outside them.

The neighboring literature already treats permutation synchronization,
cycle-consistent partial multi-matchings, and exact classification of clean
versus corrupted partial permutations.  The closest interfaces include
Pachauri--Kondor--Singh (2013), Bernard--Thunberg--Goncalves--Theobalt
(2019), and Li--Shi--Lerman (2022).  The present reduction is used only as a
no-go audit; no priority claim is attached to the elementary totalization.

## 4. A minimal partial-domain statistical experiment

The preceding reduction does not show that global compatibility has no
statistical price.  The following experiment gives it the strongest possible
chance.

Let \(G=C_L\) be a cycle with \(L\ge3\) edges and
\(\mathcal B_v=\{0,1\}\) at every vertex.  Edge \(e\) has a domain bit
\(z_e\in\{0,1\}\) and partial identity

\[
T_e^{z_e}:\{z_e\}\longrightarrow\{z_e\},
\qquad T_e^{z_e}(z_e)=z_e.
\]

The system has a global section if and only if all domain bits are equal.
Define its one-chart inconsistency obstruction by

\[
O_1(z)=min_{s\in\{0,1\}^V}
\frac1L\sum_{e=(u,v)}
\mathbf 1\{s_u\notin D_e\text{ or }T_e(s_u)\ne s_v\}.
\]

Consider

\[
H_0:z=0^L,
\qquad
H_{1,e}:z_e=1, z_f=0\text{ for }f\ne e,quad e=1,\ldots,L.
\]

Under \(H_0\), the one-chart obstruction is zero.  Under every \(H_{1,e}\),
every one-chart labeling violates at least one edge, and the constant-zero
labeling violates exactly the anomalous edge.  Therefore

\[
O_1(H_0)=0,
\qquad
O_1(H_{1,e})=\frac1L.
\]

A repair that isolates one exceptional edge and costs \(1/(2L)\) is the
resource-adjusted oracle under \(H_{1,e}\), while no repair is the oracle under
\(H_0\).  A wrong architecture decision has excess objective \(1/(2L)\).

On each edge observe \(m\) independent binary-symmetric-channel measurements

\[
X_{ej}=z_e\oplus W_{ej},
\qquad W_{ej}\sim\operatorname{Bernoulli}(q),quad 0<q<1/2.
\]

Write \(P_0=\operatorname{Bernoulli}(q)\) and
\(P_1=\operatorname{Bernoulli}(1-q)\).

### Theorem 2: the apparent structural price is sparse detection

Let \(\mathbb P_0\) be the complete-data law under \(H_0\), let
\(\mathbb P_e\) be the law under \(H_{1,e}\), and define the uniform mixture

\[
\mathbb Q=\frac1L\sum_{e=1}^L\mathbb P_e.
\]

Then

\[
\chi^2(\mathbb Q\|\mathbb P_0)
=
\frac{\{1+\chi^2(P_1\|P_0)\}^{m}-1}{L},
\]

where

\[
\chi^2(P_1\|P_0)
=\frac{(1-2q)^2}{q(1-q)}.
\]

Consequently, if

\[
\frac{\{1+\chi^2(P_1\|P_0)\}^{m}-1}{L}\le\frac14,
\]

every architecture selector has worst-case decision error at least \(3/8\)
over \(H_0,H_{1,1},\ldots,H_{1,L}\).

Conversely, edgewise majority vote followed by "repair iff any edge is
positive" has worst-case decision error at most

\[
L\exp(-mC_q),
\qquad
C_q=-\log\{2\sqrt{q(1-q)}\}.
\]

For fixed \(q\), constant-confidence architecture selection therefore has
the matching order

\[
m=\Theta_q(\log L).
\]

#### Proof

Let \(\ell_e\) be the likelihood ratio contributed by the \(m\) observations
on edge \(e\).  Under \(\mathbb P_0\), the variables \(\ell_e\) are independent,
\(\mathbb E_0\ell_e=1\), and

\[
\mathbb E_0\ell_e^2
=\{1+\chi^2(P_1\|P_0)\}^{m}.
\]

The mixture likelihood ratio is \(L^{-1}\sum_e\ell_e\).  Cross terms equal
one, so direct expansion gives the displayed chi-square identity.  The
inequality

\[
\operatorname{TV}(\mathbb Q,\mathbb P_0)
\le \frac12\sqrt{\chi^2(\mathbb Q\|\mathbb P_0)}
\]

and the equal-prior testing identity imply Bayes error at least \(3/8\).
Worst-case minimax error is at least this Bayes error.

For the upper bound, the error probability of majority vote on one edge is at
most \(\exp(-mC_q)\).  Under the null, a union bound controls all \(L\) false
alarms.  Under a one-edge alternative, failure to repair requires at least the
anomalous edge to be misclassified.  Taking the larger bound proves the
claim. \(\square\)

### Interpretation

This theorem meets three tempting flagship criteria:

- local edge difficulty is identical across possible anomaly locations;
- the architecture changes because common domain survival fails;
- deciding the global architecture costs \(\log L\) samples per edge, whereas
  classifying one prespecified edge at constant confidence costs only a
  constant number.

Nevertheless, the experiment is exactly testing a zero vector against a
one-sparse binary vector through independent noisy coordinates.  Equivalently,
it tests a fixed repetition-code word against one-coordinate corruption.
The additional price is a familywise multiple-testing or sparse-support
recovery price.  Partial transport supplies the interpretation, not a new
minimax mechanism.

## 5. Dummy-state kill test on the minimal experiment

For the singleton partial identity on \(\{0,1\}\), add one dummy state
\(\partial\).  Complete

\[
T^0:\{0\}\to\{0\}
\]

to the total permutation that fixes \(0\) and swaps \(1\) with \(\partial\).
Complete

\[
T^1:\{1\}\to\{1\}
\]

to the total permutation that fixes \(1\) and swaps \(0\) with \(\partial\).
Restrict deployed vertex labels to \(\{0,1\}\).  The original section problem
is recovered exactly.  Thus even the cleanest "undefined rather than moved"
example embeds into \(S_3\) synchronization with a validity mask.

Discarding the mask would indeed change the scientific meaning by allowing a
dummy global section.  Retaining the mask preserves the meaning and exposes
the classical reduction.  Therefore the semantic objection to dummy labels
does not rescue theorem-level originality.

## 6. Which flagship clauses survive?

| Required clause | Status | Reason |
|---|---:|---|
| intrinsic population obstruction | passes | global-section failure and the one-edge obstruction are exact |
| honest finite-sample certificate | passes in the seed | simultaneous edge tests give one |
| certificate changes architecture | passes in the seed | one chart versus one exceptional seam |
| no unnecessary repair | passes in the seed | familywise type-I control |
| repair consistency | passes in the seed | majority testing succeeds above \(\log L\) |
| matching structural lower bound | passes in rate | chi-square mixture lower bound gives \(\log L\) |
| nonreduction to known theory | **fails** | sparse testing/repetition-code membership and masked synchronization |
| task-level operational gain | absent | no downstream decision law has been specified |

This table explains why satisfying a theorem checklist is not sufficient.  A
complete theorem can still be a renamed classical problem.

## 7. Go/no-go decision

### Closed route

Do not pursue a flagship theorem whose only claimed source of novelty is one
or more of:

- data-dependent domains;
- partial bijections rather than permutations;
- missing branches carried through cycle compositions;
- a chart split triggered by global-section failure;
- a \(\log |E|\) exact-recovery threshold.

These remain useful modeling choices and may support a strong application,
but they do not establish a new general learning theory.

### Narrow route that was attacked next

Reopening the route requires an ingredient not preserved by the masked-CSP
encoding.  The most defensible possibility is **operational exposure**:

1. local observational data do not identify the masks or transports;
2. a declared intervention or action exposes only selected compatibility
   conflicts;
3. the learner must choose what to expose before deciding whether to split
   memory, routing, or charts;
4. the lower bound charges this adaptive exposure, not merely edge
   classification;
5. the repaired architecture yields policy or scientific-decision regret
   improvement on independent units.

At that point the central object is no longer partial transport.  It is an
active or sequential representation-selection problem, with partial transport
serving only as its structural state description.

The subsequent audit
`OPERATIONALLY_EXPOSED_MEMORY_CONFLICT_GO_NO_GO.md` constructs exactly this
kind of memory conflict.  It closes rather than rescues the route: when the
exposing split is unavailable the query has zero information, and when it is
available it is an experiment action in controlled sequential testing.  A
resource charge produces information per unit cost, not a distinct
architecture-learning term.

## 8. Implication for the monograph

The book should keep its present honest positioning as a typed,
native-loss, audit-oriented synthesis.  This attack does not justify adding a
36th result or promoting Chapter 23.  It strengthens the manuscript by making
the stopping rule explicit:

> Partiality is a scientifically meaningful semantic distinction, but in the
> finite model it is not by itself a theorem-level escape from masked
> synchronization, constraint satisfaction, or structured testing.

The requested next attack has now been completed.  Its lower-bound experiment
closes operational exposure alone as a flagship route under finite resettable
diagnostics.  The flagship search should stop unless a new hard family first
passes an explicit nonreduction test against controlled sensing, POMDP
exploration, automata discrimination, and representation selection.
