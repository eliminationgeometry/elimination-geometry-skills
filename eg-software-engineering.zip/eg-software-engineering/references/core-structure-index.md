# Core16 Structure and Statement Index

> Generated from the complete bundled TeX sources. Use this index to locate the exact source before making theorem-level claims. The titles below are locators, not substitutes for hypotheses or proofs.

## Contents

1. [Elimination Geometry I](#core-01)
2. [Elimination Geometry II](#core-02)
3. [Exactification and Optimization Certificates](#core-03)
4. [Elimination Geometry III](#core-04)
5. [Elimination Obstruction Transfer](#core-05)
6. [Compositional Obstruction Transfer](#core-06)
7. [Foundations of Elimination Geometry](#core-07)
8. [Quantum Elimination Geometry](#core-08)
9. [Singular Elimination Geometry](#core-09)
10. [Lift Complexity](#core-10)
11. [Operational Semantics](#core-11)
12. [Statistical Elimination Geometry](#core-12)
13. [Certificate Statistics](#core-13)
14. [Resource-Constrained Architectures](#core-14)
15. [EG for Machine Learning and AI](#core-15)
16. [EG for Adaptive Learning Systems](#core-16)

## Core 01

**Paper:** Elimination Geometry I: A Certified Calculus of Auxiliary-Field Coupling  
**Exact source:** [`core16/eg1.tex`](core16/eg1.tex)

### Section map

- L117: Introduction
- L283: Constructive Template and Decision Map
  - L300: Collections of local problems
  - L328: Conjugate-complete envelopes
  - L378: MM and EM are two instances
  - L459: Four schemes, one fork, and an orthogonal dependence layer
  - L571: Elimination--coupling calculus and certified saddle completion
- L743: Operational Geometry and Exchange Conditions
  - L803: Directed Bregman pooling and intrinsic globalization
  - L1043: Distributional auxiliaries: operational summary
  - L1060: Chosen coupling geometries and transport penalties
  - L1112: Compatibility and metric transfer
  - L1242: Operational accounts and exchange conditions
- L1385: Fixed-Marginal and Vertical Dependence
  - L1394: The static fixed-marginal fiber
  - L1464: Vertical C: conditional fibers along a recursive path
  - L1622: Protected objects and application boundaries
- L1683: Plug-in Globalization: the Defect is Second Order
  - L2029: High-order signed graph globalization with CDF repair
- L3162: Exactification: Exact Score and Certified Geometry
  - L3555: Certified inexact X implementation
- L3718: Variational Coupling: Exactness by Construction
- L3983: Statistical Constructions and Stress Tests
  - L3986: Flagship construction: quotient-safe spectral projectors
  - L4149: Early motivating EM illustration: localized mixtures
  - L4188: Early motivating MM illustration: half-quadratic local criteria
  - L4219: Robust conditional scatter feeding the spectral construction
  - L4268: Complementary construction: amortized variational inference
  - L4292: Non-Euclidean stress test I: quantum Gibbs families
  - L4524: Non-Euclidean stress test II: LogDet spectral auxiliaries
- L4701: Illustrative Numerical Diagnostics
- L4777: Related Work
- L5035: Discussion

### Named statements

- L286: **Remark** — Certified-lift interface and sequel boundary
- L330: **Definition** — Conjugate-complete auxiliary representation
- L383: **Assumption** — Half-quadratic representability
- L402: **Example** — Perturbed check loss
- L414: **Example** — Huber and Student weights
- L426: **Example** — EM is the same envelope
- L595: **Definition** — One-sided certified elimination
- L614: **Proposition** — The consensus interchange gap
- L670: **Proposition** — Certified saddle elimination and its quadratic regime
- L716: **Remark** — What survives, and what does not, for saddle PGXVC
- L808: **Proposition** — Directed Bregman consensus
- L882: **Remark** — Strong consensus can suppress rare coordinates
- L912: **Remark** — Quotient geometry and zero-cost gauge fixing
- L933: **Proposition** — Multi-stage defect ledger
- L980: **Proposition** — Profile curvature is quotient geometry
- L1031: **Remark** — Defect, profile curvature, and inference are different layers
- L1120: **Lemma** — Currency-exchange bound
- L1167: **Proposition** — No unconditional Wasserstein-to-KL exchange rate
- L1202: **Remark** — Analytic and empirical exchange certificates
- L1214: **Remark** — Defect-matched V and the moving-metric trap
- L1281: **Remark** — A multi-currency controller, not another scheme
- L1317: **Remark** — The lift is designed; reparameterization is not a new defect
- L1331: **Remark** — Power generators: robustness is not global boundedness
- L1348: **Remark** — The KL orientation flip in policy optimization
- L1396: **Definition** — Fixed-marginal dependence layer
- L1430: **Proposition** — Coordinate safety and the joint-objective requirement
- L1509: **Theorem** — Vertical Fiber Ledger
- L1564: **Remark** — What is and is not new in the ledger
- L1574: **Proposition** — Single-path trichotomy
- L1655: **Remark** — C is orthogonal to, not after, PGXV
- L1669: **Remark** — Where a domain-specific algorithm can still be new
- L1686: **Assumption** — Controlled Bregman geometry
- L1730: **Theorem** — Bregman defect and near-monotonicity for scheme (G)
- L1801: **Proposition** — Moment cancellation raises the defect to fourth order
- L1868: **Proposition** — Mixture- and exponential-coordinate density centering
- L1956: **Remark** — The two centers can be sharply different
- L1970: **Corollary** — Channel and pathwise inheritance of centered defects
- L2005: **Remark** — Centered kernels are vertical G, not automatically C
- L2013: **Remark** — What is classical and what the framework adds
- L2107: **Proposition** — CDF repair certificate for a signed graph smoother
- L2202: **Theorem** — Finite-sample CRPS risk and graph effective dimension
- L2383: **Proposition** — Unbiased raw CRPS risk and an observable repair deduction
- L2461: **Remark** — Selection and dependence boundary
- L2518: **Corollary** — Real-smoothness minimax rate and validity phase boundary
- L2775: **Remark** — Scope of the repaired rule
- L2803: **Proposition** — Ambient variational representation and its conditional Dirichlet obstruction
- L2953: **Remark** — Structural role and interface with Part II
- L3013: **Remark** — Generating identity
- L3026: **Remark** — One defect, quadratic --- and why conjugate terms matter
- L3047: **Remark** — The defect is second order from both sides
- L3076: **Corollary** — Oracle-map sensitivity and a deployable defect certificate
- L3141: **Proposition** — Coherence under a continuous coupled field
- L3213: **Theorem** — Defect-corrected exactification
- L3291: **Corollary** — Defect budget and metric rays
- L3342: **Proposition** — Defect-adaptive stabilization in a conjugate lift
- L3464: **Proposition** — Inner optimality residuals generate inexact-X certificates
- L3590: **Corollary** — Accepted descent with an approximate defect jet
- L3676: **Proposition** — Zero-cost symmetry closure
- L3704: **Remark** — When the gauge closure is nontrivial
- L3763: **Assumption** — Variational regularity
- L3786: **Theorem** — Exact monotonicity, interpolation, and consensus
- L3874: **Remark** — Operational V diagnostics and the structural sequel
- L3917: **Remark** — Representation--coupling product principle
- L3961: **Remark** — Annealed coupling as continuation
- L4054: **Proposition** — Spectral block update, consensus endpoint, and exchange
- L4117: **Remark** — What the certificate does and does not transport
- L4333: **Assumption** — Faithful local quantum geometry
- L4367: **Corollary** — The forward-Umegaki midpoint is the Holevo center
- L4396: **Remark** — Quantum center orientation
- L4418: **Proposition** — Gibbs defect and variational endpoints
- L4481: **Corollary** — Centering raises the Gibbs defect from quadratic to quartic
- L4571: **Proposition** — LogDet envelope, exact blocks, and endpoints

## Core 02

**Paper:** Elimination Geometry II: Integrability, Representation, and Structural Limits  
**Exact source:** [`core16/eg2.tex`](core16/eg2.tex)

### Section map

- L138: Introduction
- L301: Certified elimination and the defect coordinate
  - L370: A running quadratic laboratory
- L429: Flatness of the elimination lattice
  - L642: Curvature repair and the nearest certified objective
- L1027: The representation gate
  - L1041: Equivalent packages and unrestricted-lift collapse
  - L1113: Surjective refinements and quotient-faithful coherence
  - L1269: Duplication no-go and transported units
  - L1357: Admissible representation classes
- L1379: Frontier geometry and supported V paths
  - L1389: The scalar frontier and its supported dual
  - L1536: External design inefficiency
  - L1613: Work and susceptibility
- L1668: Invariant leverage and the complete quadratic fingerprint
  - L1676: Curvature allocation and the local coupling spectrum
  - L1823: The complete augmented modal fingerprint
  - L2067: Leverage filtering and contraction-body design
  - L2331: Frontier insufficiency and leverage on symmetry quotients
- L2484: Semantic admissibility of variational coupling
  - L2493: The operator passport
  - L2589: Probability validity versus Hilbert-scale order
  - L2909: Graph-universal spectral passports and exact weighted witnesses
- L3242: Exactification as a unique jet normal form
- L3611: Coupling accounting consequences and a scoped normal form
  - L3620: A statistical three-currency consequence
  - L3772: A scoped architectural normal form
- L3895: Fixed-marginal dependence and V--C separation
- L4160: Three hard ledger tests
  - L4163: Hard instance I: a forward-KL distillation barrier in soft control
  - L4339: Hard instance II: quantum Gibbs fibers and observability
  - L4670: Hard instance III: the classical Polyakov fiber
- L4755: Relation to neighboring theories
  - L4758: Classical components and claimed increments
- L5095: Boundaries and extensions
  - L5103: Scope of the finite-dimensional core
  - L5147: Infinite-dimensional and transported extensions
  - L5245: Remaining statistical and structural boundaries
- L5331: Discussion

### Named statements

- L309: **Definition** — Certified minimum elimination
- L337: **Example** — Conjugate-complete Bregman lifts
- L361: **Remark** — Representation dependence
- L466: **Theorem** — Flat certified-elimination criterion
- L546: **Example** — A curved report of the quadratic laboratory
- L570: **Example** — Locally valid edges without a global objective
- L599: **Definition** — Defect curvature
- L613: **Proposition** — Quantitative elimination holonomy
- L693: **Theorem** — Curvature floor and nearest certified repair
- L800: **Corollary** — Global certified repair without declared witnesses
- L841: **Theorem** — Periods and the three-tax repair on a general complex
- L922: **Example** — A period with zero curvature
- L935: **Corollary** — A local falsification bound
- L950: **Corollary** — Path-independent multi-layer defect ledger
- L987: **Remark** — Order-flat value, order-curved work
- L1008: **Remark** — Canonical defects versus reported divergences
- L1044: **Definition** — Coupling-equivalent lift packages
- L1061: **Proposition** — Representation invariance and unrestricted collapse
- L1122: **Definition** — Surjective refinement and quotient coherence
- L1154: **Theorem** — The non-bijective representation gate
- L1272: **Corollary** — Duplication no-go for raw-weight penalties
- L1318: **Remark** — Scope and classical operation
- L1337: **Remark** — No-free rescaling
- L1360: **Remark** — Admissible L is a representation prefix
- L1392: **Definition** — Fidelity--coherence frontier
- L1427: **Theorem** — Frontier duality and endpoints
- L1542: **Definition** — External-globalization inefficiency
- L1554: **Corollary** — Irreducible frontier cost plus design inefficiency
- L1579: **Example** — A classical frontier: the common-corrector price
- L1616: **Theorem** — Work and susceptibility on the supported frontier
- L1686: **Theorem** — Auxiliary leverage and curvature allocation
- L1761: **Proposition** — The local coupling spectrum
- L1826: **Theorem** — Complete linear fingerprint of an unconstrained quadratic lift--coupling germ
- L2025: **Example** — Why energy and leverage are not a complete fingerprint
- L2052: **Remark** — Scope and classical linear algebra
- L2070: **Proposition** — The leverage filter law
- L2159: **Corollary** — The contraction-body parameterization
- L2207: **Proposition** — Positive-definite self-adjoint contractions have induced penalties, and inefficiency measures declared-target mismatch
- L2305: **Remark** — What this settles about the G/V distinction
- L2334: **Example** — A pointwise frontier does not determine leverage
- L2353: **Remark** — Coupling energy is not outer leverage
- L2363: **Proposition** — Quotient leverage for orbit-degenerate oracles
- L2441: **Example** — Discriminant barrier
- L2457: **Proposition** — Symmetry selection rule for leverage
- L2496: **Proposition** — The V passport
- L2576: **Remark** — Semantic gates for claimed V mechanisms
- L2621: **Proposition** — The Dirichlet cone on three nodes and the exact order ceiling
- L2708: **Proposition** — A three-node probability--approximation-order frontier
- L2864: **Corollary** — Positive off-diagonal entries defeat the probability gate on any graph
- L2924: **Proposition** — Bernstein spectral passport
- L2990: **Proposition** — Exact weighted-path spectral obstruction
- L3077: **Corollary** — Universal spectral-power classification
- L3106: **Corollary** — Graph-universal polynomial no-go
- L3135: **Remark** — Scope and ownership of the spectral frontier
- L3180: **Remark** — Barrier--repair--rate closure across the series
- L3262: **Proposition** — Jet splicing and the retained auxiliary tail
- L3311: **Theorem** — Converse and uniqueness of jet exactification
- L3365: **Corollary** — First-order conservation of the target score
- L3378: **Proposition** — Conjugate-lift transmission and an affine no-go
- L3471: **Proposition** — Exactification budget
- L3502: **Theorem** — Robustness to approximate defect jets
- L3623: **Theorem** — Stochastic defect risk and the three-currency filter
- L3779: **Definition** — One-coupling architecture
- L3800: **Theorem** — PGXV-by-C normal form in the one-coupling class
- L3840: **Theorem** — No-free first-order coupling in smooth scalar auxiliary models
- L3906: **Proposition** — Coordinate safety
- L3940: **Theorem** — V--C separation identity
- L3973: **Definition** — Dependence--benefit frontier
- L3997: **Proposition** — The least dependence required for joint gain
- L4050: **Remark** — Entropic C is recursively certified
- L4086: **Remark** — Elimination--tilt interchange on rate functions
- L4101: **Remark** — A horizontal frontier
- L4118: **Proposition** — Conditional-kernel protection
- L4138: **Example** — Specification exactness does not identify the law
- L4191: **Theorem** — No dimension-free forward-KL performance certificate
- L4289: **Corollary** — Support restores an explicit exchange rate
- L4359: **Proposition** — Noncommutative hard-coherence endpoint
- L4411: **Proposition** — The local measurement-to-defect exchange tax
- L4541: **Theorem** — Lossless classicalization of a defect family
- L4609: **Corollary** — Measured KL cannot certify an upper defect budget
- L4653: **Remark** — Quantum boundary of the stochastic filter
- L4687: **Proposition** — Certified elimination and conformal incompatibility
- L5154: **Proposition** — The filter law with continuous spectrum
- L5194: **Proposition** — Bundle-valued fields, transport, and holonomy

## Core 03

**Paper:** Exactification and Optimization Certificates: Local Rates, Leverage Deflation, and Certified Switching  
**Exact source:** [`core16/x_algo.tex`](core16/x_algo.tex)

### Section map

- L134: Introduction
  - L182: Exact correspondences with prior work
  - L270: Inherited foundation and independent contribution
  - L315: Scope and novelty boundary
- L340: Certified elimination and exactified models
  - L377: The design fork and the qualification gate
  - L416: The tangency dichotomy
- L491: Jet splicing and the fidelity--leverage law
- L591: Conjugate transmission and a sharp no-go theorem
- L731: Defect-adaptive stabilization
- L954: Residual-certifiable approximate exactification
- L1122: The defect-certified unrelaxed branch
- L1249: The local rate geometry of exactification
  - L1480: Scalar relaxation as the spectral baseline
- L1503: Low-rank leverage deflation
- L1933: Certified leverage-deflated exactification
  - L1944: An exactified metric ray
  - L2008: The unified controller
  - L2086: One theorem for stale, inexact, approximate, and switched exactification
  - L2299: Global guarantee for the exact-score branch
- L2403: End-to-end nonlinear elimination laboratory
  - L2414: Problem and protocol
  - L2508: Results
- L2568: The exactification-curvature frontier
- L2636: Deep-learning interface: theorem, analogy, and refresh
- L2701: Novelty boundary, limitations, and next tests
- L2776: Conclusion

### Named statements

- L355: **Assumption** — Smooth profiled target
- L421: **Proposition** — Tangency dichotomy
- L458: **Remark** — Self-staleness and persistent foreign fields
- L475: **Definition** — Order-\(k\) exactification
- L498: **Theorem** — Jet-splicing normal form
- L549: **Proposition** — Field-difference and fidelity--leverage law
- L578: **Definition** — Exactification equivalence and active field
- L596: **Assumption** — Conjugate-complete lift
- L632: **Theorem** — Exact auxiliary-transmission identity
- L677: **Corollary** — Affine and polynomial no-go
- L691: **Example** — Affine safety without leverage
- L710: **Example** — A nonlinear field that survives exactification
- L751: **Proposition** — Exact candidate ledger
- L784: **Lemma** — Bregman-defect Hessian
- L814: **Assumption** — Local transmission bounds
- L831: **Theorem** — Defect-adaptive stabilization
- L878: **Corollary** — Observable-defect trust law
- L905: **Corollary** — Certified refresh radius for a self-stale field
- L931: **Corollary** — Affine endpoint
- L975: **Proposition** — Inner residual produces value and score certificates
- L1040: **Definition** — Certified approximate exactification model
- L1051: **Theorem** — Residual-certified majorization and target descent
- L1174: **Theorem** — Descent and stationary cluster points
- L1242: **Remark** — What convergence does not prove
- L1260: **Proposition** — Classical tangent-surrogate rate matrix
- L1318: **Proposition** — Auxiliary-coordinate invariance
- L1343: **Theorem** — Schur identification of the classical rate matrix
- L1452: **Remark** — Two kinds of leverage
- L1468: **Remark** — Nonoracle fields
- L1524: **Theorem** — Classical spectral deflation on the leverage channel
- L1582: **Proposition** — Certified tail-edge safeguard
- L1611: **Theorem** — Target-frame Ritz certificate with one common rotation
- L1808: **Corollary** — Fully computable safeguarded Ritz gate
- L1890: **Corollary** — Finite-rank leverage needs finite-rank deflation
- L1916: **Remark** — Matrix-free leverage modes
- L2094: **Theorem** — Certified switching and recovery of the deflated rate
- L2289: **Remark** — What eventual activation assumes
- L2301: **Theorem** — Classical variable-metric Armijo complexity
- L2368: **Proposition** — Certified inexact metric solve
- L2603: **Proposition** — Basic frontier properties

## Core 04

**Paper:** Elimination Geometry III: Certified Pushforwards, Base Change, and the Zero-Temperature Limit  
**Exact source:** [`core16/eg3.tex`](core16/eg3.tex)

### Section map

- L132: Introduction
  - L186: Main results
  - L247: What is classical and what is added
  - L293: Relation to the companion papers
- L312: Hard and soft kernel composition
  - L315: Hard elimination and pathwise excess cost
  - L379: Finite temperature and the correct nonnegative certificate
  - L569: Associativity and its precise scope
- L626: Coherence on heterogeneous refinement diagrams
  - L633: Refinement cocycles
  - L767: Finite-state strictification
- L850: Finite-temperature base change
  - L857: Reference measures and the descended cost
  - L934: The base-change and defect theorem
  - L1186: Universal quotient faithfulness
  - L1233: Composition under iterated refinement
  - L1278: Pullback squares and the Beck--Chevalley anomaly
  - L1409: The fiber-volume anomaly
  - L1473: The semiclassical fiber ledger
- L1523: Dequantization: from conditional KL to hard defect
  - L1531: Finite-state theorem
  - L1820: What survives and what does not
- L1912: Worked instances
  - L1919: Hidden-state inference: sum--product and min--sum
  - L1955: Entropy-regularized control
  - L1977: Latent-state refinement and redundant labels
  - L1999: Entropic transport and Schr\"odinger bridges
  - L2017: A finite refinement diamond
- L2036: Interfaces, limitations, and nonextensions
  - L2039: Interface with P/G/X/V/C
  - L2068: The quantum boundary
  - L2086: Gauge fibers and path integrals
  - L2100: Analytic and computational boundaries
- L2132: Discussion
- L2188: Proof details and useful identities
  - L2191: The variational form of the soft value
  - L2219: Density calculation for base change
  - L2255: A matrix form of finite strictification
- L2281: Notation and result map

### Named statements

- L334: **Definition** — Hard transition defect
- L347: **Theorem** — Hard factorization-defect chain rule
- L418: **Remark** — Feynman--Kac and Doob-transform antecedents
- L429: **Remark** — A log-normalizer is not a defect
- L456: **Lemma** — Conditional Gibbs certificate
- L506: **Theorem** — Soft conditional chain theorem
- L552: **Corollary** — Exact touching and approximate messages
- L588: **Proposition** — Parenthesization invariance
- L605: **Remark** — No cost-free identity convention
- L616: **Remark** — Connection with semirings and convex bifunctions
- L664: **Definition** — Exact refinement report
- L674: **Theorem** — Heterogeneous integrability
- L725: **Theorem** — From integrability to an elimination tower
- L760: **Remark** — Infima need not be attained
- L801: **Theorem** — Nearest certified strictification
- L831: **Remark** — Why the witnesses are declared
- L841: **Remark** — Classical ingredients, new interface
- L905: **Remark** — Why \(v\) cannot be omitted
- L913: **Remark** — Potential of mean force
- L946: **Theorem** — Finite-temperature base change
- L1029: **Corollary** — Fiber touching
- L1038: **Theorem** — Approximate base-change certificate
- L1164: **Remark** — A pushforward-level X certificate
- L1177: **Remark** — Information chain rule versus objective ledger
- L1193: **Theorem** — Universal finite-temperature quotient gate
- L1226: **Remark** — Absolute constants are still objective changes
- L1245: **Proposition** — Base-change composition
- L1269: **Remark** — Two kinds of coherence
- L1306: **Theorem** — Measured Beck--Chevalley identity and anomaly
- L1399: **Remark** — What the anomaly measures
- L1416: **Proposition** — Finite replication ledger
- L1452: **Example** — A state-dependent target change
- L1465: **Remark** — Duplication is not automatically anomalous
- L1480: **Proposition** — Nondegenerate fiber expansion
- L1545: **Theorem** — Quantitative law-level dequantization
- L1707: **Corollary** — Architecture-level dequantization
- L1766: **Corollary** — Deterministic paths
- L1799: **Corollary** — Soft optimal paths concentrate on hard optimal paths
- L1841: **Theorem** — Conditional Varadhan base change
- L1880: **Remark** — Three hard targets
- L1892: **Remark** — Degenerate ground states
- L1900: **Remark** — Continuous paths require localization
- L1942: **Example** — A negative soft report

## Core 05

**Paper:** Elimination Obstruction Transfer: Bregman Flow Duality, Monodromy, and Lower Bounds for Amortized Inference  
**Exact source:** [`core16/eot.tex`](core16/eot.tex)

### Section map

- L137: Introduction
  - L194: Main contributions
  - L285: Relation to the companion framework
  - L296: Organization
- L308: Certified elimination and architecture classes
  - L311: Defects generated by elimination
  - L355: A finite transported architecture
  - L415: The Bregman architecture obstruction
- L448: Bregman obstruction-flow duality
- L617: Quadratic flows and calibration-sample certificates
  - L673: Exact global sections and holonomy
  - L718: Sparse witnesses
  - L764: Approximate oracle robustness
- L841: Population transport and frontier lower bounds
  - L993: A frontier witness
- L1058: Amortized variational inference
  - L1061: The exact defect
  - L1191: A finite-sample flow certificate
  - L1217: A probability-space corollary
  - L1263: Interpretation of refinement
- L1275: Monodromy and global section obstructions
  - L1282: Oracle covers
  - L1430: Softness as a separate account
  - L1504: Atlas complexity
- L1549: Separated mixtures and a dimension phase
  - L1559: The ordered configuration cover
  - L1612: A quantitative mixture no-go
  - L1905: Scientific target boundary
- L1915: Classical ingredients and claimed increments
  - L2018: Amortization gap and solution-map restrictions
  - L2037: Topological representation learning and atlases
  - L2060: Lipschitz extension and graph learning
  - L2072: Canonicalization and soft frames
  - L2084: Mixture label switching
- L2100: Boundaries and failure modes
- L2149: Discussion

### Named statements

- L316: **Definition** — Certified local elimination
- L339: **Assumption** — Defect exchange
- L431: **Definition** — Bregman architecture obstruction
- L455: **Assumption** — Finite-dimensional qualification
- L471: **Theorem** — Bregman obstruction-flow duality
- L576: **Corollary** — Obstruction transfer to the certified target
- L604: **Remark** — What is and is not new in the duality
- L629: **Theorem** — Exact quadratic projection--flow identity
- L675: **Corollary** — Hard-section obstruction
- L720: **Proposition** — Disjoint-edge matching certificate
- L769: **Proposition** — Residual-robust flow certificate
- L856: **Theorem** — Oracle-variation transport lower bound
- L905: **Corollary** — Empirical assignment certificate
- L934: **Example** — Strict hierarchy: matching, assignment, and full flow
- L1014: **Proposition** — Oracle-roughness frontier lower bound
- L1045: **Remark** — Flow versus transport witnesses
- L1080: **Corollary** — Conjugate-complete amortized inference
- L1134: **Remark** — Scope of conjugate completeness
- L1143: **Theorem** — Architecture-level amortization lower bound
- L1222: **Corollary** — Exact-KL oracle fields
- L1249: **Remark** — Pythagorean boundary
- L1284: **Definition** — Embedded finite oracle cover
- L1316: **Remark** — Finite group quotients as a source
- L1337: **Theorem** — Worst-case and population monodromy taxes
- L1422: **Remark** — Why a pointwise topological no-go is not enough
- L1448: **Theorem** — Hard selection or soft entropy
- L1506: **Definition** — Amortization atlas number
- L1528: **Proposition** — Chart lower bound for exact hard amortization
- L1587: **Proposition** — One-dimensional section and higher-dimensional exchange obstruction
- L1614: **Corollary** — Monodromy-induced amortization gap for mixtures
- L1674: **Example** — An exact antipodal double-cover witness
- L1718: **Proposition** — A literal reverse-KL monodromy tax
- L1878: **Remark** — Portable transfer versus the exact mountain-pass barrier

## Core 06

**Paper:** Compositional Obstruction Transfer: Rectangularity, Architecture Base Change, and Dequantization  
**Exact source:** [`core16/cot.tex`](core16/cot.tex)

### Section map

- L145: Introduction
  - L184: Main results
  - L308: Classical ingredients and claimed increment
  - L339: Scope and organization
- L360: Architecture obstruction as a second elimination
  - L363: The obstruction value
- L489: Shared kernels and memory compression
  - L492: The geometric-pool coordination tax
  - L589: A fixed-occupancy memory-compression theorem
- L727: The rectangularity gate
  - L730: Architectures on a finite history tree
  - L812: Bellman recursion and the coordination tax
- L1186: Architecture base change
  - L1189: Fine laws, coarse laws, and canonical lifts
  - L1252: The exact infimal ledger
  - L1459: The fiber-saturation gate
- L1576: Dequantization of moving architecture classes
  - L1579: Uniform law-level input
  - L1664: Set convergence and the variational limit
  - L1835: Coordination taxes and relaxed hard limits
- L1969: Effective monodromy under representation
  - L1972: Invariant fiber quotients
- L2118: Interfaces, certificates, and boundaries
  - L2121: The four commutation gates
  - L2164: Computable lower relaxations and upper witnesses
  - L2205: Relation to the companion papers
  - L2236: Honest boundaries
- L2271: Discussion
- L2321: Notation and result map

### Named statements

- L376: **Definition** — Architecture obstruction
- L419: **Proposition** — Information projection and implementation ledger
- L477: **Remark** — Relation to the amortization gap
- L501: **Theorem** — Shared-kernel geometric-pool tax
- L562: **Example** — Opposed binary oracles
- L624: **Theorem** — Memory-compression obstruction
- L686: **Corollary** — Memory design as directed clustering
- L708: **Proposition** — Elementary monotonicity
- L777: **Definition** — Rectangular hull
- L815: **Theorem** — Rectangular obstruction recursion
- L889: **Theorem** — Coordination-defect chain rule
- L1008: **Theorem** — Universal Bellman--rectangularity gate
- L1058: **Remark** — Universal versus accidental exactness
- L1067: **Remark** — Why the positivity floor appears in the converse
- L1077: **Remark** — Relation to classical rectangularity
- L1093: **Example** — A shared binary mode with endogenous occupancy
- L1235: **Definition** — Fiber realization tax
- L1255: **Theorem** — Architecture obstruction base change
- L1327: **Definition** — Architecture fiber tax
- L1343: **Corollary** — Coarse-deviation/fiber-realization ledger
- L1378: **Corollary** — Fine-deployment fiber ledger
- L1462: **Definition** — Fiber-saturated architecture
- L1473: **Theorem** — Universal obstruction-faithfulness gate
- L1505: **Corollary** — Approximate saturation
- L1538: **Example** — Objective-faithful but obstruction-unfaithful
- L1565: **Remark** — A representation/architecture ledger
- L1634: **Corollary** — Fixed-class obstruction dequantization
- L1676: **Definition** — Sequential architecture convergence
- L1708: **Theorem** — Moving-architecture dequantization
- L1826: **Remark** — Why \(\Gamma\)-convergence is not decoration
- L1881: **Corollary** — Coordination-tax dequantization
- L1926: **Proposition** — Deterministic and relaxed hard endpoints
- L2031: **Theorem** — Effective-monodromy gate
- L2077: **Example** — Two sign obstructions cancel after multiplication
- L2109: **Remark** — Why local topological taxes do not simply add
- L2170: **Corollary** — Coordination certificate sandwich

## Core 07

**Paper:** Foundations of Elimination Geometry: Defect Fibrations, Obstruction Towers, and Interchange Coherence  
**Exact source:** [`core16/foundation.tex`](core16/foundation.tex)

### Section map

- L141: Introduction
  - L180: Rigidity before obstruction
  - L207: The fundamental compression
  - L269: Curvature of the obstruction calculus
  - L320: Classical ingredients and the claim of the paper
  - L348: Organization
- L364: Certified defect fibrations
  - L367: The absolute object
  - L444: Split relative defect fibrations
- L508: Rigidity of the certificate currency
  - L519: Exact disintegration singles out forward relative entropy
  - L634: The Gibbs-to-Bellman deformation
- L851: The fundamental obstruction tower
  - L854: Architecture obstruction and fiber realization
  - L987: The universal saturation gate
- L1082: Composition, Bellman towers, and rectangularity
  - L1085: Composable defect fibrations
  - L1190: Rectangularity as multi-cleavage saturation
- L1327: Architecture curvature and downstream difficulty
  - L1330: Bellman transfers on a representation diagram
  - L1399: A complete downstream distinguishability theorem
  - L1462: Common perturbations and nested architectures
- L1522: Architecture-level integrability and strictification
  - L1525: Curvature and global periods
  - L1587: Nearest strictification
- L1666: Interchange coherence and 3-curvature
  - L1669: Contextual rather than pointwise commutation
  - L1734: A minimal tropical counterexample
- L1827: The five companion theories as interface corollaries
  - L1836: Parts I and II
  - L1876: Part III
  - L1901: EOT and COT
- L1964: Discussion and limits
- L2035: A finite tower calculation
- L2068: Proof audit for the universal converse

### Named statements

- L373: **Definition** — Certified defect fibration
- L401: **Proposition** — Exact insertion ledger
- L417: **Example** — Ordinary auxiliary elimination
- L434: **Example** — Relative entropy fiber
- L452: **Definition** — Split relative certified defect fibration
- L488: **Remark** — Set-valued oracle fibers
- L498: **Remark** — Topology
- L533: **Definition** — Compositional statistical certificate
- L572: **Theorem** — Finite soft-currency rigidity; classical
- L614: **Remark** — Why the original informal statement needs these qualifiers
- L625: **Remark** — Scope of the rigidity
- L639: **Lemma** — Hard-currency rigidity
- L668: **Theorem** — Compositional currency deformation
- L825: **Corollary** — Why the three principal currencies are not arbitrary
- L839: **Remark** — What is classical and what is assembled here
- L865: **Definition** — Fine and coarse obstructions
- L894: **Theorem** — Fundamental obstruction tower
- L928: **Corollary** — Three-level deployment ledger
- L994: **Assumption** — Attainment and separation package
- L1003: **Definition** — Canonical-lift saturation
- L1015: **Theorem** — Universal obstruction--saturation gate
- L1051: **Remark** — Why ``for every oracle'' is essential
- L1060: **Corollary** — Approximate saturation
- L1097: **Definition** — Compatible composite
- L1119: **Theorem** — Obstruction tower composition law
- L1154: **Corollary** — Factorwise saturation
- L1180: **Remark** — Min-plus interpretation
- L1210: **Theorem** — Rectangularity--saturation equivalence
- L1239: **Theorem** — Universal separable-value gate
- L1268: **Theorem** — Universal relaxed-obstruction gate
- L1297: **Corollary** — COT's Bellman gate
- L1318: **Remark** — Unreachable histories
- L1359: **Proposition** — Path taxes are iterated obstruction towers
- L1379: **Definition** — Architecture curvature
- L1407: **Theorem** — Curvature bounds and separation
- L1447: **Corollary** — Representation-equivalent objectives can differ in architectural difficulty
- L1469: **Lemma** — Nested-minimum oscillation principle
- L1500: **Corollary** — Sharp coordination-tax perturbation
- L1545: **Theorem** — Architecture integrability
- L1579: **Remark** — Local flatness is insufficient
- L1608: **Theorem** — Hodge strictification and certification ledger
- L1686: **Definition** — Interchange \(3\)-curvature
- L1707: **Theorem** — Contextual interchange criterion
- L1744: **Theorem** — Pairwise-flat but interchange-curved
- L1810: **Corollary** — Pairwise certificate gates do not certify a cube
- L1839: **Corollary** — Part I: P/G/X/V/C placement
- L1864: **Corollary** — Part II: integrability, representation, and monodromy
- L1879: **Corollary** — Part III: certified pushforwards
- L1904: **Corollary** — EOT: obstruction of admissible sections
- L1921: **Corollary** — COT: one universal closure principle

## Core 08

**Paper:** Quantum Elimination Geometry: Gibbs Base--Change Rigidity, Conditional Sectors, and Recoverability  
**Exact source:** [`core16/quantum.tex`](core16/quantum.tex)

### Section map

- L120: Introduction
  - L163: Main result in one line
  - L190: Proof architecture
  - L232: What remains exact
- L262: Finite-dimensional Gibbs elimination
  - L281: Reduced Gibbs operators and pressure
  - L361: Normalized references
- L400: Pressure duality and lossless quantum extension
  - L408: The constrained Gibbs--Fenchel dual
  - L512: A right inverse of partial trace cannot carry information
  - L562: Universal saturation forces a product reference
- L630: Full-algebra Gibbs base-change rigidity
  - L809: The exact Umegaki disintegration that survives
- L855: Exact base change over a commuting sector algebra
- L1051: The general interaction ledger
  - L1059: Recoverability and mean-force anomaly
  - L1192: The anomaly gate
  - L1225: Recovery of the exact product ledger
- L1243: Two-qubit models
  - L1249: A controlled interaction: exact on one algebra
  - L1308: A transverse interaction: no exact diagonal descent
  - L1336: Small-field response
  - L1354: Reproducible numerical audit
- L1396: Relation to quantum sufficiency and mean-force theory
  - L1399: What is inherited
  - L1421: What is added here
- L1446: Series boundary, limitations, and open problems
  - L1449: The boundary with classical disintegration
  - L1483: Limitations
  - L1506: Open directions
- L1526: Conclusion

### Named statements

- L321: **Definition** — Full quantum Gibbs base change
- L348: **Remark** — Affine mean-force closure
- L424: **Lemma** — Gibbs variational identity
- L456: **Proposition** — Constrained pressure duality
- L515: **Lemma** — Undisturbed extension channels are product
- L552: **Remark** — No information without disturbance
- L579: **Proposition** — Universal constrained saturation
- L638: **Theorem** — Universal Gibbs base-change rigidity
- L783: **Corollary** — Scalar-shadow rigidity
- L792: **Corollary** — One temperature is enough
- L800: **Remark** — The quantifier over noncommuting fields
- L818: **Corollary** — Product Gibbs chain rule
- L878: **Definition** — Sector base change
- L899: **Theorem** — Commuting-sector base-change gate
- L1002: **Corollary** — Maximal abelian coarse algebra
- L1032: **Remark** — Conditional-expectation interpretation
- L1042: **Remark** — Higher-rank sectors
- L1085: **Theorem** — Exact quantum base-change ledger
- L1157: **Corollary** — Universal recovery certificate
- L1183: **Remark** — Exact versus approximate statements
- L1195: **Proposition** — Universal anomaly cancellation is rigid

## Core 09

**Paper:** Singular Elimination Geometry: Discriminants, Degree Obstructions, and Catastrophe Taxes  
**Exact source:** [`core16/singular.tex`](core16/singular.tex)

### Section map

- L138: Introduction
  - L181: Contributions
  - L234: What is classical and what is new
  - L261: Organization and notation
- L283: Certified defects on singular oracle incidence
  - L286: Oracle incidence and the discriminant
  - L334: Residual factorizations
- L377: The radical normal form
  - L488: Arbitrary nonvanishing target loops
- L556: Degree barriers for homogeneous elimination
  - L681: A perturbative degree corollary
- L706: Polynomial discriminants and root monodromy
  - L713: The regular-value root cover
  - L825: Local ramification inherits the exact normal form
- L905: Approaching the discriminant
- L999: Representation, atlases, and risk aggregation
  - L1007: Local charts
  - L1043: Unordered and randomized representations
  - L1102: Average risk can hide a seam
  - L1160: The architecture ledger
- L1208: A conical eigenline catastrophe
- L1317: Application templates
  - L1325: Polynomial root tracking
  - L1352: A two-component collision prototype
  - L1384: Landau-type mode collision
  - L1405: Eigenvalue crossing and geometric phase
  - L1422: Symmetry breaking and neural modes
- L1442: Relation to the elimination-geometry program
  - L1445: Regular and singular transfer
  - L1488: A singular obstruction-transfer schema
  - L1515: Scope limits
  - L1540: Open problems
- L1564: Conclusion
- L1600: Elementary calculations behind the normal forms
  - L1603: Winding under a strict residual tube
  - L1624: The real Hessian
  - L1645: The conical-crossing Rayleigh identity
- L1665: Computational verification protocol

### Named statements

- L310: **Definition** — Uniform catastrophe tax
- L351: **Lemma** — Strict approximation preserves the punctured homotopy class
- L402: **Lemma** — Winding divisibility
- L422: **Theorem** — Exact radical catastrophe tax
- L469: **Remark** — Why the minimizer is singular
- L478: **Remark** — The result is objective-specific
- L500: **Theorem** — Radial bounds for a general loop
- L534: **Corollary** — Uniform perturbation stability
- L563: **Assumption** — Homogeneous residual map
- L603: **Theorem** — Homogeneous degree barrier
- L651: **Remark** — Divisibility is only a necessary condition in general
- L662: **Example** — Complex powers
- L672: **Example** — A degree-zero residual map
- L687: **Corollary** — Degree barrier in an annulus
- L742: **Definition** — Discriminant clearance
- L754: **Theorem** — Polynomial discriminant barrier
- L802: **Remark** — Sharpness and its limit
- L813: **Corollary** — The radical theorem as a discriminant theorem
- L832: **Theorem** — Exact local ramification tax
- L885: **Remark** — Local versus global roots
- L895: **Remark** — Stratified extension
- L913: **Proposition** — Separation and vertical Hessian
- L951: **Proposition** — Exact singular scaling
- L982: **Remark** — Regular transfer versus singular witness
- L1014: **Proposition** — Exact atlas number on the circle
- L1064: **Proposition** — Randomization cancels the point-selection tax
- L1093: **Remark** — A quotient can remove a real obstruction
- L1109: **Theorem** — Collapse of the continuous average tax
- L1150: **Remark** — No contradiction with the minimax theorem
- L1166: **Theorem** — Architecture-sensitive radical ledger
- L1199: **Remark** — The tax belongs to a deployment contract
- L1237: **Theorem** — Exact oriented-eigenvector tax
- L1281: **Corollary** — Projector representation has zero tax
- L1306: **Remark** — Berry sign and objective units

## Core 10

**Paper:** Lift Complexity: Intrinsic Admissibility, Slack Factorizations, and the Computational Gate for Elimination Geometry  
**Exact source:** [`core16/lift.tex`](core16/lift.tex)

### Section map

- L158: Introduction
  - L194: The extension-complexity proposal and its obstruction
  - L246: Contributions
  - L300: Classical ingredients and new layer
- L329: Convex objectives as compact epigraph bodies
  - L332: Standing setup
- L477: The slack operator is the intrinsic gate
  - L480: Slack factorizations
  - L589: Gauge
- L621: Finite lift complexity does not prevent collapse
  - L629: A constant-overhead append operation
  - L725: Size is not defect currency
- L766: Slack-anchored reduced lifts
  - L769: Factorization quotients
  - L835: Quotient-faithful coherence
  - L881: Refinement invariance
- L929: The fidelity--coherence--complexity frontier
  - L937: One-sided faithful approximations
  - L1060: A second elimination and its exact ledger
  - L1140: Attainment is an additional theorem, not notation
  - L1191: Constrained and penalized views
- L1244: Canonical target-visible carrier complexity
  - L1458: Finite visible capacity
  - L1553: Carrier saturation and information capacity
  - L1679: The extraction gate for conic lifts
  - L1770: Principal specializations and scope
- L1825: An exact padding artifact
  - L1917: The quotient that exposes the artifact
- L1957: Linear, semidefinite, and sum-of-squares lifts
  - L1960: Polyhedral lifts
  - L1983: PSD lifts
  - L2003: Sum-of-squares hierarchies
- L2052: A conditional exchange from conic computation to defect
  - L2059: Optimization gap is vertical defect
  - L2096: Barrier-conditioned exchange
  - L2149: Why extension lower bounds are not time lower bounds
- L2179: Relation to the companion calculus
  - L2236: A useful boundary with EOT
  - L2260: A useful boundary with Part III
- L2271: Limitations and open problems
  - L2274: No canonical cone dictionary
  - L2284: No general unique quotient core
  - L2297: No universal size-to-capacity conversion
  - L2306: Coupling primitives still require semantics
  - L2316: Approximation quality and bit complexity
  - L2326: The intended complexity-theoretic program
- L2347: Conclusion
- L2386: A finite-library specialization
- L2414: The nondivisible padding formula
- L2434: Notation crosswalk

### Named statements

- L334: **Assumption** — Objective and domain
- L362: **Definition** — Cone dictionary
- L377: **Definition** — Conic lift
- L425: **Definition** — Functional conic lift complexity
- L439: **Proposition** — Epigraph equivalence
- L468: **Remark** — What is counted
- L496: **Definition** — \(K\)-factorization
- L513: **Theorem** — Conic lift--factorization gate
- L542: **Corollary** — Objective lift complexity as slack rank
- L566: **Corollary** — Polyhedral and semidefinite specializations
- L579: **Remark** — The classification is intrinsic but not unique
- L603: **Definition** — Gauge-invariant coupling rule
- L631: **Assumption** — Representable penalty primitive
- L643: **Theorem** — Finite-complexity target-calling no-go
- L699: **Corollary** — A size cutoff does not define admissibility
- L716: **Remark** — Why this is stronger than a language ban
- L727: **Proposition** — Scaling obstruction
- L756: **Remark** — Missing computational data
- L783: **Definition** — Factorization quotient
- L813: **Definition** — Reduced slack carrier
- L840: **Definition** — Quotient-faithful refinement
- L858: **Definition** — Intrinsic lift package
- L871: **Remark** — What remains application dependent
- L896: **Theorem** — Quotient-faithful refinements preserve frontiers
- L917: **Corollary** — The no-go append operation is neutral after reduction
- L944: **Definition** — One-sided \(\delta\)-faithful lift
- L975: **Remark** — Epigraph interpretation
- L996: **Definition** — Single-formulation and global frontiers
- L1035: **Proposition** — Order properties and feasibility gate
- L1067: **Theorem** — Lift-selection ledger
- L1118: **Remark** — The two ledgers are transverse
- L1127: **Corollary** — Near-optimal audit
- L1147: **Theorem** — A compact normalized attainment criterion
- L1181: **Remark** — How normalization can be supplied
- L1219: **Proposition** — Supported frontier points
- L1235: **Remark** — Why the constrained form is primary
- L1286: **Theorem** — Canonical target-visible decomposition
- L1314: **Remark** — Attribution and scope of novelty
- L1370: **Theorem** — Canonical visible quotient and exact coarsening tax
- L1427: **Corollary** — Exact obstruction tower
- L1476: **Theorem** — Finite visible-capacity frontier
- L1568: **Theorem** — Visible-carrier saturation ledger
- L1627: **Theorem** — Information capacity forces native defect
- L1711: **Theorem** — Conditional lift-to-carrier transfer
- L1860: **Theorem** — Exact coherence dilution by factor splitting
- L1937: **Corollary** — Euclidean factor coherence is not quotient intrinsic
- L1947: **Remark** — The example is not an LP lower bound
- L2020: **Proposition** — Exactness gate for hierarchy lifts
- L2043: **Remark** — Degree is not the only cost
- L2070: **Proposition** — Primal--dual accuracy certificate
- L2098: **Theorem** — Conditional barrier-to-defect exchange
- L2132: **Remark** — Uniform oracle fields
- L2140: **Remark** — Cone order versus barrier parameter
- L2151: **Proposition** — Scope of a lift lower bound
- L2392: **Proposition** — Finite library

## Core 11

**Paper:** Operational Semantics of Elimination Pipelines: Task Envelopes and Contextual Coherence  
**Exact source:** [`core16/operation.tex`](core16/operation.tex)

### Section map

- L117: Introduction
  - L176: Contributions
  - L215: Relation to classical ingredients
  - L251: Organization
- L264: Operational setup and main theorem
  - L334: Task envelopes
  - L364: Context grammars and contextual distance
  - L438: Universal contextual completion
- L508: Proof machinery and canonical quotient
  - L512: Task-envelope reconstruction
  - L624: Closure and context pullback
  - L667: Proof of the main theorem
  - L712: Canonical quotient composition
- L761: Observable contracts and resolution
  - L764: Three contracts
  - L860: Lipschitz resolution
- L974: Contextual ordering coherence
- L1097: Worked application: a finite-memory screening pipeline
  - L1126: All six schedules
  - L1179: A legal context reveals the hidden gap
  - L1212: Exact resolution profile
  - L1255: Pairwise budgets and global ordering
- L1302: Interface to certified elimination
- L1349: Limits and conclusion
  - L1402: Conclusion

### Named statements

- L298: **Definition** — Task contract and observational distance
- L337: **Definition** — Task envelope
- L397: **Definition** — Context closure
- L441: **Theorem** — Contextual completion and quantitative full abstraction
- L514: **Proposition** — Task-envelope reconstruction and exact isometry
- L626: **Lemma** — Least closed extension
- L649: **Lemma** — Context pullback
- L714: **Corollary** — Canonical operational quotient
- L767: **Corollary** — Zero-input shadow
- L798: **Corollary** — Fixed-certificate semantics
- L821: **Corollary** — Full reconstruction and finite tomography
- L880: **Remark** — Compact form of the envelope lemma
- L890: **Theorem** — Exact task-resolution semantics
- L944: **Definition** — Resolution profile
- L998: **Theorem** — Exact contextual \(n\)-curvature
- L1055: **Theorem** — Contextual pairwise-to-global bound

## Core 12

**Paper:** Statistical Elimination Geometry: Stable Obstructions and Honest Architecture Certificates  
**Exact source:** [`core16/statistical.tex`](core16/statistical.tex)

### Section map

- L139: Introduction
  - L195: Main results
  - L242: Ownership and novelty boundary
  - L282: Organization
- L293: Confidence transport through elimination
  - L300: Worlds, grammars, and architecture values
  - L359: The bracket theorem
- L468: Persistent atlas obstructions are horizontally stable
  - L476: Sublevel incidences and the inverse frontier
  - L537: Interleaving and exact stability
  - L603: One-sided bands and honest atlas decisions
- L647: Operational confidence and contextual observability
  - L654: Task envelopes
  - L734: Context closure
  - L792: Observable architecture frontiers
- L844: Honest architecture certificates are three-way
  - L851: Confidence sets of elimination worlds
  - L928: Adaptive audit queries
- L951: No free lunch: a stable obstruction can be statistically hidden
  - L960: The radical architecture barrier
  - L1005: Localized winding experiment
- L1102: Worked application: exact noisy radical certificates
  - L1110: Observation model and the exact degree identification set
  - L1239: A local spacing condition for exact certification
  - L1308: Random and active designs
  - L1351: Matching minimax lower bound for the square root
- L1452: Scope, limitations, and consequences
  - L1459: What is universal
  - L1478: What is not universal
  - L1501: Computation and high-dimensional extensions
  - L1523: Interpretation for architecture design
  - L1545: Conclusion

### Named statements

- L333: **Lemma** — Uniform nonexpansiveness
- L379: **Theorem** — Honest elimination bracket
- L423: **Corollary** — Fixed grammar and sharp constant
- L447: **Remark** — Selection costs no additional coverage
- L461: **Remark** — What the theorem does not construct
- L488: **Definition** — Persistent atlas number
- L539: **Theorem** — Atlas interleaving and stable inverse
- L593: **Example** — Why the inverse is the stable object
- L605: **Corollary** — One-sided atlas confidence
- L681: **Theorem** — Exact task normal form and nonexpansiveness
- L759: **Corollary** — Kernel-error transport
- L803: **Theorem** — Honest observable frontier
- L895: **Theorem** — Honesty and maximal decisiveness
- L943: **Remark** — Boundary conventions
- L978: **Proposition** — Exact divisibility barrier
- L1041: **Theorem** — No uniformly informative finite-sample certificate
- L1158: **Theorem** — Exact compatible-degree program
- L1218: **Corollary** — Exact radical trichotomy
- L1251: **Theorem** — Dense-sample collapse
- L1310: **Corollary** — Random-design honest certificate
- L1357: **Theorem** — Hidden-winding parity lower bound
- L1445: **Remark** — Why one localized alternative misses the logarithm

## Core 13

**Paper:** Certificate Statistics: Validity, Resolution Complexity, Task-Relative Sufficiency, and Recursive Updating  
**Exact source:** [`core16/certificate_stat.tex`](core16/certificate_stat.tex)

### Section map

- L128: Introduction
  - L145: The binary-label compression
- L249: Typed certificate experiments
  - L252: Truth, confidence certificate, and posterior color
  - L329: Three carrier types
  - L396: The certificate record
- L411: Honest certificate geometry
  - L414: Maximal decisiveness
  - L449: Threshold profiles and stability
  - L500: Anytime validity and typed unresolvedness
- L539: Resolution complexity
  - L542: Characteristic information
  - L611: Exact Gaussian AND/OR geometry
  - L677: Static allocation geometry and the price of passivity
- L713: Evidence carriers and task-relative sufficiency
  - L721: Exact KL loss and certificate data processing
  - L789: Binding alternatives and the slack criterion
  - L849: Local nuisance quotients and task completeness
  - L962: Exact two-sensor laboratory
- L1009: Two statistical ledgers: Bayesian average and worldwise certificates
  - L1016: Prior-average posterior loss
- L1096: Recursive posterior quotients and minimal memory
  - L1104: Why the current task posterior is not enough
  - L1132: The recursive certificate posterior quotient
  - L1256: Projected Bayes closure and update curvature
  - L1295: The interface ladder and its broken converses
- L1338: Unified active certificate resolution
  - L1349: Two nonexchangeable design currencies
  - L1395: CertTrack: the closed-form Gaussian specialization
  - L1490: CR-BayesTrack: posterior design and worldwise stopping
  - L1669: The certificate realization theorem
- L1734: An end-to-end finite laboratory
- L1847: A real action audit: UCBAdmissions
- L1963: Relations, scope, and research boundary
  - L1970: Boundary matrix
  - L2005: Testing, three decisions, and partial identification
  - L2013: Fixed-confidence pure exploration and active testing
  - L2037: Active learning
  - L2051: Sufficiency, completeness, and experiment comparison
  - L2068: Bayesian design and belief compression
  - L2080: Elimination Geometry and the architecture interface
  - L2104: Ownership statement
- L2150: Conclusion
- L2181: Full CertTrack proof
- L2325: CR-BayesTrack likelihood-ratio audit
- L2391: Carrier-independence constructions
- L2428: A finite refinement algorithm
- L2448: Computable outer certificates
- L2466: Two quantifiers of feasibility

### Named statements

- L305: **Proposition** — Posterior credibility is not worldwise validity
- L361: **Definition** — Typed carrier exactness
- L381: **Theorem** — Carrier non-substitution
- L422: **Theorem** — Worldwise honesty and maximal decisiveness
- L462: **Proposition** — Exact threshold profile
- L481: **Theorem** — Margin stability
- L510: **Theorem** — Anytime-valid certificate
- L570: **Definition** — Worldwise fixed-confidence resolution
- L580: **Theorem** — Resolution lower bound
- L628: **Theorem** — Exact AND/OR certificate complexity
- L739: **Lemma** — Standard conditional KL chain-rule ledger
- L767: **Theorem** — Certificate data processing
- L801: **Theorem** — Exact preservation by slack domination
- L835: **Definition** — Certificate-sufficient evidence carrier
- L881: **Theorem** — Task-quotient contraction and completeness modulus
- L977: **Proposition** — Same carrier dimension, opposite certificate value
- L1025: **Proposition** — Standard task-posterior KL identity
- L1053: **Theorem** — Average--certificate separation
- L1171: **Definition** — Recursive certificate posterior quotient
- L1180: **Theorem** — Recursive quotient theorem
- L1212: **Definition** — Exact recursive carrier
- L1224: **Theorem** — Minimal exact recursive state
- L1271: **Theorem** — Zero projected-update curvature
- L1301: **Theorem** — Sufficiency and recursion interface theorem
- L1446: **Theorem** — Validity and asymptotic exactness of CertTrack
- L1535: **Lemma** — Deterministic transfer for the declared tracker
- L1566: **Theorem** — Anytime worldwise validity
- L1590: **Assumption** — Finite-model regularity
- L1597: **Theorem** — Certificate-optimal leading constant
- L1673: **Theorem** — Certificate realization
- L1819: **Proposition** — Four-layer separation in one finite experiment
- L1909: **Proposition** — UCB audit tolerance profile
- L2189: **Lemma** — Simultaneous internal-time coverage
- L2215: **Lemma** — Target and allocation convergence
- L2255: **Lemma** — Gaussian stabilization tail
- L2331: **Lemma** — Adaptive likelihood-ratio martingale
- L2356: **Lemma** — Adaptive KL law and eventual maximum likelihood

## Core 14

**Paper:** Elimination Geometry of Resource-Constrained Architectures: Typed Capacity, Rate--Distortion, and Certified Deployment  
**Exact source:** [`core16/architecture.tex`](core16/architecture.tex)

### Section map

- L168: Introduction
  - L318: Contributions and ownership of the ingredients
  - L403: Organization
- L418: Architecture contracts and two distortion frontiers
  - L437: Resource grammars
  - L512: Operational contracts
  - L633: Architecture rate and the audit vector
- L670: Typed architecture capacity and common deployment
  - L680: Three carrier domains and a typed resource grammar
  - L770: The common-deployment quantifier
  - L909: Architecture-relative resolution information
  - L1003: Joint colored-state closure
- L1094: Canonical source reduction
  - L1130: The carrier--decoder identity
  - L1187: The coarsest native carrier
  - L1251: Class-level saturation ledger
- L1308: From primitive resources to visible carrier capacity
  - L1338: Hard simplex routing and the minimum \texorpdfstring{$q$}{q}-cut profile
  - L1442: Normalized continuous conic grammars
- L1582: Native architecture rate--distortion
  - L1593: Finite visible-codebook frontier
  - L1689: Metric entropy forces native distortion
  - L1774: The architecture rate--distortion theorem
  - L1858: Information budgets as a special rate coordinate
- L1914: From native distortion to contextual observability
  - L1923: Exact finite visibility
  - L2009: The finite two-gate theorem
  - L2120: Continuous task resolution
  - L2217: Closing the resource--carrier--task chain
  - L2260: Canonical singleton audit
- L2347: Typed realization and certificate-guided expansion
  - L2354: The typed architecture realization theorem
  - L2463: Certificate-guided architecture expansion
- L2550: Worked application: an exact path architecture
  - L2559: Oracle and architecture grammar
  - L2594: Exact native rate--distortion function
  - L2691: An exact finite-resolution audit
  - L2754: Exact observable frontier and phase diagram
  - L2886: Typed interpretation of the path model
- L2917: Scope, interfaces, and conclusion
  - L2924: What is universal and what is grammar specific
  - L2986: Relation to learning and neighboring theories
  - L3092: Why the typed audit is not a scalar master loss
  - L3133: Limits and next theoretical step
  - L3205: Conclusion

### Named statements

- L442: **Definition** — Resource-indexed carrier--decoder grammar
- L472: **Definition** — Native architecture distortion
- L497: **Proposition** — Resource monotonicity
- L614: **Definition** — Observable architecture distortion
- L690: **Definition** — Typed resource grammar
- L745: **Proposition** — Typed carrier non-substitution
- L820: **Theorem** — Common-deployment quantifier theorem
- L878: **Theorem** — Anytime common-deployment certificate
- L952: **Corollary** — Architecture-resolution complexity
- L1038: **Theorem** — Joint colored-state closure
- L1132: **Theorem** — Canonical carrier--decoder decomposition
- L1189: **Theorem** — Canonical visible quotient and coarsening tax
- L1267: **Theorem** — Exact native architecture ledger
- L1369: **Theorem** — Exact hard carrier extraction
- L1418: **Corollary** — Paths and trees
- L1479: **Theorem** — Continuous conic carrier extraction
- L1545: **Proposition** — Ambient sharpness of the dimension exponent
- L1572: **Remark** — Why the grammar is indispensable
- L1604: **Theorem** — Finite Bregman rate--distortion frontier
- L1707: **Theorem** — Entropy-to-native transfer
- L1755: **Corollary** — Separated-type quantization floor
- L1779: **Theorem** — Resource-constrained architecture rate--distortion
- L1828: **Proposition** — Conditional codebook upper bound
- L1871: **Corollary** — Information-limited architecture distortion
- L1944: **Theorem** — Exact finite visibility transform
- L2020: **Definition** — Native-defect readout
- L2043: **Theorem** — Observable obstruction transfer: finite sharp form
- L2152: **Theorem** — Sharp resolution-controlled transfer
- L2222: **Corollary** — Certified architecture rate--distortion and observability
- L2364: **Theorem** — Typed architecture realization
- L2510: **Theorem** — Soundness of typed expansion
- L2605: **Theorem** — Exact path architecture distortion
- L2732: **Lemma** — Exact audit visibility
- L2764: **Theorem** — Exact capacity--resolution surface

## Core 15

**Paper:** Elimination Geometry for Machine Learning and AI: Certified Architecture Realizability and Obstruction-Aware Learning  
**Exact source:** [`core16/egml.tex`](core16/egml.tex)

### Section map

- L163: Introduction
  - L227: Contributions
- L320: From approximation error to architecture realizability
  - L323: Local decisions, oracle risk, and deployable fields
  - L413: The internal carrier--decoder ledger
  - L588: A four-account certified learning theorem
  - L698: Honest confidence transport for an architecture frontier
  - L828: Confidence worlds and the necessary three-way certificate
  - L893: Data-dependent architecture classes
- L917: Native defects and obstruction transfer
  - L920: Why the loss currency is fixed by elimination
  - L978: Native distortion and contextual observability
  - L1180: A population certificate for Lipschitz architectures
  - L1234: Finite calibration graphs and the exact flow certificate
- L1276: Canonical architecture obstructions
  - L1290: Parameter sharing as a coordination tax
  - L1338: Topology: locally exact, globally unselectable
  - L1555: The tax belongs to an output and risk contract
  - L1591: Semantic validity and nonlinear repair
- L1615: Obstruction-Aware Learning and Inference
  - L1677: A repair dictionary
  - L1804: Independent held-out certification
  - L1840: OALI is not generic mixture of experts
- L1858: Interfaces with current ML and AI systems
  - L1861: Amortized variational inference
  - L1907: Policies, world models, and memory
  - L1932: Symmetry, canonicalization, and structured outputs
  - L1950: Foundation models and test-time computation
- L1963: Data-dependent design, reachability, and computation
  - L1966: Structural selection and learning selection use different events
  - L1995: Optimization reachability is not architecture realizability
  - L2012: Auxiliary size is not runtime
- L2028: A falsifiable empirical program
  - L2036: Recommended protocol
  - L2084: Predictions that can fail
- L2124: Scope, neighboring theories, and nonclaims
- L2215: Discussion
- L2258: Proof of the obstruction-flow dual
- L2284: Proof of the shared-kernel tax
- L2300: Proof of the radical tax
- L2323: Proof of the held-out guarantee

### Named statements

- L355: **Definition** — Model and architecture gaps
- L376: **Proposition** — Exact population ledger
- L402: **Remark** — The architecture gap is relational
- L464: **Theorem** — Canonical architecture rate--distortion ledger
- L516: **Proposition** — Canonical visible quotient and coarsening tax
- L551: **Corollary** — Visible-capacity architecture floor
- L578: **Remark** — Decoder nonsaturation versus optimization
- L602: **Assumption** — Uniform generalization event
- L616: **Theorem** — Four-account certified learning bound
- L647: **Corollary** — Resource-indexed certified learning floor
- L667: **Remark** — Why a sandwich rather than a four-term identity
- L677: **Corollary** — Certified lower and upper architecture witnesses
- L725: **Lemma** — Uniform nonexpansiveness
- L766: **Theorem** — Honest architecture-frontier bracket
- L803: **Corollary** — Four-account bound with an estimated structural floor
- L859: **Theorem** — Honesty and maximal decisiveness
- L900: **Proposition** — Conditional sample-split bound
- L942: **Definition** — Geometric architecture obstruction
- L953: **Theorem** — Obstruction transfer
- L1004: **Theorem** — Exact contextual normal form and confidence transport
- L1090: **Proposition** — Conditional native-to-observable transfer
- L1190: **Theorem** — Oracle-variation transport bound
- L1247: **Theorem** — Obstruction-flow dual
- L1298: **Theorem** — Closed-form shared-kernel tax
- L1376: **Proposition** — Persistent atlas rate--distortion interface
- L1404: **Theorem** — Horizontal atlas stability and honest one-sided bands
- L1473: **Theorem** — Exact radical architecture tax
- L1499: **Theorem** — Coverage no-free-lunch for architecture diagnosis
- L1735: **Proposition** — Certified atlas sandwich and finite termination
- L1817: **Theorem** — Finite-library held-out improvement

## Core 16

**Paper:** Elimination Geometry for Adaptive Learning Systems: Certificate-Directed Acquisition, Recursive Capacity, and Architecture Expansion  
**Exact source:** [`core16/egml2.tex`](core16/egml2.tex)

### Section map

- L136: Introduction
- L253: The static deployment block remains EGML
  - L316: The deployment carrier--decoder interface
  - L371: Generalization and optimization remain separate
- L407: Typed adaptive learning systems
  - L444: The audit vector is not a loss decomposition
  - L480: Authorization and design are different states
- L496: Evidence capacity and certificate-directed acquisition
  - L556: What an evidence carrier destroys
  - L620: Posterior guidance inside a worldwise face
- L762: The recursive visible-capacity tower
  - L887: Witness-directed refinement
- L932: Projected update curvature
  - L1012: An exact task-visible order defect
- L1066: No cross-budget compensation
- L1150: The Adaptive EGML Realization Theorem
- L1255: AR-OALI: acquisition and expansion in one loop
- L1344: An action-changing finite learning system
  - L1394: Two equal-size evidence carriers
  - L1405: The present task posterior is too small
  - L1431: Full entropy buys nuisance information
  - L1446: A truth certificate is not yet a deployment route
- L1511: A falsifiable machine-learning program
  - L1522: Recommended protocol
  - L1554: Predictions that can fail
- L1581: Relations, ownership, and scope
  - L1584: Relation to the first EGML paper
  - L1595: Relation to Certificate Statistics
  - L1612: Active learning and experiment design
  - L1623: Belief compression, POMDPs, and continual learning
  - L1638: Architecture search and mixture of experts
  - L1647: Boundaries
- L1671: Conclusion
- L1707: Finite-horizon value preservation
- L1745: Adaptive likelihood-ratio audit
- L1770: Finite refinement pseudocode
- L1787: Exact calculations for the finite laboratories

### Named statements

- L277: **Definition** — Static EGML accounts
- L291: **Proposition** — Exact deployment population ledger
- L332: **Theorem** — Static deployment carrier ledger
- L382: **Theorem** — Static learning sandwich
- L424: **Definition** — Three exactness predicates
- L464: **Remark** — Unit invariance of a typed audit
- L521: **Theorem** — Acquisition lower bound
- L570: **Lemma** — Standard evidence KL chain-rule ledger
- L674: **Lemma** — Declared-tracker discrepancy
- L719: **Assumption** — Finite active-model regularity
- L727: **Theorem** — Worldwise-valid posterior-guided acquisition
- L804: **Definition** — Exact horizon-indexed carrier
- L817: **Theorem** — Recursive quotient and depth-indexed architecture capacity
- L904: **Theorem** — Minimal finite expansion
- L950: **Definition** — Predictive update closure
- L980: **Theorem** — Companion closure/zero-defect interface
- L1014: **Proposition** — Mean-field curvature of $1/8$
- L1077: **Theorem** — Typed no-compensation theorem
- L1158: **Theorem** — Adaptive EGML realization
- L1231: **Corollary** — Simultaneous coordinate attainability
- L1298: **Theorem** — Finite AR-OALI guarantee
- L1334: **Remark** — Unknown kernels
- L1463: **Proposition** — Companion four-layer separation plus deployment gate
- L1725: **Proposition** — Every finite-horizon learning value factors
