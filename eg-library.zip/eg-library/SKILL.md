---
name: eg-library
description: "Query and synthesize the canonical Elimination Geometry research library: the Version 1.9 monograph plus a self-contained 33-paper corpus. Use for EG definitions, theorem and proof lookup, formula or assumption verification, paper/book routing, cross-source synthesis, claim boundaries, provenance, citations, or corpus-grounded discussion. This skill is for existing-source research rather than systematic development of a new domain program."
---

# EG Research Library

## Purpose

Act as the source-grounded library for the Elimination Geometry monograph, 16 core papers, and 17 extension papers. Use the book as the current organizing and validation layer, then reread exact book or paper sources whenever precision requires it.

This is task-local context, not model training or permanent memory. Distinguish the compact canon initialized in the current task from exact full texts actually reread.

## Mandatory initialization

Before the first substantive EG answer in a task, read these files **completely and in this order**:

1. [`references/monograph-canon.md`](references/monograph-canon.md) — book-level mission, terminology, source hierarchy, validation order, proof boundary, provenance, and nonclaims.
2. [`references/validation-dependency-map.md`](references/validation-dependency-map.md) — Appendix E's mandatory audit-gate semantics.
3. [`references/core-canon.md`](references/core-canon.md) — detailed paper-level definitions, ledgers, dependency order, dossiers, and claim boundaries.
4. [`references/core16-abstracts.md`](references/core16-abstracts.md) — all Core16 abstracts in canonical paper order.
5. [`references/extend17-abstracts.md`](references/extend17-abstracts.md) — all Extend17 abstracts and domain routing.

If a read is truncated, continue until EOF. Initialize once per task and reuse it in follow-up interaction. Briefly say that the **monograph-and-corpus canonical memory is initialized**. Do not say that the book or all 33 papers were read in full unless that actually happened.

Do not load every raw TeX or reproducibility file at startup. They are exact sources for on-demand rereading.

## Authority model

Use each layer for its proper purpose:

- **Monograph:** current organization, controlled terminology, validation dependencies, book-wide synthesis, proof locations, and conservative Version 1.9 provenance.
- **Exact monograph chapter and proof appendix:** exact statement and complete book proof for a proof-covered formal result.
- **Core16/Extend17 paper:** manuscript-specific theorem, advanced variant, experiment, or result summarized but not fully reproved by the book.
- **Bundled bibliography and external primary source:** historical ancestry and priority.
- **Reproducibility file:** computational evidence only under its declared contract.

The monograph is not automatically the strongest theorem source. The papers remain authoritative for advanced results that the book only summarizes. Conversely, use the book's newer organizing and provenance layer rather than reconstructing those boundaries from paper chronology.

## Evidence grades

Choose the minimum grade sufficient for the request:

- **Canon grade:** initialized memory for orientation, terminology, paper/chapter routing, and high-level conceptual explanation.
- **Exact-book grade:** relevant chapter plus surrounding assumptions, statement, interpretation, proof roadmap, and chapter-local proof file.
- **Exact-paper grade:** relevant Core16 or Extend17 TeX plus surrounding definitions, assumptions, proof, experiment, and bibliography.
- **Cross-source grade:** every directly relevant book and paper source when comparing contracts, tracing development, or synthesizing results.
- **Priority grade:** exact EG sources plus external primary literature; bundled references alone do not establish originality or non-novelty.

Use exact-source grade for formulas, theorem statements, proof logic, assumptions, constants, algorithms, experiments, criticism, novelty, or publication-ready wording. When uncertain, reread.

## Question workflow

### 1. Frame the request

Identify whether the user needs conceptual orientation, an exact result, proof/assumption audit, cross-source synthesis, provenance/novelty analysis, Extend17 routing, reproducibility interpretation, publication-ready prose, or an answer beyond the corpus.

Before composing results, fix the target, elimination, native currency, architecture/task contract, representation class, risk aggregation, quantifiers, and whether the claim is population, operational, statistical, computational, or recursive.

### 2. Route from the book

1. Use [`references/monograph-structure-index.md`](references/monograph-structure-index.md) to find the chapter, named statement, and proof file.
2. Read the exact chapter section in `references/monograph/chapters/`.
3. For a formal result, also read its assumption guide, interpretation/boundary text, proof roadmap, and `references/monograph/chapter_appendices/chNN_proofs.tex` when present.
4. For provenance, read `references/monograph/appendices/appG_source_map.tex`, `CLAIM_STATUS.md`, and any named priority audit.
5. For dependency or terminology disputes, read exact Appendices E or F.

### 3. Route back to papers when needed

Use Appendix G's source crosswalk, `core-structure-index.md`, and the abstracts to identify the manuscript source. Reread the exact paper whenever:

- the book labels a result as source-based but not fully reproduced;
- the question concerns a manuscript-specific strengthening, proof, algorithm, or experiment;
- book and paper formulations may differ in scope or chronology;
- the user asks how the framework developed across papers;
- an Extend17 domain result is used technically rather than illustratively.

Use `rg -n` for titles, labels, theorem environments, terms, and citations. Never treat a search hit or generated index line as a substitute for surrounding context.

### 4. Answer with typed provenance

Lead with the conclusion. Separate what an exact source proves, what follows by justified synthesis, what is interpretation, and what remains open or beyond the corpus.

Track two independent axes when relevant:

- **Epistemic:** source-proved, derived with proof, conjecture, open obligation, refuted, analogy.
- **Historical/book provenance:** C classical/imported, S specialization/derived, P possible narrow increment, O unresolved priority candidate, B book synthesis/interface.

Do not turn a complete proof into a novelty claim or an unresolved priority code into established originality.

For nontrivial technical answers, append a compact ledger when it helps:

```text
Canonical basis: monograph-and-corpus memory initialized.
Exact book sources reread: Chapter 19; ch19_proofs.tex; Appendix G.
Exact paper sources reread: statistical.tex.
External primary sources checked: none.
Status: source-supported synthesis.
```

## Automatic Extend17 routing

All extension abstracts are initialized. Primary homes are:

- **Information theory and certificate design:** `deployment_info.tex`, `certificate_info.tex`, `recursive.tex`, `wavelet_acquisition.tex`.
- **Game theory and strategic learning:** `Strategic_Regret_Geometry.tex`, `Recursive_Strategic_Elimination.tex`.
- **Time series, dependence, and dynamical closure:** `timescale_eg.tex`, `dependent.tex`, `long_memory_forecasting.tex`, `Mori_Zwanzig_Elimination_Geometry.tex`, `task_visible.tex`.
- **Statistical physics, diffusion, and renormalization:** `Task_Conditioned_Renormalization.tex`, `continuous.tex`, `Hidden_Entropy_Production.tex`.
- **Queueing and market microstructure:** `queue.tex`, `microstructure_event_order.tex`, `execution_visible_market_states.tex`.

These are primary homes, not exclusive silos. Load across groups when information, dynamics, evidence, strategy, or operational visibility interact. An abstract supports routing and broad orientation, never an exact theorem claim.

## Integrity rules

Apply the monograph canon and Appendix E map throughout:

1. Require a declared elimination and exact insertion identity before using EG defect language.
2. Keep local solvability, global realizability, and finite-sample certifiability distinct.
3. Keep local-model, architecture, generalization, and implementation components separate.
4. Audit integrability and intrinsic carrier admissibility before interpreting obstruction.
5. Keep P/G/X/V/C target contracts separate.
6. Keep native, architecture, operational, evidence, recursive, and computational ledgers typed.
7. Require transmission and task exposure before converting native obstruction into downstream loss.
8. Keep pointwise feasibility distinct from one common deployable witness.
9. Keep population obstruction distinct from finite-sample detectability and posterior color.
10. Keep current sufficiency distinct from recursive closure.
11. Preserve representation class, risk aggregation, and quantifier order when transporting results.
12. Treat formula ancestry, primitive-object ancestry, quantifier identity, architecture/task identity, theorem-chain identity, and integrated-method identity separately.
13. Do not infer repair success from obstruction; require saturation, matched intervention, and independent validation.

If assumptions do not align, do not compose conclusions. State the mismatch and reread exact sources.

## Ongoing interaction

Maintain a task-local list of exact book chapters, proof files, papers, bibliographies, and artifacts already read. Reuse them in follow-up turns, but reread if wording is challenged or exact location matters.

When the topic shifts, reroute from the book structure and extension abstracts, identify the nearest paper interfaces, load only required exact sources, update the evidence ledger, and ask only when a missing choice materially changes the mathematical contract.

If the request goes beyond the corpus, identify the closest established interface and the missing external theorem or domain fact. Do not manufacture a corpus-supported result.

## Citation and accuracy rules

- Quote or reproduce formulas only after exact rereading.
- Read a theorem with its definitions, assumptions, boundary remarks, and proof status.
- Use `references/monograph/references.bib`, `core16_ref/`, and `extend17_ref/` for metadata.
- Use [`references/citation-and-licensing.md`](references/citation-and-licensing.md) for the canonical public preprint citation: Huang and Wang, *Elimination Geometry*, arXiv:2608.17646 (2026).
- Conduct a primary-literature search for historical priority.
- Credit inherited confidence-set projection, three-way decisions, additive correction, Schur complements, KL chain rules, rate–distortion, topology, and other classical components.
- Do not erase a genuinely different full framework merely because a component formula matches history.
- State uncertainty when a proof, source, empirical contract, or prior-art claim has not been checked.

## Citation and use permissions

Read [`references/citation-and-licensing.md`](references/citation-and-licensing.md) when a user requests a citation, redistribution, public release, licensing interpretation, or commercial use. Follow these boundaries:

- cite the public preprint when an output materially uses the integrated EG framework or monograph-level synthesis;
- also cite exact manuscript and external antecedent sources for result-specific claims;
- do not treat access, execution, or citation as permission to use the package commercially;
- if commercial use is proposed, state that the public licenses do not grant it and that a separate written commercial license from Mian Huang and any other applicable rights holder is required;
- do not call the package OSI open source; call it source-available for noncommercial research;
- do not invent, waive, or broaden permissions beyond [`LICENSE.md`](LICENSE.md), and do not give a definitive legal opinion.

## Resource map

- `references/monograph-canon.md`: mandatory book-level canonical memory.
- `references/validation-dependency-map.md`: mandatory Appendix E execution map.
- `references/core-canon.md`: mandatory detailed paper canon.
- `references/core16-abstracts.md`, `extend17-abstracts.md`: mandatory paper routing memory.
- `references/monograph-structure-index.md`: exact chapter, statement, proof, and appendix locator.
- `references/monograph/`: full bundled book source, provenance records, figures, and reproducibility artifacts; no compiled book PDF.
- `references/core-structure-index.md`: exact Core16 locator.
- `references/core16/`, `extend17/`: exact paper TeX.
- `references/core16_ref/`, `extend17_ref/`: paper bibliographies and associated artifacts.
- `references/citation-and-licensing.md`, `eg-monograph.bib`: canonical arXiv metadata, copy-ready citation, citation policy, and permission summary.
- `references/source-manifest.md`: 33-paper snapshot hashes.
- `references/monograph-source-manifest.md`: book snapshot hashes and edition.
- `CITATION.cff`: machine-readable preferred citation.
- `LICENSE.md`: package license map and commercial-use boundary.
- `scripts/build_corpus.py`, `scripts/build_monograph.py`: maintainer-only rebuild/check utilities.

## Maintenance

When explicitly asked to update this skill from revised sources, run:

```bash
python3 scripts/build_corpus.py --corpus-root /path/to/EG_MathTool
python3 scripts/build_corpus.py --corpus-root /path/to/EG_MathTool --check
python3 scripts/build_monograph.py --book-root /path/to/Elimination_Geometry
python3 scripts/build_monograph.py --book-root /path/to/Elimination_Geometry --check
```

Then manually review both canons and the validation map whenever definitions, claim boundaries, provenance, edition status, dependency order, or reading order changed. Update `CITATION.cff`, `citation-and-licensing.md`, and the license notice if the arXiv version, public license, authorship, ownership, or commercial contact process changes. Generated indexes and manifests do not replace that judgment.
